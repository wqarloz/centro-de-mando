import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { aEventoDTO } from "@/lib/estatus";

/**
 * La puerta del sitio WQZ al Centro de Mando.
 *
 * POST /api/solicitud — el formulario "Armemos tu cotización" del sitio
 * entrega aquí su carga. El evento nace como PROSPECTO con tarifa 0
 * (a cotizar) y un folio SECUENCIAL de cotización (COT-8241, COT-8242…):
 * nunca aleatorio, para que no haya huecos ni colisiones y el PDF,
 * el WhatsApp del cliente y la tarjeta hablen del mismo número.
 *
 * CORS abierto: en producción el sitio puede vivir en otro dominio.
 */

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS });
}

const RE_CORREO = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const BASE_FOLIO = 8240; // continúa la historia de los folios de muestra

const texto = (v: unknown): string => (typeof v === "string" ? v.trim() : "");

/** "2026-11-20" → Date (mediodía UTC: el día de calendario no se corre). */
const aFecha = (s: string): Date | null => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const d = new Date(`${s}T12:00:00Z`);
  return Number.isNaN(d.getTime()) ? null : d;
};

/** El siguiente folio secuencial: el mayor que exista + 1 (con piso). */
async function siguienteFolio(): Promise<string> {
  const existentes = await db.evento.findMany({
    where: { folio: { startsWith: "COT-" } },
    select: { folio: true },
  });
  let max = BASE_FOLIO;
  for (const e of existentes) {
    const n = Number.parseInt((e.folio ?? "").slice(4), 10);
    if (Number.isFinite(n) && n > max) max = n;
  }
  return `COT-${max + 1}`;
}

const MESES_CORTOS = [
  "ene", "feb", "mar", "abr", "may", "jun",
  "jul", "ago", "sep", "oct", "nov", "dic",
];

export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => null)) as Record<
    string,
    unknown
  > | null;
  if (!body) {
    return NextResponse.json(
      { error: "Cuerpo inválido" },
      { status: 400, headers: CORS }
    );
  }

  const cliente = texto(body.cliente);
  const eventoNombre = texto(body.evento);
  const correo = texto(body.correo);
  const celular = texto(body.celular);
  const sede = texto(body.sede);
  const tema = texto(body.tema);
  const equipo = texto(body.equipo);
  const notasCliente = texto(body.notas);
  const horaInicio = texto(body.horaInicio);
  const horaFin = texto(body.horaFin);
  const modalidadRaw = texto(body.modalidad);

  if (!cliente) {
    return NextResponse.json(
      { error: "Falta el nombre o empresa" },
      { status: 400, headers: CORS }
    );
  }
  if (!correo || !RE_CORREO.test(correo)) {
    return NextResponse.json(
      { error: "Correo inválido" },
      { status: 400, headers: CORS }
    );
  }
  if (!eventoNombre) {
    return NextResponse.json(
      { error: "Falta el nombre del evento" },
      { status: 400, headers: CORS }
    );
  }

  // Días elegidos en el calendario del sitio (ISO, uno por uno).
  const dias = Array.isArray(body.dias)
    ? (body.dias as unknown[]).map((d) => texto(d)).filter((d) => aFecha(d) !== null)
    : [];
  if (dias.length === 0) {
    return NextResponse.json(
      { error: "Falta elegir los días" },
      { status: 400, headers: CORS }
    );
  }

  // Horario del reloj (opcional pero, si viene, viene completo).
  const horarioOk = (h: string) => /^\d{1,2}:\d{2}$/.test(h);
  const hi = horarioOk(horaInicio) ? horaInicio : null;
  const hf = horarioOk(horaFin) ? horaFin : null;

  // Modalidad del sitio → modalidad del comedor.
  const virtual = /virt/i.test(modalidadRaw);
  const modalidad = virtual ? "REMOTO" : sede ? "FORANEO" : "PRESENCIAL_CDMX";

  // Fechas: inicio/fin para ordenar, texto con la lista real de días.
  const ordenados = [...dias].sort();
  const fechaInicio = aFecha(ordenados[0]);
  const fechaFin = aFecha(ordenados[ordenados.length - 1]);
  const fechasTexto = ordenados
    .map((k) => {
      const [y, m, d] = k.split("-").map(Number);
      return `${d} ${MESES_CORTOS[m - 1]} ${y}`;
    })
    .join(" · ");

  const notas = [
    "Llegó del sitio web",
    `Evento: ${eventoNombre}`,
    equipo && equipo !== "Sin equipo" ? `Equipo: ${equipo}` : null,
    notasCliente ? `Notas del cliente: ${notasCliente}` : null,
  ]
    .filter(Boolean)
    .join(" · ");

  // El evento nace como prospecto a cotizar.
  const data = {
    cliente,
    contacto: null,
    telefono: celular || null,
    correo,
    idiomas: "EN - ES",
    estatus: "PROSPECTO",
    razonCancelacion: null,
    fechasTexto,
    fechaInicio,
    fechaFin,
    dias: dias.length,
    horaInicio: hi,
    horaFin: hf,
    horario: hi && hf ? `${hi} - ${hf}` : hi,
    tipoBloque: null,
    tema: tema || null,
    modalidad,
    ciudad: sede || null,
    tarifa: 0,
    tarifaPorDia: null,
    impuestosTipo: null,
    anticipo: 0,
    saldo: 0,
    fechaLimitePago: null,
    linkGlosario: null,
    notas,
  };

  // Folio secuencial con reintento si dos solicitudes llegan a la vez.
  for (let intento = 0; intento < 3; intento++) {
    const folio = await siguienteFolio();
    try {
      const creado = await db.evento.create({ data: { ...data, folio } });
      return NextResponse.json(
        { folio: creado.folio, evento: aEventoDTO(creado) },
        { status: 201, headers: CORS }
      );
    } catch (e) {
      const codigo = (e as { code?: string }).code;
      if (codigo === "P2002" && intento < 2) continue; // folio tomado: siguiente
      return NextResponse.json(
        { error: "No se pudo registrar la solicitud" },
        { status: 500, headers: CORS }
      );
    }
  }
  return NextResponse.json(
    { error: "No se pudo asignar un folio" },
    { status: 500, headers: CORS }
  );
}
