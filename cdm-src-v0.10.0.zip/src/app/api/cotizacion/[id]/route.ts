import { NextRequest, NextResponse } from "next/server";
import { PDFDocument, StandardFonts, rgb, degrees, PDFFont } from "pdf-lib";
import fontkit from "@pdf-lib/fontkit";
import { db } from "@/lib/db";
import { parseEquipo } from "@/lib/estatus";
import { PLAYFAIR_BOLD, PLAYFAIR_ITALICA } from "../fuentes";

// ─────────────────────────────────────────────────────────────────────────────
// Cotización en PDF — Fase 2 del ecosistema (v0.7.1: reglas de contenido ronda 2).
//
// El documento viste de "despacho boutique": papel claro, banda obsidiana con
// filete dorado y la identidad de Carlos Serrano: monograma WQZ en rombo
// dorado en la cabecera y contacto completo al pie.
//
// Reglas de contenido decididas por el usuario (ronda 2 de identidad, 2026-11):
//   · Nombre corto "Carlos Serrano" + iniciales WQZ (antes LCS, "por ahora").
//   · Sin fila de horarios en el detalle del servicio.
//   · Sin sección de aceptación: el documento cierra con una línea cortés en
//     itálica y el pie de contacto.
//
// Las tipografías de la casa (Playfair Display, SIL OFL) viajan incrustadas en
// base64 (fuentes.ts): el despliegue en Vercel nunca lee archivos del disco.
//
// El dinero se despliega siempre con el desglose clásico mexicano:
//   Subtotal (tarifa) + IVA 16% = Total
// El desglose fiscal MORAL/FAE (retenciones) es información interna del
// panel y NO viaja al cliente: el documento le presenta lo que él paga.
// ─────────────────────────────────────────────────────────────────────────────

export const dynamic = "force-dynamic";

// Datos del emisor — forma corta decidida por el usuario (ronda 2, 2026-11).
const EMISOR = {
  nombre: "Carlos Serrano",
  titulo: "Intérprete · Traductor",
  iniciales: "WQZ",
  telefono: "+52 55 4652 9029",
  correo: "lcsb.tra.int@gmail.com",
  vigencia: "Vigencia: 15 días naturales a partir de la fecha de emisión.",
  nota:
    "Los importes se expresan en pesos mexicanos (MXN). La disponibilidad de las fechas queda sujeta a confirmación.",
};

// Paleta "Estación de lujo"
const NEGRO = rgb(0.07, 0.07, 0.08); // obsidiana de la banda
const TINTA = rgb(0.13, 0.13, 0.15); // texto principal
const GRIS = rgb(0.47, 0.46, 0.5); // texto secundario
const ORO = rgb(0.69, 0.55, 0.33); // dorado #B08D57
const LINEA = rgb(0.83, 0.82, 0.8); // hairlines del papel
const PAPEL = rgb(1, 1, 1);

const A4 = { ancho: 595.28, alto: 841.89 };
const MARGEN = 48;
const DERECHA = A4.ancho - MARGEN; // borde derecho del contenido

// ── Utilidades de texto ──────────────────────────────────────────────────────

/** Dinero determinista: 9280 → "9,280.00" (sin depender del locale del server). */
function dinero(n: number): string {
  const v = Math.round(n * 100) / 100;
  const [ent, dec] = v.toFixed(2).split(".");
  const conComas = ent.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${conComas}.${dec}`;
}

const MESES = [
  "enero", "febrero", "marzo", "abril", "mayo", "junio",
  "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
];

/** "2026-11-06T12:00:00.000Z" → "6 de noviembre de 2026" (día UTC del evento). */
function fechaLarga(iso: string): string {
  const d = new Date(iso);
  return `${d.getUTCDate()} de ${MESES[d.getUTCMonth()]} de ${d.getUTCFullYear()}`;
}

/** Hoy en horario de México (UTC−6 fijo, sin horario de verano desde 2022):
 *  la cotización viaja al cliente con la fecha que él ve en su reloj, no la
 *  del servidor donde se genere (Vercel corre en UTC y de madrugada se
 *  adelanta un día). */
function hoyMexicoIso(): string {
  return new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString();
}

/** Rango humano: "28 – 29 de octubre de 2026" o "28 de oct – 3 de nov de 2026". */
function rangoFechas(iniIso: string, finIso: string | null): string {
  const ini = new Date(iniIso);
  if (!finIso) return fechaLarga(iniIso);
  const fin = new Date(finIso);
  const mismoDia =
    ini.getUTCFullYear() === fin.getUTCFullYear() &&
    ini.getUTCMonth() === fin.getUTCMonth() &&
    ini.getUTCDate() === fin.getUTCDate();
  if (mismoDia) return fechaLarga(iniIso);
  const anio = ini.getUTCFullYear();
  if (ini.getUTCFullYear() === fin.getUTCFullYear()) {
    if (ini.getUTCMonth() === fin.getUTCMonth()) {
      return `${ini.getUTCDate()} – ${fin.getUTCDate()} de ${MESES[fin.getUTCMonth()]} de ${anio}`;
    }
    return (
      `${ini.getUTCDate()} de ${MESES[ini.getUTCMonth()]} – ` +
      `${fin.getUTCDate()} de ${MESES[fin.getUTCMonth()]} de ${anio}`
    );
  }
  return `${fechaLarga(iniIso)} – ${fechaLarga(finIso)}`;
}

/** Par de idiomas legible para el cliente: "EN - ES" → "Inglés – Español". */
function idiomasLegible(idiomas: string | null): string {
  if (idiomas === "EN - ES") return "Inglés – Español";
  if (idiomas === "PO - ES") return "Portugués – Español";
  return "A definir";
}

function modalidadLegible(mod: string, ciudad: string | null): string {
  // Para el cliente no existe lo "foráneo" (jerga interna relativa a la
  // base en CDMX): lo que le importa es DÓNDE será el servicio.
  if (mod === "PRESENCIAL_CDMX") return "Presencial · Ciudad de México";
  if (mod === "REMOTO") return "Remoto · en línea";
  return ciudad ? `Presencial · ${ciudad}` : "Presencial · ciudad por confirmar";
}

/** Reduce el cuerpo de la letra hasta que el texto quepa en el ancho dado. */
function ajustar(
  texto: string,
  font: { widthOfTextAtSize: (t: string, s: number) => number },
  base: number,
  maxAncho: number,
  minimo = 8
): number {
  let s = base;
  while (s > minimo && font.widthOfTextAtSize(texto, s) > maxAncho) s -= 0.5;
  return s;
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  const fila = await db.evento.findUnique({ where: { id } }).catch(() => null);
  if (!fila) {
    return NextResponse.json({ error: "Evento no encontrado" }, { status: 404 });
  }

  // Equipo del evento (ronda 17): lo marcado para el cliente viaja al PDF —
  // con costo propio va a INVERSIÓN como concepto aparte; sin costo se
  // declara incluido en la tarifa. Las líneas internas no salen de la base.
  const equipo = parseEquipo(fila.equipo);
  const equipoPdf = equipo.filter((l) => l.enCotizacion);
  const sinCosto = equipoPdf.filter((l) => !l.precio);
  const conCosto = equipoPdf.filter((l) => l.precio);

  // Código de cotización: hereda el identificador corto del evento.
  const codigo =
    "COT-" + (fila.idEvento ? fila.idEvento.replace(/^EV-/, "") : fila.id.slice(-4).toUpperCase());

  const pdf = await PDFDocument.create();
  pdf.setTitle(`Cotización ${codigo} — ${fila.cliente}`);
  pdf.setAuthor(EMISOR.nombre);
  pdf.setSubject(`Cotización de servicios de interpretación · ${EMISOR.titulo}`);
  pdf.setCreator("Centro de Mando");
  pdf.registerFontkit(fontkit);

  const pagina = pdf.addPage([A4.ancho, A4.alto]);
  const helv = await pdf.embedFont(StandardFonts.Helvetica);
  const helvBold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const timesBold = await pdf.embedFont(StandardFonts.TimesRomanBold);
  const playfair = await pdf.embedFont(PLAYFAIR_BOLD, { subset: true });
  const playfairItalica = await pdf.embedFont(PLAYFAIR_ITALICA, { subset: true });

  type Color = ReturnType<typeof rgb>;

  const texto = (
    s: string,
    x: number,
    y: number,
    opts: {
      font?: PDFFont;
      tam?: number;
      color?: Color;
      derecha?: boolean;
      centro?: boolean;
    } = {}
  ) => {
    const font = opts.font ?? helv;
    const tam = opts.tam ?? 10;
    const color = opts.color ?? TINTA;
    let px = x;
    if (opts.derecha || opts.centro) {
      const w = font.widthOfTextAtSize(s, tam);
      if (opts.derecha) px = x - w;
      if (opts.centro) px = (A4.ancho - w) / 2;
    }
    pagina.drawText(s, { x: px, y, size: tam, font, color });
  };

  /** Ancho total de un texto con espaciado extra entre letras (tracking). */
  const anchoEspaciado = (s: string, font: PDFFont, tam: number, tracking: number) =>
    [...s].reduce((w, ch) => w + font.widthOfTextAtSize(ch, tam) + tracking, 0) - tracking;

  /** Texto con "aire" entre letras — la firma visual de la papelería fina. */
  const textoEspaciado = (
    s: string,
    x: number,
    y: number,
    opts: {
      font?: PDFFont;
      tam?: number;
      color?: Color;
      tracking?: number;
      derecha?: boolean;
      centro?: boolean;
    } = {}
  ) => {
    const font = opts.font ?? helv;
    const tam = opts.tam ?? 10;
    const color = opts.color ?? TINTA;
    const tracking = opts.tracking ?? 0;
    if (!tracking) {
      texto(s, x, y, { font, tam, color, derecha: opts.derecha, centro: opts.centro });
      return;
    }
    const total = anchoEspaciado(s, font, tam, tracking);
    let px = x;
    if (opts.derecha) px = x - total;
    if (opts.centro) px = (A4.ancho - total) / 2;
    for (const ch of s) {
      pagina.drawText(ch, { x: px, y, size: tam, font, color });
      px += font.widthOfTextAtSize(ch, tam) + tracking;
    }
  };

  const hairline = (y: number, gruesa = false) => {
    pagina.drawRectangle({
      x: MARGEN,
      y,
      width: A4.ancho - MARGEN * 2,
      height: gruesa ? 1 : 0.5,
      color: LINEA,
    });
  };

  /** Escribe un párrafo con ajuste de línea y devuelve la y siguiente.
 *  Si no cabe en maxLineas, la última se cierra con elipsis. */
  const escribirParrafo = (
    s: string,
    y: number,
    tam: number,
    color: Color,
    maxLineas = 3
  ): number => {
    const ancho = A4.ancho - MARGEN * 2;
    const palabras = s.split(" ");
    const lineas: string[] = [];
    let actual: string[] = [];
    for (const p of palabras) {
      const prueba = [...actual, p].join(" ");
      if (actual.length && helv.widthOfTextAtSize(prueba, tam) > ancho) {
        lineas.push(actual.join(" "));
        actual = [p];
        if (lineas.length >= maxLineas) break;
      } else {
        actual.push(p);
      }
    }
    if (actual.length && lineas.length < maxLineas) lineas.push(actual.join(" "));
    const corto = lineas.join(" ").length < s.length;
    for (let i = 0; i < lineas.length; i++) {
      let linea = lineas[i];
      if (corto && i === lineas.length - 1) {
        linea = linea.length > 3 ? linea.slice(0, -3) + "…" : linea + "…";
      }
      texto(linea, MARGEN, y, { tam, color });
      y -= 13;
    }
    return y;
  };

  /** Rombo de contorno dorado — el sello del monograma. */
  const romboContorno = (cx: number, cy: number, r: number, grosor: number) => {
    const vertices: [number, number][] = [
      [cx, cy + r],
      [cx + r, cy],
      [cx, cy - r],
      [cx - r, cy],
      [cx, cy + r],
    ];
    for (let i = 0; i < vertices.length - 1; i++) {
      pagina.drawLine({
        start: { x: vertices[i][0], y: vertices[i][1] },
        end: { x: vertices[i + 1][0], y: vertices[i + 1][1] },
        thickness: grosor,
        color: ORO,
      });
    }
  };

  /** Rombo dorado relleno — viñeta que hace eco al monograma. */
  const romboRelleno = (cx: number, cy: number, r: number) => {
    pagina.drawRectangle({
      x: cx - r,
      y: cy - r,
      width: r * 2,
      height: r * 2,
      color: ORO,
      rotate: degrees(45),
    });
  };

  // ── Cabecera: banda obsidiana con el sello personal ─────────────────────────
  const ALTO_BANDA = 82;
  pagina.drawRectangle({
    x: 0,
    y: A4.alto - ALTO_BANDA,
    width: A4.ancho,
    height: ALTO_BANDA,
    color: NEGRO,
  });
  pagina.drawRectangle({
    x: 0,
    y: A4.alto - ALTO_BANDA - 2.5,
    width: A4.ancho,
    height: 2.5,
    color: ORO,
  });

  // Monograma: iniciales en rombo de doble filete dorado.
  const cxMono = MARGEN + 27;
  const cyMono = A4.alto - 44;
  romboContorno(cxMono, cyMono, 26, 1.1);
  romboContorno(cxMono, cyMono, 20, 0.45);
  const anchoIniciales = playfair.widthOfTextAtSize(EMISOR.iniciales, 13);
  pagina.drawText(EMISOR.iniciales, {
    x: cxMono - anchoIniciales / 2,
    y: cyMono - 4.5,
    size: 13,
    font: playfair,
    color: ORO,
  });

  // Nombre y título del emisor.
  const xNombre = MARGEN + 64;
  let tamNombre = 19;
  while (
    tamNombre > 12 &&
    anchoEspaciado(EMISOR.nombre, playfair, tamNombre, 0.5) > DERECHA - 150 - xNombre
  ) {
    tamNombre -= 0.5;
  }
  textoEspaciado(EMISOR.nombre, xNombre, A4.alto - 38, {
    font: playfair,
    tam: tamNombre,
    color: PAPEL,
    tracking: 0.5,
  });
  textoEspaciado(EMISOR.titulo.toUpperCase(), xNombre, A4.alto - 56, {
    font: helvBold,
    tam: 8.5,
    color: ORO,
    tracking: 2.4,
  });

  // Código y fecha de emisión (bloque derecho de la banda).
  texto(codigo, DERECHA, A4.alto - 38, {
    font: helvBold,
    tam: 11,
    color: ORO,
    derecha: true,
  });
  texto(`Emitida: ${fechaLarga(hoyMexicoIso())}`, DERECHA, A4.alto - 56, {
    tam: 8.5,
    color: rgb(0.72, 0.71, 0.69),
    derecha: true,
  });

  // ── Título del documento sobre el papel ────────────────────────────────────
  const yTitulo = A4.alto - ALTO_BANDA - 36;
  romboRelleno(MARGEN + 6, yTitulo + 8, 3.1);
  texto("Cotización de servicios", MARGEN + 20, yTitulo, {
    font: playfair,
    tam: 26,
    color: TINTA,
  });

  let y = yTitulo - 30;

  // ── Preparado para ──
  const etiqueta = (s: string) =>
    texto(s, MARGEN, y, { font: helvBold, tam: 8.5, color: ORO });
  const filaDato = (rotulo: string, valor: string) => {
    texto(rotulo, MARGEN, y, { tam: 10, color: GRIS });
    texto(valor, DERECHA, y, { tam: 10, color: TINTA, derecha: true });
  };

  etiqueta("PREPARADO PARA");
  y -= 20;
  const tamCliente = ajustar(fila.cliente, helvBold, 15, A4.ancho - MARGEN * 2, 11);
  texto(fila.cliente, MARGEN, y, { font: helvBold, tam: tamCliente });
  y -= 17;
  for (const linea of [
    fila.contacto,
    fila.correo,
    fila.telefono ? `Tel. ${fila.telefono}` : null,
  ]) {
    if (linea) {
      texto(linea, MARGEN, y, { tam: 9.5, color: GRIS });
      y -= 15;
    }
  }
  y -= 10;
  hairline(y);
  y -= 30;

  // ── Detalle del servicio ──
  etiqueta("DETALLE DEL SERVICIO");
  y -= 22;

  const diasTexto = fila.dias
    ? `${fila.dias} ${fila.dias === 1 ? "día" : "días"} de servicio`
    : "Por definir";
  // Sin fila de horarios (decisión del usuario, ronda 2 de identidad).
  const fechas = fila.fechaInicio
    ? rangoFechas(fila.fechaInicio.toISOString(), fila.fechaFin?.toISOString() ?? null)
    : fila.fechasTexto || "Por definir";

  const filas: [string, string][] = [
    ["Fechas", fechas],
    ["Duración", diasTexto],
    ["Idiomas", idiomasLegible(fila.idiomas)],
    ["Modalidad", modalidadLegible(fila.modalidad, fila.ciudad)],
    ...(fila.tema ? ([["Tema / industria", fila.tema]] as [string, string][]) : []),
    ...(fila.tipoBloque ? ([["Jornada", fila.tipoBloque]] as [string, string][]) : []),
  ];

  for (const [rotulo, valor] of filas) {
    filaDato(rotulo, valor);
    y -= 8;
    hairline(y);
    y -= 21;
  }

  // ── Equipo incluido en la tarifa (ronda 17) ──
  // Lo que el servicio necesita y no se cobra aparte: se declara para que el
  // cliente lo vea cubierto por su cotización (p. ej. la media cabina).
  if (sinCosto.length > 0) {
    y -= 6;
    etiqueta("EQUIPO INCLUIDO EN EL SERVICIO");
    y -= 20;
    const lista = sinCosto
      .map((l) => `${l.cantidad > 1 ? `${l.cantidad} × ` : ""}${l.nombre}`)
      .join(" · ");
    y = escribirParrafo(lista, y, 9.5, TINTA, 3) + 6;
    hairline(y);
    y -= 21;
  }

  y -= 12;

  // ── Inversión: siempre Subtotal + IVA 16% = Total ──
  etiqueta("INVERSIÓN");
  y -= 22;

  const tarifa = fila.tarifa ?? 0;
  if (tarifa > 0) {
    if (fila.tarifaPorDia && fila.tarifaPorDia > 0 && fila.dias && fila.dias > 1) {
      texto(
        `Tarifa diaria: $ ${dinero(fila.tarifaPorDia)} × ${fila.dias} días`,
        MARGEN,
        y,
        { tam: 9.5, color: GRIS }
      );
      y -= 20;
    }

    // Equipo con costo propio (ronda 17): conceptos que se suman a la
    // interpretación. Sin equipo, el bloque queda idéntico al de siempre.
    const conceptos = conCosto.slice(0, 3);
    const extra = conCosto.slice(3);
    const totalEquipo = conCosto.reduce(
      (suma, l) => suma + (l.precio ?? 0) * l.cantidad,
      0
    );
    const subtotal = tarifa + totalEquipo;
    const iva = subtotal * 0.16;
    const total = subtotal + iva;

    texto(totalEquipo > 0 ? "Interpretación" : "Subtotal", MARGEN, y, { tam: 11 });
    texto(`$ ${dinero(tarifa)}`, DERECHA, y, { tam: 11, derecha: true });
    y -= 18;

    for (const l of conceptos) {
      const nombreLinea = `${l.nombre}${l.cantidad > 1 ? ` (${l.cantidad})` : ""}`;
      texto(nombreLinea, MARGEN, y, {
        tam: ajustar(nombreLinea, helv, 10, A4.ancho - MARGEN * 2 - 120, 8),
        color: GRIS,
      });
      texto(`$ ${dinero((l.precio ?? 0) * l.cantidad)}`, DERECHA, y, {
        tam: 10,
        color: TINTA,
        derecha: true,
      });
      y -= 16;
    }
    if (extra.length > 0) {
      const extraMonto = extra.reduce(
        (suma, l) => suma + (l.precio ?? 0) * l.cantidad,
        0
      );
      texto(
        `Equipo adicional (${extra.length} ${
          extra.length === 1 ? "concepto" : "conceptos"
        })`,
        MARGEN,
        y,
        { tam: 10, color: GRIS }
      );
      texto(`$ ${dinero(extraMonto)}`, DERECHA, y, { tam: 10, color: TINTA, derecha: true });
      y -= 16;
    }

    if (totalEquipo > 0) {
      texto("Subtotal", MARGEN, y, { tam: 11 });
      texto(`$ ${dinero(subtotal)}`, DERECHA, y, { tam: 11, derecha: true });
      y -= 20;
    } else {
      y -= 2; // sin equipo: el salto de siempre entre tarifa e IVA
    }
    texto("IVA (16%)", MARGEN, y, { tam: 11 });
    texto(`$ ${dinero(iva)}`, DERECHA, y, { tam: 11, derecha: true });
    y -= 14;
    hairline(y, true);
    y -= 24;
    texto("Total", MARGEN, y, { font: helvBold, tam: 12 });
    texto(`$ ${dinero(total)} MXN`, DERECHA, y, {
      font: timesBold,
      tam: 16,
      derecha: true,
    });

    // Vigencia de la cotización — urgencia comercial sutil, con viñeta rombo.
    // En documentos muy cargados se omite para no invadir el pie de página.
    if (y >= 140) {
      y -= 22;
      romboRelleno(MARGEN + 4, y + 3, 2.6);
      texto(EMISOR.vigencia, MARGEN + 14, y, { tam: 9, color: GRIS });
    }
  } else {
    texto("Inversión por definir", MARGEN, y, { tam: 11, color: GRIS });
  }

  // ── Nota al pie del cuerpo ──
  y -= 28;
  const anchoNota = A4.ancho - MARGEN * 2;
  const tamNota = 9;
  const palabras = EMISOR.nota.split(" ");
  let linea: string[] = [];
  for (const p of palabras) {
    const prueba = [...linea, p].join(" ");
    if (helv.widthOfTextAtSize(prueba, tamNota) > anchoNota && linea.length) {
      texto(linea.join(" "), MARGEN, y, { tam: tamNota, color: GRIS });
      y -= 13;
      linea = [p];
    } else {
      linea.push(p);
    }
  }
  if (linea.length) {
    texto(linea.join(" "), MARGEN, y, { tam: tamNota, color: GRIS });
  }

  // ── Cierre cortés ──
  // La sección de aceptación con firmas fue retirada por decisión del usuario
  // (ronda 2 de identidad): el documento termina con esta línea y el pie.
  y -= 18;
  romboRelleno(A4.ancho / 2, y, 3.2);
  texto("Quedo a sus órdenes para cualquier ajuste.", 0, y - 20, {
    font: playfairItalica,
    tam: 11.5,
    color: GRIS,
    centro: true,
  });

  // ── Pie del documento: identidad y contacto del emisor ──
  pagina.drawRectangle({
    x: MARGEN,
    y: 96,
    width: anchoNota,
    height: 0.8,
    color: ORO,
  });
  textoEspaciado(
    `${EMISOR.nombre.toUpperCase()} · ${EMISOR.titulo.toUpperCase()}`,
    0,
    80,
    { font: helvBold, tam: 8, color: GRIS, tracking: 1.1, centro: true }
  );
  texto(`${EMISOR.telefono} · ${EMISOR.correo}`, 0, 66, {
    tam: 8.5,
    color: GRIS,
    centro: true,
  });

  const bytes = await pdf.save();

  return new NextResponse(bytes as unknown as BodyInit, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="Cotizacion-${codigo}.pdf"`,
      "Cache-Control": "no-store",
    },
  });
}
