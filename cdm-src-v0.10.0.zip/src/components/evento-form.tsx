"use client";

import { useEffect, useMemo, useState } from "react";
import { Calendar1, Clock, EyeOff, FileText, Pencil, Plus, X } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import CalendarioRango from "@/components/calendario-rango";
import Reloj24 from "@/components/reloj-24";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  calcularImpuestos,
  ESTATUS_CONFIG,
  ESTATUS_VALIDOS,
  type EventoDTO,
  type Estatus,
  formatoDinero,
  formatoTarifa,
  IDIOMAS_VALIDOS,
  IMPUESTOS_CONFIG,
  type ImpuestosTipo,
  MAX_LINEAS_EQUIPO,
  type Modalidad,
  MODALIDAD_CONFIG,
  type LineaEquipo,
  resumenEquipo,
} from "@/lib/estatus";
import { useToast } from "@/hooks/use-toast";
import { SUPERFICIE_TARJETA } from "@/lib/temas";
import { fechaDisplay } from "@/lib/fechas";

interface Props {
  /** Modo crear: avisa cuando un evento nuevo queda guardado. */
  onCreado?: (evento: EventoDTO) => void;
  /** Modo editar: el evento a precargar. */
  evento?: EventoDTO;
  /** Modo editar: avisa cuando los cambios quedan guardados. */
  onEditado?: (evento: EventoDTO) => void;
}

const SECCION = "text-[10px] font-medium uppercase tracking-[0.18em] text-acento/70";
const ETIQUETA = "text-xs font-medium text-tinta-suave";

// Botones de añadido rápido — hablan el mismo idioma que el sitio WQZ
// («Media cabina con receptores»…), así la cotización y el sitio coinciden.
// “paso” es en cuánto sube la cantidad cuando el preset ya está en la lista.
type PresetEquipo = { label: string; paso: number; linea: LineaEquipo };
const PRESETS_EQUIPO: PresetEquipo[] = [
  {
    label: "Receptores",
    paso: 20,
    linea: { nombre: "Receptores", cantidad: 20, precio: null, enCotizacion: true },
  },
  {
    label: "Media cabina",
    paso: 1,
    linea: { nombre: "Media cabina con receptores", cantidad: 1, precio: null, enCotizacion: true },
  },
  {
    label: "Cabina completa",
    paso: 1,
    linea: { nombre: "Cabina completa con receptores", cantidad: 1, precio: null, enCotizacion: true },
  },
  {
    label: "Body / transmisor",
    paso: 1,
    linea: { nombre: "Body / transmisor", cantidad: 1, precio: null, enCotizacion: false },
  },
];

// Columnas del editor de equipo: artículo · cantidad · precio · PDF · quitar.
const GRID_LINEA = "grid grid-cols-[minmax(0,1fr)_52px_74px_34px_30px] items-center gap-1.5";

type FormState = {
  cliente: string;
  contacto: string;
  telefono: string;
  correo: string;
  idiomas: string; // "" | "EN - ES" | "PO - ES"
  tema: string;
  modalidad: Modalidad;
  ciudad: string;
  estatus: Estatus;
  fechaInicio: string;
  fechaFin: string;
  horaInicio: string;
  horaFin: string;
  tarifaPorDia: string;
  tarifa: string;
  anticipo: string;
  impuestosTipo: "" | ImpuestosTipo;
  fechaLimitePago: string;
  linkGlosario: string;
  notas: string;
  equipo: LineaEquipo[];
};

const VACIO: FormState = {
  cliente: "",
  contacto: "",
  telefono: "",
  correo: "",
  idiomas: "",
  tema: "",
  modalidad: "PRESENCIAL_CDMX",
  ciudad: "",
  estatus: "PROSPECTO",
  fechaInicio: "",
  fechaFin: "",
  horaInicio: "",
  horaFin: "",
  tarifaPorDia: "",
  tarifa: "",
  anticipo: "",
  impuestosTipo: "",
  fechaLimitePago: "",
  linkGlosario: "",
  notas: "",
  equipo: [],
};

/** Pasa de un evento guardado a los valores que muestran los inputs. */
function desdeEvento(e: EventoDTO): FormState {
  // El instante ISO se lee como fecha de exhibición (día de calendario UTC):
  // así el input muestra el día que el usuario registró, sin importar su
  // zona horaria — y sin corrimientos de un día al editar.
  const fecha = (s: string | null) => {
    if (!s) return "";
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
    const d = fechaDisplay(s);
    return d ? format(d, "yyyy-MM-dd") : "";
  };
  const ini = fecha(e.fechaInicio);
  const fin = fecha(e.fechaFin);
  return {
    cliente: e.cliente,
    contacto: e.contacto ?? "",
    telefono: e.telefono ?? "",
    correo: e.correo ?? "",
    idiomas: (IDIOMAS_VALIDOS as readonly string[]).includes(e.idiomas ?? "")
      ? (e.idiomas as string)
      : "",
    tema: e.tema ?? "",
    modalidad: e.modalidad,
    ciudad: e.ciudad ?? "",
    estatus: e.estatus,
    fechaInicio: ini,
    fechaFin: fin,
    horaInicio: e.horaInicio ?? "",
    horaFin: e.horaFin ?? "",
    tarifaPorDia: e.tarifaPorDia != null ? String(e.tarifaPorDia) : "",
    tarifa: e.tarifa != null ? String(e.tarifa) : "",
    anticipo: e.anticipo != null ? String(e.anticipo) : "",
    impuestosTipo: e.impuestosTipo ?? "",
    fechaLimitePago:
      e.fechaLimitePago && /^\d{4}-\d{2}-\d{2}$/.test(e.fechaLimitePago)
        ? e.fechaLimitePago
        : "",
    linkGlosario: e.linkGlosario ?? "",
    notas: e.notas ?? "",
    equipo: (e.equipo ?? []).map((l) => ({ ...l })),
  };
}

/** Días que abarca el evento según las fechas del formulario. */
function diasDelForm(f: Pick<FormState, "fechaInicio" | "fechaFin">): number | null {
  if (!f.fechaInicio) return null;
  if (!f.fechaFin) return 1;
  const ini = new Date(f.fechaInicio + "T12:00:00");
  const fin = new Date(f.fechaFin + "T12:00:00");
  const d = Math.round((fin.getTime() - ini.getTime()) / 86400000) + 1;
  return d < 1 ? 1 : d;
}

export default function EventoForm({ onCreado, evento, onEditado }: Props) {
  const esEdicion = Boolean(evento);
  const [abierto, setAbierto] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState<FormState>(() =>
    evento ? desdeEvento(evento) : VACIO
  );
  const { toast } = useToast();

  // Si el evento cambia por fuera (edición o toque), el formulario se sincroniza.
  useEffect(() => {
    if (evento) setForm(desdeEvento(evento));
  }, [evento]);

  const set = (k: keyof FormState) => (v: string) =>
    setForm((f) => ({ ...f, [k]: v }));

  const dias = useMemo(() => diasDelForm(form), [form]);

  // ── Fechas y horario: pop-ups estilo WQZ (calendario y reloj) ──
  const [calAbierto, setCalAbierto] = useState(false);
  const [relojAbierto, setRelojAbierto] = useState(false);

  const resumenFechas = useMemo(() => {
    if (!form.fechaInicio) return "Toca el calendario";
    const ini = new Date(form.fechaInicio + "T12:00:00");
    const texto = (d: Date) => format(d, "d MMM", { locale: es });
    if (!form.fechaFin || form.fechaFin === form.fechaInicio)
      return texto(ini);
    const fin = new Date(form.fechaFin + "T12:00:00");
    return `${texto(ini)} – ${texto(fin)} · ${dias} ${dias === 1 ? "día" : "días"}`;
  }, [form.fechaInicio, form.fechaFin, dias]);

  const resumenHorario = useMemo(() => {
    if (!form.horaInicio || !form.horaFin) return "Toca el reloj";
    const [h1, m1] = form.horaInicio.split(":").map(Number);
    const [h2, m2] = form.horaFin.split(":").map(Number);
    const mins = h2 * 60 + m2 - (h1 * 60 + m1);
    if (mins <= 0) return form.horaInicio;
    return `${form.horaInicio} – ${form.horaFin} · ${
      mins % 60 === 0 ? `${Math.round(mins / 60)} h` : `${(mins / 60).toFixed(1)} h`
    }`;
  }, [form.horaInicio, form.horaFin]);

  // ── Tarifa por día → total autocalculado ──
  useEffect(() => {
    const porDia = parseFloat(form.tarifaPorDia);
    if (Number.isFinite(porDia) && porDia > 0 && dias && dias >= 1) {
      const total = porDia * dias;
      setForm((f) =>
        f.tarifa === String(total) ? f : { ...f, tarifa: String(total) }
      );
    }
  }, [form.tarifaPorDia, dias]);

  // Vista previa de lo que se calculará automáticamente
  const previa = useMemo(() => {
    const partes: string[] = [];
    if (dias) partes.push(`${dias} ${dias === 1 ? "día" : "días"}`);
    if (/^\d{1,2}:\d{2}$/.test(form.horaInicio) && /^\d{1,2}:\d{2}$/.test(form.horaFin)) {
      const [h1, m1] = form.horaInicio.split(":").map(Number);
      const [h2, m2] = form.horaFin.split(":").map(Number);
      const mins = h2 * 60 + m2 - (h1 * 60 + m1);
      if (mins > 0) {
        partes.push(
          mins >= 360 ? "Jornada Completa" : mins >= 180 ? "Medio Día" : "Por Hora"
        );
      }
    }
    const porDia = parseFloat(form.tarifaPorDia);
    if (Number.isFinite(porDia) && porDia > 0) {
      partes.push(`$ ${formatoTarifa(porDia)} por día`);
    }
    const tarifa = parseFloat(form.tarifa);
    const anticipo = parseFloat(form.anticipo) || 0;
    if (Number.isFinite(tarifa)) {
      partes.push(`saldo $ ${formatoTarifa(Math.max(tarifa - anticipo, 0))}`);
    }
    return partes.join(" · ");
  }, [form, dias]);

  // ── Desglose de impuestos en vivo ──
  const desglose = useMemo(() => {
    const tarifa = parseFloat(form.tarifa);
    if (!form.impuestosTipo || !Number.isFinite(tarifa) || tarifa <= 0) return null;
    return {
      tipo: form.impuestosTipo,
      ...calcularImpuestos(tarifa, form.impuestosTipo),
    };
  }, [form.impuestosTipo, form.tarifa]);

  const alternarImpuestos = (t: ImpuestosTipo) =>
    setForm((f) => ({
      ...f,
      impuestosTipo: f.impuestosTipo === t ? "" : t,
    }));

  // ── Equipo: edición línea por línea ──
  const cambiarLinea = (i: number, cambios: Partial<LineaEquipo>) =>
    setForm((f) => ({
      ...f,
      equipo: f.equipo.map((l, j) => (i === j ? { ...l, ...cambios } : l)),
    }));

  const quitarLinea = (i: number) =>
    setForm((f) => ({ ...f, equipo: f.equipo.filter((_, j) => j !== i) }));

  const alternarEnCotizacion = (i: number) =>
    setForm((f) => ({
      ...f,
      equipo: f.equipo.map((l, j) =>
        i === j ? { ...l, enCotizacion: !l.enCotizacion } : l
      ),
    }));

  const agregarPreset = (p: PresetEquipo) =>
    setForm((f) => {
      const existente = f.equipo.find(
        (l) => l.nombre.trim().toLowerCase() === p.linea.nombre.toLowerCase()
      );
      // Ya está en la lista: suma una cantidad más en vez de duplicarla
      // (receptores de 20 en 20, bodies y cabinas de uno en uno).
      if (existente) {
        return {
          ...f,
          equipo: f.equipo.map((l) =>
            l === existente ? { ...l, cantidad: l.cantidad + p.paso } : l
          ),
        };
      }
      if (f.equipo.length >= MAX_LINEAS_EQUIPO) return f;
      return { ...f, equipo: [...f.equipo, { ...p.linea }] };
    });

  // Vista previa del equipo: qué viaja al PDF y cuánto dinero suma.
  const previaEquipo = useMemo(() => {
    const conNombre = form.equipo.filter((l) => l.nombre.trim() !== "");
    const alPdf = conNombre.filter((l) => l.enCotizacion);
    const interno = conNombre.filter((l) => !l.enCotizacion);
    const costo = form.equipo.reduce(
      (suma, l) => suma + (l.precio ?? 0) * l.cantidad,
      0
    );
    return { alPdf, interno, costo };
  }, [form.equipo]);

  const guardar = async () => {
    setError("");
    if (!form.cliente.trim()) {
      setError("El cliente o empresa es el único campo obligatorio junto con la tarifa.");
      return;
    }
    const tarifa = form.tarifa.trim() === "" ? 0 : parseFloat(form.tarifa);
    if (!Number.isFinite(tarifa) || tarifa < 0) {
      setError("La tarifa debe ser un número (puede ser 0 si aún no la defines).");
      return;
    }

    setEnviando(true);
    try {
      const res = await fetch(
        esEdicion ? `/api/eventos/${evento!.id}` : "/api/eventos",
        {
          method: esEdicion ? "PUT" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            cliente: form.cliente,
            contacto: form.contacto || null,
            telefono: form.telefono || null,
            correo: form.correo || null,
            idiomas: form.idiomas || null,
            tema: form.tema || null,
            modalidad: form.modalidad,
            ciudad: form.modalidad === "FORANEO" ? form.ciudad || null : null,
            estatus: form.estatus,
            // El motivo de cancelación se captura al cancelar (en la tarjeta);
            // al editar se conserva el que ya estaba guardado.
            razonCancelacion: evento?.razonCancelacion ?? null,
            fechaInicio: form.fechaInicio || null,
            fechaFin: form.fechaFin || form.fechaInicio || null,
            horaInicio: form.horaInicio || null,
            horaFin: form.horaFin || null,
            tarifa,
            tarifaPorDia:
              form.tarifaPorDia.trim() === "" ? null : parseFloat(form.tarifaPorDia) || null,
            impuestosTipo: form.impuestosTipo || null,
            anticipo: form.anticipo.trim() === "" ? 0 : parseFloat(form.anticipo) || 0,
            fechaLimitePago: form.fechaLimitePago || null,
            linkGlosario: form.linkGlosario || null,
            notas: form.notas || null,
            equipo: form.equipo,
          }),
        }
      );
      if (!res.ok) throw new Error("respuesta no ok");
      const dato: EventoDTO = await res.json();
      if (esEdicion) {
        onEditado?.(dato);
      } else {
        onCreado?.(dato);
        setForm(VACIO);
      }
      setAbierto(false);
      toast({
        title: esEdicion ? "Cambios guardados" : "Evento registrado",
        description: esEdicion
          ? `${dato.cliente} quedó actualizado.`
          : `${dato.cliente} quedó en tu registro.`,
      });
    } catch {
      toast({
        title: "No se pudo guardar",
        description: "Revisa tu conexión e inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setEnviando(false);
    }
  };

  return (
    <Dialog open={abierto} onOpenChange={setAbierto}>
      <DialogTrigger asChild>
        {esEdicion ? (
          <button
            type="button"
            aria-label={`Editar evento — ${evento!.cliente}`}
            title="Editar evento"
            className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-tinta-muda transition-colors hover:bg-acento/10 hover:text-acento-claro"
          >
            <Pencil className="h-3.5 w-3.5" aria-hidden />
          </button>
        ) : (
          <Button className="h-10 rounded-lg bg-acento px-4 text-sm font-semibold text-acento-tinta transition-colors hover:bg-acento-claro">
            <Plus className="h-4 w-4" aria-hidden />
            Nuevo evento
          </Button>
        )}
      </DialogTrigger>

      <DialogContent
        style={SUPERFICIE_TARJETA}
        className="max-h-[88vh] overflow-y-auto radio-tarjeta border-linea-fuerte bg-tarjeta-baja text-tinta-suave sm:max-w-lg"
      >
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-tinta">
            {esEdicion ? "Editar evento" : "Nuevo evento"}
          </DialogTitle>
          <DialogDescription className="text-xs text-tinta-muda">
            {esEdicion ? (
              <>
                Actualiza lo que necesites — tarifas, nombres, horarios… el resto
                de la tarjeta se recalcula solo.
                {evento!.idEvento ? (
                  <>
                    {" "}
                    Código:{" "}
                    <span className="font-mono text-tinta-suave">
                      {evento!.idEvento}
                    </span>
                  </>
                ) : null}
              </>
            ) : (
              <>
                Solo <span className="text-tinta-suave">cliente</span> y{" "}
                <span className="text-tinta-suave">tarifa</span> son obligatorios.
                Todo lo demás lo puedes dejar vacío y completar después.
              </>
            )}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5">
          {/* ── Cliente ── */}
          <section className="space-y-3">
            <p className={SECCION}>Cliente</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1.5 sm:col-span-2">
                <label className={ETIQUETA} htmlFor="f-cliente">
                  Cliente / Empresa <span className="text-acento">*</span>
                </label>
                <Input
                  id="f-cliente"
                  value={form.cliente}
                  onChange={(e) => set("cliente")(e.target.value)}
                  placeholder="AdWeek, Grupo Balanca…"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-contacto">
                  Nombre del contacto
                </label>
                <Input
                  id="f-contacto"
                  value={form.contacto}
                  onChange={(e) => set("contacto")(e.target.value)}
                  placeholder="Ana María Tlatolli"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-tel">
                  Teléfono (WhatsApp)
                </label>
                <Input
                  id="f-tel"
                  type="tel"
                  inputMode="numeric"
                  value={form.telefono}
                  onChange={(e) => set("telefono")(e.target.value)}
                  placeholder="5636020401"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <label className={ETIQUETA} htmlFor="f-correo">
                  Correo del contacto
                </label>
                <Input
                  id="f-correo"
                  type="email"
                  value={form.correo}
                  onChange={(e) => set("correo")(e.target.value)}
                  placeholder="contacto@empresa.com"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
            </div>
          </section>

          {/* ── Evento ── */}
          <section className="space-y-3">
            <p className={SECCION}>El evento</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <label className={ETIQUETA}>Idiomas</label>
                <Select
                  value={form.idiomas || "SIN-DEFINIR"}
                  onValueChange={(v) => set("idiomas")(v === "SIN-DEFINIR" ? "" : v)}
                >
                  <SelectTrigger className="h-10 border-linea-fuerte bg-panel">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-linea-fuerte bg-tarjeta text-tinta-suave">
                    <SelectItem value="SIN-DEFINIR" className="focus:bg-panel">
                      Sin definir
                    </SelectItem>
                    {IDIOMAS_VALIDOS.map((i) => (
                      <SelectItem key={i} value={i} className="focus:bg-panel">
                        {i}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-tema">
                  Tema / Industria
                </label>
                <Input
                  id="f-tema"
                  value={form.tema}
                  onChange={(e) => set("tema")(e.target.value)}
                  placeholder="Marketing, legal, médico…"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA}>Modalidad</label>
                <Select
                  value={form.modalidad}
                  onValueChange={(v) => set("modalidad")(v as Modalidad)}
                >
                  <SelectTrigger className="h-10 border-linea-fuerte bg-panel">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-linea-fuerte bg-tarjeta text-tinta-suave">
                    {(Object.keys(MODALIDAD_CONFIG) as Modalidad[]).map((m) => (
                      <SelectItem key={m} value={m} className="focus:bg-panel">
                        {MODALIDAD_CONFIG[m].label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA}>Estatus</label>
                <Select value={form.estatus} onValueChange={(v) => set("estatus")(v as Estatus)}>
                  <SelectTrigger className="h-10 border-linea-fuerte bg-panel">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-linea-fuerte bg-tarjeta text-tinta-suave">
                    {ESTATUS_VALIDOS.map((e) => (
                      <SelectItem key={e} value={e} className="focus:bg-panel">
                        {ESTATUS_CONFIG[e].label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {form.modalidad === "FORANEO" ? (
                <div className="space-y-1.5 sm:col-span-2">
                  <label className={ETIQUETA} htmlFor="f-ciudad">
                    Ciudad
                  </label>
                  <Input
                    id="f-ciudad"
                    value={form.ciudad}
                    onChange={(e) => set("ciudad")(e.target.value)}
                    placeholder="Monterrey, León, Tijuana…"
                    className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                  />
                </div>
              ) : null}
            </div>
          </section>

          {/* ── Fechas y horario (calendario + reloj estilo WQZ) ── */}
          <section className="space-y-3">
            <p className={SECCION}>Fechas y horario</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-fechas">
                  Fechas
                </label>
                <button
                  id="f-fechas"
                  type="button"
                  aria-haspopup="dialog"
                  onClick={() => setCalAbierto(true)}
                  className="flex h-10 items-center gap-2 rounded-lg border border-linea-fuerte bg-panel px-3 text-left text-xs font-medium text-tinta-suave transition-colors hover:border-acento/30"
                >
                  <Calendar1 className="h-4 w-4 shrink-0 text-acento/70" aria-hidden />
                  <span className="min-w-0 flex-1 truncate text-tinta">
                    {resumenFechas}
                  </span>
                  <span aria-hidden className="text-acento">›</span>
                </button>
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-horario">
                  Horario
                </label>
                <button
                  id="f-horario"
                  type="button"
                  aria-haspopup="dialog"
                  onClick={() => setRelojAbierto(true)}
                  className="flex h-10 items-center gap-2 rounded-lg border border-linea-fuerte bg-panel px-3 text-left text-xs font-medium text-tinta-suave transition-colors hover:border-acento/30"
                >
                  <Clock className="h-4 w-4 shrink-0 text-acento/70" aria-hidden />
                  <span className="min-w-0 flex-1 truncate text-tinta">
                    {resumenHorario}
                  </span>
                  <span aria-hidden className="text-acento">›</span>
                </button>
              </div>
            </div>
            {calAbierto ? (
              <CalendarioRango
                abierto
                onCierra={() => setCalAbierto(false)}
                fechaInicio={form.fechaInicio}
                fechaFin={form.fechaFin}
                onCambia={(ini, fin) =>
                  setForm((f) =>
                    f.fechaInicio === ini && f.fechaFin === fin
                      ? f
                      : { ...f, fechaInicio: ini, fechaFin: fin }
                  )
                }
              />
            ) : null}
            {relojAbierto ? (
              <Reloj24
                abierto
                onCierra={() => setRelojAbierto(false)}
                horaInicio={form.horaInicio}
                horaFin={form.horaFin}
                onCambia={(hi, hf) =>
                  setForm((f) =>
                    f.horaInicio === hi && f.horaFin === hf
                      ? f
                      : { ...f, horaInicio: hi, horaFin: hf }
                  )
                }
              />
            ) : null}
          </section>

          {/* ── Equipo para el servicio ── */}
          <section className="space-y-3">
            <p className={SECCION}>Equipo para el servicio</p>
            <div className="flex flex-wrap gap-1.5">
              {PRESETS_EQUIPO.map((p) => (
                <button
                  key={p.linea.nombre}
                  type="button"
                  onClick={() => agregarPreset(p)}
                  className="inline-flex h-8 items-center gap-1 rounded-full border border-linea-fuerte px-3 text-[11px] font-medium text-tinta-suave transition-colors hover:border-acento/40 hover:text-acento-claro"
                >
                  <Plus className="h-3 w-3" aria-hidden />
                  {p.label}
                </button>
              ))}
            </div>

            {form.equipo.length === 0 ? (
              <p className="text-[11px] leading-relaxed text-tinta-muda">
                Lo que el evento necesita: cabina, receptores, bodies… Cada línea
                puede llevar precio (se suma en la cotización) y puedes decidir
                cuál viaja al PDF y cuál queda sólo en el panel.
              </p>
            ) : (
              <div className="space-y-2">
                <div className={`${GRID_LINEA} px-0.5 text-[10px] font-medium uppercase tracking-wide text-tinta-muda`}>
                  <span>Artículo</span>
                  <span className="text-center">Cant.</span>
                  <span className="text-right">Precio/u</span>
                  <span className="text-center">PDF</span>
                  <span aria-hidden />
                </div>
                {form.equipo.map((l, i) => (
                  <div key={i} className={GRID_LINEA}>
                    <Input
                      value={l.nombre}
                      onChange={(e) => cambiarLinea(i, { nombre: e.target.value })}
                      placeholder="Receptores, media cabina, body…"
                      className="h-9 border-linea-fuerte bg-panel text-xs placeholder:text-tinta-muda"
                      aria-label={`Artículo de equipo ${i + 1}`}
                    />
                    <Input
                      type="number"
                      min={1}
                      value={l.cantidad}
                      onChange={(e) =>
                        cambiarLinea(i, {
                          cantidad: Math.max(1, parseInt(e.target.value, 10) || 1),
                        })
                      }
                      className="h-9 border-linea-fuerte bg-panel px-1.5 text-center text-xs"
                      aria-label={`Cantidad de ${l.nombre || "equipo"}`}
                    />
                    <Input
                      type="number"
                      min={0}
                      value={l.precio ?? ""}
                      onChange={(e) =>
                        cambiarLinea(i, {
                          precio:
                            e.target.value === "" ? null : Math.max(0, parseFloat(e.target.value) || 0),
                        })
                      }
                      placeholder="incluido"
                      className="h-9 border-linea-fuerte bg-panel px-1.5 text-right text-xs placeholder:text-tinta-muda"
                      aria-label={`Precio unitario de ${l.nombre || "equipo"}`}
                    />
                    <button
                      type="button"
                      onClick={() => alternarEnCotizacion(i)}
                      aria-pressed={l.enCotizacion}
                      title={
                        l.enCotizacion
                          ? "Va a la cotización — tócala para dejarla sólo en el panel"
                          : "Sólo para el panel — tócala para que vaya a la cotización"
                      }
                      aria-label={
                        l.enCotizacion
                          ? `Quitar «${l.nombre}» de la cotización`
                          : `Enviar «${l.nombre}» a la cotización`
                      }
                      className={`inline-flex h-9 w-[34px] items-center justify-center rounded-lg border transition-colors ${
                        l.enCotizacion
                          ? "border-acento/40 bg-acento/10 text-acento-claro"
                          : "border-linea-fuerte text-tinta-muda hover:text-tinta-suave"
                      }`}
                    >
                      {l.enCotizacion ? (
                        <FileText className="h-3.5 w-3.5" aria-hidden />
                      ) : (
                        <EyeOff className="h-3.5 w-3.5" aria-hidden />
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => quitarLinea(i)}
                      aria-label={`Quitar ${l.nombre || "línea"} del equipo`}
                      title="Quitar del equipo"
                      className="inline-flex h-9 w-[30px] items-center justify-center rounded-lg text-tinta-muda transition-colors hover:bg-peligro/10 hover:text-peligro"
                    >
                      <X className="h-3.5 w-3.5" aria-hidden />
                    </button>
                  </div>
                ))}

                <p className="rounded-lg border border-linea-fuerte bg-panel px-3 py-2 text-[11px] leading-relaxed text-tinta-muda">
                  {previaEquipo.alPdf.length > 0 ? (
                    <>
                      Va a la cotización:{" "}
                      <span className="text-acento-claro">
                        {resumenEquipo(previaEquipo.alPdf, 4)}
                      </span>
                      {previaEquipo.interno.length > 0 ? (
                        <>
                          {" "}· sólo panel:{" "}
                          <span className="text-tinta-suave">
                            {resumenEquipo(previaEquipo.interno, 3)}
                          </span>
                        </>
                      ) : null}
                    </>
                  ) : (
                    <>
                      Nada de este equipo va a la cotización — todo queda como
                      logística interna del panel.
                    </>
                  )}
                  {previaEquipo.costo > 0 ? (
                    <>
                      {" "}· costo del equipo{" "}
                      <span className="text-acento-claro">
                        $ {formatoTarifa(previaEquipo.costo)}
                      </span>{" "}
                      (se suma a la tarifa en el PDF)
                    </>
                  ) : null}
                </p>
              </div>
            )}
          </section>

          {/* ── Dinero ── */}
          <section className="space-y-3">
            <p className={SECCION}>Dinero (MXN)</p>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-pordia">
                  Tarifa por día (opcional)
                </label>
                <Input
                  id="f-pordia"
                  type="number"
                  inputMode="numeric"
                  min="0"
                  value={form.tarifaPorDia}
                  onChange={(e) => set("tarifaPorDia")(e.target.value)}
                  placeholder="3500"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-tarifa">
                  Tarifa total <span className="text-acento">*</span>
                </label>
                <Input
                  id="f-tarifa"
                  type="number"
                  inputMode="numeric"
                  min="0"
                  value={form.tarifa}
                  onChange={(e) => set("tarifa")(e.target.value)}
                  placeholder="4500"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-anticipo">
                  Anticipo pagado
                </label>
                <Input
                  id="f-anticipo"
                  type="number"
                  inputMode="numeric"
                  min="0"
                  value={form.anticipo}
                  onChange={(e) => set("anticipo")(e.target.value)}
                  placeholder="0"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-limite">
                  Fecha límite de pago
                </label>
                <Input
                  id="f-limite"
                  type="date"
                  value={form.fechaLimitePago}
                  onChange={(e) => set("fechaLimitePago")(e.target.value)}
                  className="h-10 border-linea-fuerte bg-panel"
                />
              </div>
            </div>

            {/* Impuestos opcionales */}
            <div className="space-y-1.5">
              <p className={ETIQUETA}>Impuestos (opcional)</p>
              <div className="grid grid-cols-2 gap-2">
                {(Object.keys(IMPUESTOS_CONFIG) as ImpuestosTipo[]).map((t) => {
                  const activo = form.impuestosTipo === t;
                  return (
                    <button
                      key={t}
                      type="button"
                      aria-pressed={activo}
                      onClick={() => alternarImpuestos(t)}
                      title={IMPUESTOS_CONFIG[t].detalle}
                      className={`inline-flex h-10 items-center justify-center gap-1.5 rounded-full border px-3 text-[11px] font-medium transition-colors ${
                        activo
                          ? "border-acento/40 bg-acento/10 text-acento-claro"
                          : "border-linea-fuerte text-tinta-suave hover:border-linea-hover hover:text-tinta"
                      }`}
                    >
                      {IMPUESTOS_CONFIG[t].corto}
                    </button>
                  );
                })}
              </div>
              <p className="text-[10px] leading-relaxed text-tinta-muda">
                {form.impuestosTipo
                  ? IMPUESTOS_CONFIG[form.impuestosTipo].detalle
                  : "Tócalos para calcular el desglose. Persona moral: retiene IVA e ISR · FAE: solo IVA."}
              </p>
            </div>

            {desglose ? (
              <div className="rounded-lg border border-linea-fuerte bg-panel px-3 py-2.5 text-[11px] leading-relaxed text-tinta-muda">
                <p>
                  <span className="text-acento-claro">Factura:</span>{" "}
                  $ {formatoDinero(desglose.factura)}{" "}
                  <span className="text-tinta-muda">
                    (tarifa + IVA 16% de $ {formatoDinero(desglose.iva)})
                  </span>
                </p>
                {desglose.tipo === "MORAL" ? (
                  <>
                    <p>
                      Retenciones: IVA −$ {formatoDinero(desglose.retIva)} · ISR −${" "}
                      {formatoDinero(desglose.retIsr)}
                    </p>
                    <p>
                      <span className="text-acento-claro">Neto a recibir:</span>{" "}
                      $ {formatoDinero(desglose.neto)}
                    </p>
                  </>
                ) : (
                  <p>
                    <span className="text-acento-claro">Neto a recibir:</span>{" "}
                    $ {formatoDinero(desglose.neto)} — sin retenciones
                  </p>
                )}
              </div>
            ) : null}
          </section>

          {/* ── Notas y glosario ── */}
          <section className="space-y-3">
            <p className={SECCION}>Notas y glosario</p>
            <div className="space-y-1.5">
              <label className={ETIQUETA} htmlFor="f-glos">
                Link a glosario (opcional)
              </label>
              <Input
                id="f-glos"
                value={form.linkGlosario}
                onChange={(e) => set("linkGlosario")(e.target.value)}
                placeholder="https://docs.google.com/…"
                className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
              />
            </div>
            <Textarea
              value={form.notas}
              onChange={(e) => set("notas")(e.target.value)}
              placeholder="Dress code, equipo de cabina, contactos alternos…"
              rows={2}
              className="border-linea-fuerte bg-panel placeholder:text-tinta-muda"
            />
          </section>

          {previa ? (
            <p className="rounded-lg border border-linea-fuerte bg-panel px-3 py-2 text-[11px] text-tinta-muda">
              Se calculará automáticamente:{" "}
              <span className="text-acento-claro">{previa}</span>
            </p>
          ) : null}

          {error ? <p className="text-xs text-peligro">{error}</p> : null}

          <div className="flex gap-2 pt-1">
            <Button
              onClick={guardar}
              disabled={enviando}
              className="h-11 flex-1 rounded-lg bg-acento text-sm font-semibold text-acento-tinta hover:bg-acento-claro"
            >
              {enviando ? "Guardando…" : esEdicion ? "Guardar cambios" : "Guardar evento"}
            </Button>
            <Button
              variant="outline"
              onClick={() => setAbierto(false)}
              className="h-11 rounded-lg border-linea-fuerte bg-tarjeta text-tinta-suave hover:text-tinta"
            >
              Cancelar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
