"use client";

import { useEffect, useRef, type ReactNode } from "react";
import { X } from "lucide-react";
import { SUPERFICIE_TARJETA } from "@/lib/temas";

interface Props {
  titulo: string;
  abierto: boolean;
  onCierra: () => void;
  onListo?: () => void;
  textoListo?: string;
  children: ReactNode;
}

/**
 * Pop-up de selección (estilo WQZ) que vive DENTRO del diálogo del
 * formulario: capa fija que cubre todo, tarjeta centrada (hoja inferior
 * en móvil) y cierre por ✕, tocando fuera o "Listo". El foco entra a la
 * tarjeta al abrirse para que Escape cierre primero el pop-up — y no
 * el diálogo del formulario que está debajo.
 */
export default function PopElegir({
  titulo,
  abierto,
  onCierra,
  onListo,
  textoListo = "Listo",
  children,
}: Props) {
  const tarjetaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (abierto) {
      // El foco dentro de la tarjeta hace que Escape se detenga aquí.
      tarjetaRef.current?.focus({ preventScroll: true });
    }
  }, [abierto]);

  if (!abierto) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-end justify-center bg-black/55 backdrop-blur-[2px] sm:items-center sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label={titulo}
      onKeyDown={(e) => {
        if (e.key === "Escape") {
          e.stopPropagation();
          onCierra();
        }
      }}
    >
      <button
        type="button"
        aria-label="Cerrar"
        tabIndex={-1}
        onClick={onCierra}
        className="absolute inset-0 cursor-default focus:outline-none"
      />
      <div
        ref={tarjetaRef}
        tabIndex={-1}
        style={SUPERFICIE_TARJETA}
        className="relative flex max-h-[88vh] w-full flex-col overflow-y-auto rounded-t-3xl border border-linea-fuerte bg-tarjeta p-4 outline-none sm:max-w-md sm:rounded-3xl sm:border"
      >
        <header className="flex items-center justify-between gap-3 pb-2">
          <p className="text-sm font-medium text-tinta">{titulo}</p>
          <button
            type="button"
            onClick={onCierra}
            aria-label="Cerrar"
            className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-tinta-muda transition-colors hover:bg-acento/10 hover:text-acento-claro"
          >
            <X className="h-4 w-4" aria-hidden />
          </button>
        </header>
        {children}
        {onListo ? (
          <button
            type="button"
            onClick={onListo}
            className="mt-3 inline-flex h-11 shrink-0 items-center justify-center rounded-xl bg-acento text-sm font-semibold text-acento-tinta transition-colors hover:bg-acento-claro"
          >
            {textoListo}
          </button>
        ) : null}
      </div>
    </div>
  );
}
