"use client";

import { useMemo, useRef, useState } from "react";
import PopElegir from "@/components/pop-elegir";

const CX = 115;
const CY = 115;
const R = 80;

/** Punto en el dial (12 al norte, giro horario, como el sitio WQZ). */
function pt(r: number, h: number): [number, number] {
  const a = (h * 15 + 90) * Math.PI / 180;
  return [CX + r * Math.cos(a), CY + r * Math.sin(a)];
}

/** "09:00" → 9; null si no calza. */
function horaNum(s: string | null): number | null {
  if (!s) return null;
  const m = /^(\d{1,2}):(\d{2})$/.exec(s);
  if (!m) return null;
  return +m[1] + +m[2] / 60;
}

function fmt(h: number): string {
  const H = Math.floor(h) % 24;
  const M = Math.round((h - Math.floor(h)) * 60);
  return `${String(H).padStart(2, "0")}:${String(M).padStart(2, "0")}`;
}

const clampIni = (ini: number, dur: number) =>
  Math.max(0, Math.min(ini, Math.max(0, 24 - dur)));

/* Duraciones rápidas (ronda 20): 1, 2, 4 y 8 — más "Día completo", que
   ignora las horas específicas. Esta opción vive SOLO en el CDM: el sitio
   WQZ nunca la ofrece. */
const PRESETES: { h: number; label: string }[] = [
  { h: 1, label: "1 hora" },
  { h: 2, label: "2 horas" },
  { h: 4, label: "4 horas" },
  { h: 8, label: "8 horas" },
];

/* Las 24 marcas del dial (nada queda fuera: sin bloqueo de madrugada). */
const TICS = Array.from({ length: 24 }, (_, h) => {
  const a = (h * 15 + 90) * Math.PI / 180;
  const c = Math.cos(a);
  const s = Math.sin(a);
  const r2 = h % 6 === 0 ? 96 : 93;
  return {
    h,
    mayor: h % 6 === 0,
    x1: (115 + 88 * c).toFixed(2),
    y1: (115 + 88 * s).toFixed(2),
    x2: (115 + r2 * c).toFixed(2),
    y2: (115 + r2 * s).toFixed(2),
  };
});

interface Props {
  abierto: boolean;
  onCierra: () => void;
  horaInicio: string; // "09:00" | ""
  horaFin: string; // "17:00" | ""
  diaCompleto: boolean; // jornada sin horas específicas
  onCambia: (inicio: string, fin: string, completo: boolean) => void;
}

/**
 * El reloj de 24 horas del Centro de Mando (ronda 20, recalibrado):
 *
 *   · La barra es gruesa y se agarra en CUALQUIER punto de su recorrido —
 *     no sólo en la punta. El mango de la punta sigue marcando la hora
 *     de inicio, como siempre.
 *   · Un clic sobre una hora NO seleccionada mueve el arco rápido hasta
 *     ella (movimientos grandes: de la mañana a la tarde).
 *   · Deslizar el arco (desde donde se agarre) es el ajuste fino (de
 *     8:00 a 8:30). El arco mide EXACTAMENTE la jornada elegida.
 *   · "Día completo" ignora las horas: jornada sin horario específico
 *     (sólo el CDM; el sitio WQZ nunca la ofrece).
 *
 * 12 al norte; ninguna hora bloqueada: la madrugada también existe cuando
 * el evento la necesita.
 */
export default function Reloj24({
  abierto,
  onCierra,
  horaInicio,
  horaFin,
  diaCompleto,
  onCambia,
}: Props) {
  const reduce = useMemo(
    () =>
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches,
    []
  );

  const [completo, setCompleto] = useState(diaCompleto);
  const [disp, setDisp] = useState(() => {
    const i = horaNum(horaInicio);
    const f = horaNum(horaFin);
    if (i != null && f != null && f > i) return { ini: i, dur: f - i };
    if (i != null) return { ini: i, dur: 8 };
    return { ini: 9, dur: 8 }; // arranque amistoso: 09:00 – 17:00
  });
  const svgRef = useRef<SVGSVGElement>(null);
  const animRef = useRef(0);

  /* El gesto en curso: dónde se apretó, dónde estaba el arco y si el dedo
     ya se movió (para distinguir "toque seco" de "deslizamiento"). */
  const gesto = useRef<{ activo: boolean; h0: number; offset: number; movio: boolean }>({
    activo: false,
    h0: 0,
    offset: 0,
    movio: false,
  });

  const aplica = (ini: number, dur: number) => {
    const i = clampIni(ini, dur);
    setDisp({ ini: i, dur });
    onCambia(fmt(i), fmt(i + dur), false);
  };

  const poneCompleto = (valor: boolean) => {
    setCompleto(valor);
    if (valor) onCambia("", "", true);
    else onCambia(fmt(disp.ini), fmt(disp.ini + disp.dur), false);
  };

  /* El mango VIAJA con ease-out cúbico; reduce-motion = salto directo. */
  const animaHacia = (ini2: number, dur2: number) => {
    if (animRef.current) cancelAnimationFrame(animRef.current);
    const i0 = disp.ini;
    const d0 = disp.dur;
    const dist = Math.abs(ini2 - i0) + Math.abs(dur2 - d0);
    if (reduce || dist < 0.01) {
      aplica(ini2, dur2);
      return;
    }
    const DUR = 180 + 260 * Math.min(1, dist / 10);
    const t0 = performance.now();
    const paso = (t: number) => {
      const k = Math.min(1, (t - t0) / DUR);
      const e = 1 - Math.pow(1 - k, 3);
      aplica(i0 + (ini2 - i0) * e, d0 + (dur2 - d0) * e);
      animRef.current = k < 1 ? requestAnimationFrame(paso) : 0;
    };
    animRef.current = requestAnimationFrame(paso);
  };

  const horaDe = (e: React.PointerEvent): number | null => {
    const r = svgRef.current?.getBoundingClientRect();
    if (!r) return null;
    const dx = e.clientX - (r.left + r.width / 2);
    const dy = e.clientY - (r.top + r.height / 2);
    const rr = Math.hypot(dx, dy) / (r.width / 2);
    if (rr < 0.55 || rr > 1.42) return null; // centro y exterior: nada
    const phi = (Math.atan2(dy, dx) * 180) / Math.PI;
    const h = (((phi - 90) + 360) % 360) / 15;
    return Math.max(0, Math.min(23.5, Math.round(h * 2) / 2));
  };

  const baja = (e: React.PointerEvent) => {
    const h = horaDe(e);
    if (h === null) return;
    try {
      svgRef.current?.setPointerCapture?.(e.pointerId);
    } catch {
      /* captura no crítica */
    }
    if (animRef.current) cancelAnimationFrame(animRef.current);
    // Si venía "día completo", el primer gesto sobre el dial lo apaga y
    // coloca el arco donde se tocó.
    if (completo) {
      setCompleto(false);
      setDisp({ ini: clampIni(h, disp.dur), dur: disp.dur });
    }
    gesto.current = { activo: true, h0: h, offset: h - disp.ini, movio: false };
  };

  const mueve = (e: React.PointerEvent) => {
    if (!gesto.current.activo) return;
    const h = horaDe(e);
    if (h === null) return;
    if (Math.abs(h - gesto.current.h0) > 0.2) gesto.current.movio = true;
    // Deslizamiento: el arco viaja por su delta — fino y preciso, desde
    // cualquier punto donde se haya agarrado.
    aplica(h - gesto.current.offset, disp.dur);
  };

  const sube = (e: React.PointerEvent) => {
    if (!gesto.current.activo) return;
    const { h0, movio } = gesto.current;
    gesto.current.activo = false;
    if (movio) return;
    const h = horaDe(e) ?? h0;
    // Toque seco: sólo salta si cayó en una hora NO seleccionada.
    const { ini, dur } = disp;
    const dentro = ((h - ini + 24) % 24) <= dur || ((ini + dur - h) % 24) <= dur ? true : false;
    if (!dentro) animaHacia(h, dur);
  };

  /* ── El arco del reloj mide exactamente la jornada ── */
  const { ini, dur } = disp;
  const p1 = pt(R, ini);
  const p2 = pt(R, ini + dur);
  const arcoD =
    dur <= 0
      ? ""
      : `M ${p1[0].toFixed(2)} ${p1[1].toFixed(2)} A ${R} ${R} 0 ${
          dur > 12 ? 1 : 0
        } 1 ${p2[0].toFixed(2)} ${p2[1].toFixed(2)}`;
  const mango = pt(R, ini);

  return (
    <PopElegir titulo="Elige el horario" abierto={abierto} onCierra={onCierra} onListo={onCierra}>
      <div className="grid place-items-center py-1">
        <svg
          ref={svgRef}
          viewBox="0 0 230 230"
          className="h-56 w-56 touch-none select-none"
          role="img"
          aria-label={
            completo
              ? "Jornada de día completo"
              : `Horario elegido: de ${fmt(ini)} a ${fmt(ini + dur)}`
          }
          onPointerDown={baja}
          onPointerMove={mueve}
          onPointerUp={sube}
          onPointerCancel={() => {
            gesto.current.activo = false;
          }}
        >
          {/* pista completa: 24 horas, ninguna bloqueada */}
          <circle
            cx={CX}
            cy={CY}
            r={R}
            className="fill-none stroke-linea-suave"
            strokeWidth="4"
          />
          {/* resplandor del arco */}
          <path
            d={completo ? "" : arcoD}
            className="fill-none stroke-acento"
            strokeWidth="13"
            opacity=".35"
            filter="url(#brillo-reloj)"
          />
          <defs>
            <filter id="brillo-reloj" x="-40%" y="-20%" width="180%" height="140%">
              <feGaussianBlur stdDeviation="6" />
            </filter>
          </defs>
          {/* el arco: grueso, agarrable en toda su extensión */}
          {completo ? (
            <circle
              cx={CX}
              cy={CY}
              r={R}
              className="fill-none stroke-acento"
              strokeWidth="11"
              strokeLinecap="round"
              opacity=".75"
              strokeDasharray="0"
            />
          ) : (
            <path
              d={arcoD}
              className="fill-none stroke-acento"
              strokeWidth="11"
              strokeLinecap="round"
            />
          )}
          {/* 24 marcas horarias */}
          <g>
            {TICS.map((t) => (
              <line
                key={t.h}
                x1={t.x1}
                y1={t.y1}
                x2={t.x2}
                y2={t.y2}
                className={
                  t.mayor
                    ? "stroke-tinta-muda"
                    : "stroke-linea-fuerte"
                }
                strokeWidth={t.mayor ? 1.6 : 1}
                opacity={t.mayor ? 0.9 : 0.7}
              />
            ))}
          </g>
          {/* cardinales: 12 arriba, 00 abajo, 06 y 18 a los lados */}
          <text x="115" y="13" textAnchor="middle" className="fill-tinta-muda text-[10px] font-semibold">12</text>
          <text x="221" y="119" textAnchor="middle" className="fill-tinta-muda text-[10px] font-semibold">18</text>
          <text x="115" y="225" textAnchor="middle" className="fill-tinta-muda text-[10px] font-semibold">00</text>
          <text x="9" y="119" textAnchor="middle" className="fill-tinta-muda text-[10px] font-semibold">06</text>
          {/* punto del fin de jornada */}
          {!completo && dur > 0 ? (
            <circle
              cx={p2[0]}
              cy={p2[1]}
              r="5.4"
              className="fill-acento-claro"
            />
          ) : null}
          {/* el mango de la punta: marca la hora de inicio */}
          {!completo ? (
            <>
              <circle cx={mango[0]} cy={mango[1]} r="14" className="fill-acento" opacity=".22" />
              <circle cx={mango[0]} cy={mango[1]} r="9" className="fill-acento" />
              <circle cx={mango[0]} cy={mango[1]} r="3.4" className="fill-acento-tinta" />
            </>
          ) : null}
          {/* rango al centro */}
          <text
            x="115"
            y="121"
            textAnchor="middle"
            className="fill-tinta text-[13px] font-semibold"
          >
            {completo ? "Día completo" : `${fmt(ini)} – ${fmt(ini + dur)}`}
          </text>
          <text
            x="115"
            y="140"
            textAnchor="middle"
            className="fill-tinta-muda text-[9px]"
          >
            {completo
              ? "sin horas específicas"
              : `${dur % 1 === 0 ? dur : dur.toFixed(1)} ${dur === 1 ? "hora" : "horas"}`}
          </text>
        </svg>
      </div>

      {/* duraciones rápidas + día completo */}
      <div className="mt-2">
        <p className="text-[10px] font-medium uppercase tracking-[0.18em] text-acento/70">
          Duración
        </p>
        <div className="mt-1.5 flex flex-wrap justify-center gap-1.5">
          {PRESETES.map((p) => {
            const activo = !completo && Math.abs(dur - p.h) < 0.01;
            return (
              <button
                key={p.h}
                type="button"
                aria-pressed={activo}
                onClick={() => {
                  if (completo) {
                    setCompleto(false);
                  }
                  animaHacia(clampIni(ini, p.h), p.h);
                }}
                className={`inline-flex h-9 min-w-[76px] items-center justify-center rounded-full border text-[11px] font-medium transition-colors ${
                  activo
                    ? "border-acento/50 bg-acento/12 text-acento-claro"
                    : "border-linea-fuerte text-tinta-suave hover:border-acento/30 hover:text-tinta"
                }`}
              >
                {p.label}
              </button>
            );
          })}
          <button
            type="button"
            aria-pressed={completo}
            onClick={() => poneCompleto(!completo)}
            className={`inline-flex h-9 min-w-[76px] items-center justify-center rounded-full border text-[11px] font-medium transition-colors ${
              completo
                ? "border-acento/50 bg-acento/12 text-acento-claro"
                : "border-linea-fuerte text-tinta-suave hover:border-acento/30 hover:text-tinta"
            }`}
          >
            Día completo
          </button>
        </div>
        <p className="mt-2 text-center text-[11px] text-tinta-muda">
          Toca una hora libre para saltar · desliza el arco para afinar.
        </p>
      </div>
    </PopElegir>
  );
}
