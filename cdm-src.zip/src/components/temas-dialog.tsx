"use client";

// Galería de temas del Centro de Mando (ronda 20: compacta).
// Cuatro temas — obsidiana, runner, zia y aero — en fichas compactas:
// nombre, descripción, la paleta en puntos y "Aplicar". Sin miniaturas
// gigantes: el diálogo cabe de un vistazo y se elige más rápido.

import { useEffect, useState, type CSSProperties } from "react";
import { motion } from "framer-motion";
import { Check, Moon, Palette, Sun } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  aplicarTema,
  CLAVES_TEMA,
  ETIQUETA_FUENTE,
  SUPERFICIE_TARJETA,
  TEMAS,
  TEMA_DEFECTO,
  type Modo,
  type Tema,
} from "@/lib/temas";
import { useToast } from "@/hooks/use-toast";

function TarjetaTema({
  tema,
  modo,
  esActual,
  onAplicar,
}: {
  tema: Tema;
  modo: Modo;
  esActual: boolean;
  onAplicar: (tema: Tema, modo: Modo) => void;
}) {
  const paleta = tema[modo];
  const estilo = {
    ...(SUPERFICIE_TARJETA as Record<string, string>),
  } as CSSProperties;

  return (
    <div
      style={estilo}
      className="radio-tarjeta border border-linea-suave bg-tarjeta-baja p-3"
    >
      <div className="flex items-center justify-between gap-2">
        <p className="text-sm font-semibold text-tinta">{tema.nombre}</p>
        {esActual ? (
          <span className="inline-flex items-center gap-1 rounded-full border border-acento/40 bg-acento/10 px-2 py-0.5 text-[9px] font-medium text-acento-claro">
            <Check className="h-2.5 w-2.5" aria-hidden />
            En uso
          </span>
        ) : null}
      </div>
      <p className="mt-1 text-[11px] leading-relaxed text-tinta-muda">
        {tema.descripcion}
      </p>
      <div className="mt-2 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          {[paleta.fondo, paleta.tarjeta, paleta.acento, paleta.acentoClaro, paleta.tinta].map(
            (c, i) => (
              <span
                key={`muestra-${i}`}
                className="h-3.5 w-3.5 rounded-full border border-linea-fuerte"
                style={{ backgroundColor: c }}
              />
            )
          )}
        </div>
        <p className="text-[9px] font-medium uppercase tracking-[0.14em] text-acento/70">
          {ETIQUETA_FUENTE[paleta.fuente]}
        </p>
      </div>
      <Button
        onClick={() => onAplicar(tema, modo)}
        variant={esActual ? "outline" : "default"}
        disabled={esActual}
        className="mt-2.5 h-8 w-full rounded-lg text-[11px] font-semibold"
      >
        {esActual ? "Este es tu tema" : `Aplicar ${tema.nombre}`}
      </Button>
    </div>
  );
}

export default function TemasDialog() {
  const [abierto, setAbierto] = useState(false);
  // Elección guardada: al primer pintado (cocina y comedor por igual) se usa
  // el atuendo por defecto — así el HTML inicial siempre coincide y no hay
  // "hydration mismatch". Tras montar, un efecto lee la nevera del navegador
  // (localStorage) y se sincroniza con lo que el usuario había elegido.
  const [actual, setActual] = useState<{ id: string; modo: Modo }>({
    id: TEMA_DEFECTO,
    modo: "oscuro",
  });
  useEffect(() => {
    try {
      const id = localStorage.getItem(CLAVES_TEMA.tema) ?? TEMA_DEFECTO;
      const modo = (localStorage.getItem(CLAVES_TEMA.modo) as Modo | null) ?? "oscuro";
      setActual({ id, modo });
    } catch {
      // Nevera vacía o ilegible: se queda el atuendo por defecto.
    }
  }, []);
  const { toast } = useToast();

  const aplicar = (tema: Tema, modo: Modo) => {
    aplicarTema(tema.id, modo);
    setActual({ id: tema.id, modo });
    toast({
      title: "Tema aplicado",
      description: `${tema.nombre} · modo ${modo}. Puedes cambiarlo cuando quieras — nada más cambia.`,
    });
  };

  const cambiarModo = (modo: Modo) => {
    const tema = TEMAS.find((t) => t.id === actual.id) ?? TEMAS[0];
    aplicar(tema, modo);
  };

  return (
    <Dialog open={abierto} onOpenChange={setAbierto}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          className="h-10 gap-1.5 rounded-lg border-linea-fuerte bg-tarjeta px-3.5 text-xs font-medium text-tinta-suave hover:border-acento/40 hover:bg-tarjeta-baja hover:text-acento-claro"
        >
          <Palette className="h-3.5 w-3.5" aria-hidden />
          Temas
        </Button>
      </DialogTrigger>

      <DialogContent
        style={SUPERFICIE_TARJETA}
        className="max-h-[85vh] overflow-y-auto radio-tarjeta border-linea-fuerte bg-tarjeta-baja text-tinta-suave sm:max-w-md"
      >
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-tinta">
            El atuendo del Centro de Mando
          </DialogTitle>
          <DialogDescription className="text-xs leading-relaxed text-tinta-muda">
            Cuatro formas de vestir la misma app. Nada de cómo funciona cambia —
            solo la pintura de las paredes.
          </DialogDescription>

          {/* Modo: oscuro / claro */}
          <div
            role="tablist"
            aria-label="Modo de color"
            className="grid w-full max-w-52 grid-cols-2 rounded-full border border-linea-fuerte bg-panel p-1"
          >
            {(["oscuro", "claro"] as Modo[]).map((m) => (
              <button
                key={m}
                role="tab"
                aria-selected={actual.modo === m}
                onClick={() => cambiarModo(m)}
                className="relative inline-flex h-8 items-center justify-center rounded-full outline-none focus-visible:ring-1 focus-visible:ring-acento/50"
              >
                {actual.modo === m ? (
                  <motion.span
                    layoutId="indicador-modo"
                    transition={{ type: "spring", stiffness: 420, damping: 34 }}
                    aria-hidden
                    className="absolute inset-0 rounded-full border border-acento/40 bg-acento/12"
                  />
                ) : null}
                <span
                  className={`relative z-10 inline-flex items-center gap-1.5 text-xs font-medium transition-colors ${
                    actual.modo === m ? "text-acento-claro" : "text-tinta-muda"
                  }`}
                >
                  {m === "oscuro" ? (
                    <Moon className="h-3 w-3" aria-hidden />
                  ) : (
                    <Sun className="h-3 w-3" aria-hidden />
                  )}
                  {m === "oscuro" ? "Oscuro" : "Claro"}
                </span>
              </button>
            ))}
          </div>
        </DialogHeader>

        <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
          {TEMAS.map((t) => (
            <TarjetaTema
              key={t.id}
              tema={t}
              modo={actual.modo}
              esActual={t.id === actual.id}
              onAplicar={aplicar}
            />
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
