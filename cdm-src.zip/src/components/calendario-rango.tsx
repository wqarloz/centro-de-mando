"use client";

import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import PopElegir from "@/components/pop-elegir";
import { resumenFechas } from "@/lib/estatus";

const MESES = [
  "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
  "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre",
];
const SEMANA = ["L", "M", "X", "J", "V", "S", "D"];

const iso = (y: number, m: number, d: number) =>
  `${y}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;

const fechaDe = (s: string) => {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d, 12);
};

interface Props {
  abierto: boolean;
  onCierra: () => void;
  fechas: string[]; // días ISO elegidos (dispersos ok)
  onCambia: (fechas: string[]) => void;
}

/**
 * El calendario del Centro de Mando (ronda 20): los días se eligen uno por
 * uno o por arrastre. Un toque elige/quita un día suelto; deslizar el dedo
 * pinta de un jalón todo lo que atraviesa (semana entera, tres semanas…),
 * y cualquier día pintado se quita con otro toque. Así se puede tomar un
 * mes de lunes a viernes y retirar los fines de semana si no se trabajan.
 *
 * El arrastre cruza celdas con hit-testing (elementFromPoint): funciona
 * igual con dedo táctil que con ratón. El pasado también se elige — los
 * eventos ya trabajados se registran igual.
 */
export default function CalendarioRango({
  abierto,
  onCierra,
  fechas,
  onCambia,
}: Props) {
  const [hoyISO] = useState(() => {
    const n = new Date();
    return iso(n.getFullYear(), n.getMonth(), n.getDate());
  });

  /* El componente se monta al abrirse el pop-up: estos valores nacen
     ya sincronizados con el evento (o con el mes en curso). */
  const [vista, setVista] = useState(() => {
    const base = fechas.length > 0 ? fechaDe(fechas[0]) : fechaDe(hoyISO);
    return { y: base.getFullYear(), m: base.getMonth() };
  });
  const [sel, setSel] = useState<string[]>(() => [...fechas].sort());

  /* Todo cambio se comunica en vivo (como el reloj). */
  useEffect(() => {
    onCambia(sel);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sel]);

  /* Arrastre: al apretar un día se recuerda la celda; si el dedo se mueve,
     todo lo que atraviesa se PINTA (se elige). Si no se movió, el toque
     activa/desactiva ese día suelto. */
  const arrastra = useRef<{ activo: boolean; ancla: string; movio: boolean }>({
    activo: false,
    ancla: "",
    movio: false,
  });
  const rejilla = useRef<HTMLDivElement>(null);

  const pinta = (k: string) => {
    setSel((s) => (s.includes(k) ? s : [...s, k].sort()));
  };

  /** ¿Qué celda de día está bajo el puntero? null si ninguna. */
  const celdaEn = (x: number, y: number): string | null => {
    const el = document.elementFromPoint(x, y);
    const boton = el?.closest?.("[data-iso]") as HTMLElement | null;
    return boton?.dataset.iso ?? null;
  };

  const baja = (e: React.PointerEvent) => {
    const k = celdaEn(e.clientX, e.clientY);
    if (!k) return;
    arrastra.current = { activo: true, ancla: k, movio: false };
    try {
      rejilla.current?.setPointerCapture?.(e.pointerId);
    } catch {
      /* captura no crítica */
    }
  };

  const mueve = (e: React.PointerEvent) => {
    if (!arrastra.current.activo) return;
    const k = celdaEn(e.clientX, e.clientY);
    if (!k) return;
    if (k !== arrastra.current.ancla) arrastra.current.movio = true;
    pinta(k);
  };

  const sube = (e: React.PointerEvent) => {
    if (!arrastra.current.activo) return;
    const { ancla, movio } = arrastra.current;
    arrastra.current.activo = false;
    const k = celdaEn(e.clientX, e.clientY);
    if (!movio && k === ancla) {
      // Toque seco sobre un día: alterna.
      setSel((s) =>
        s.includes(k) ? s.filter((x) => x !== k) : [...s, k].sort()
      );
    }
  };

  /* La cuadrícula del mes en vista */
  const offset = (new Date(vista.y, vista.m, 1).getDay() + 6) % 7;
  const nDias = new Date(vista.y, vista.m + 1, 0).getDate();
  const celdas: (string | null)[] = [
    ...Array.from({ length: offset }, () => null),
    ...Array.from({ length: nDias }, (_, i) => iso(vista.y, vista.m, i + 1)),
  ];

  const diasTxt =
    sel.length > 0
      ? `${resumenFechas(sel)} · ${sel.length} ${sel.length === 1 ? "día" : "días"}`
      : "Sin fechas todavía";

  return (
    <PopElegir titulo="Elige las fechas" abierto={abierto} onCierra={onCierra} onListo={onCierra}>
      <div className="rounded-xl border border-linea-suave bg-panel p-2.5">
        <header className="flex items-center justify-between gap-2 pb-2">
          <button
            type="button"
            aria-label="Mes anterior"
            onClick={() =>
              setVista((v) =>
                v.m === 0 ? { y: v.y - 1, m: 11 } : { y: v.y, m: v.m - 1 }
              )
            }
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-acento transition-colors hover:bg-acento/10"
          >
            <ChevronLeft className="h-4 w-4" aria-hidden />
          </button>
          <p className="text-[13px] font-medium text-tinta">
            {MESES[vista.m]} {vista.y}
          </p>
          <button
            type="button"
            aria-label="Mes siguiente"
            onClick={() =>
              setVista((v) =>
                v.m === 11 ? { y: v.y + 1, m: 0 } : { y: v.y, m: v.m + 1 }
              )
            }
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-acento transition-colors hover:bg-acento/10"
          >
            <ChevronRight className="h-4 w-4" aria-hidden />
          </button>
        </header>
        <div className="grid grid-cols-7 gap-1 pb-1">
          {SEMANA.map((d, i) => (
            <span
              key={`${d}-${i}`}
              className="text-center text-[9px] font-semibold uppercase tracking-wider text-tinta-muda"
            >
              {d}
            </span>
          ))}
        </div>
        <div
          ref={rejilla}
          className="grid touch-none select-none grid-cols-7 gap-1"
          onPointerDown={baja}
          onPointerMove={mueve}
          onPointerUp={sube}
          onPointerCancel={() => {
            arrastra.current.activo = false;
          }}
        >
          {celdas.map((k, i) =>
            k === null ? (
              <span key={`v-${i}`} className="h-9" />
            ) : (
              <button
                key={k}
                type="button"
                data-iso={k}
                aria-pressed={sel.includes(k)}
                aria-label={`${new Date(
                  k + "T12:00:00"
                ).getDate()} de ${MESES[new Date(k + "T12:00:00").getMonth()]}`}
                className={`h-9 rounded-lg border text-xs font-medium transition-colors ${
                  sel.includes(k)
                    ? "border-acento/60 bg-acento/25 text-tinta"
                    : "border-transparent text-tinta-suave hover:border-acento/25 hover:bg-acento/8"
                } ${k === hoyISO ? "ring-1 ring-acento/40" : ""}`}
              >
                {new Date(k + "T12:00:00").getDate()}
              </button>
            )
          )}
        </div>
      </div>

      <div className="mt-3 flex items-center justify-center">
        <p className="text-[11px] text-tinta-muda">{diasTxt}</p>
      </div>
      <p className="mt-1 text-center text-[11px] text-tinta-muda">
        Toca para elegir un día · desliza para pintar varios.
      </p>
    </PopElegir>
  );
}
