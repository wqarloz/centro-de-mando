"use client";

import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import PopElegir from "@/components/pop-elegir";

const MESES = [
  "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
  "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre",
];
const SEMANA = ["L", "M", "X", "J", "V", "S", "D"];

const iso = (y: number, m: number, d: number) =>
  `${y}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;

const fechaDe = (s: string) => {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d, 12);
};

const diasEntre = (a: string, b: string) =>
  Math.round((fechaDe(b).getTime() - fechaDe(a).getTime()) / 86400000) + 1;

const rangoCorto = (ini: string, fin: string) => {
  const a = fechaDe(ini);
  const b = fechaDe(fin);
  const m = (d: Date) =>
    `${d.getDate()} ${MESES[d.getMonth()].slice(0, 3).toLowerCase()}.`;
  return a.getTime() === b.getTime()
    ? m(a)
    : `${a.getDate()}–${b.getDate()} ${MESES[b.getMonth()].slice(0, 3).toLowerCase()}.`;
};

interface Props {
  abierto: boolean;
  onCierra: () => void;
  fechaInicio: string; // "2026-11-12" | ""
  fechaFin: string; // "2026-11-15" | ""
  onCambia: (inicio: string, fin: string) => void;
}

/**
 * El calendario del sitio WQZ, trasladado al Centro de Mando con su
 * modelo de rango: un toque fija el inicio, el segundo (más tarde) fija
 * el fin y todo lo de enmedio queda pintado. A diferencia del sitio,
 * aquí el pasado también se elige: los eventos ya trabajados se
 * registran igual.
 */
export default function CalendarioRango({
  abierto,
  onCierra,
  fechaInicio,
  fechaFin,
  onCambia,
}: Props) {
  const [hoyISO] = useState(() => {
    const n = new Date();
    return iso(n.getFullYear(), n.getMonth(), n.getDate());
  });

  /* El componente se monta al abrirse el pop-up: estos valores nacen
     ya sincronizados con el evento (o con el mes en curso). */
  const [vista, setVista] = useState(() => {
    const base = fechaInicio ? fechaDe(fechaInicio) : fechaDe(hoyISO);
    return { y: base.getFullYear(), m: base.getMonth() };
  });
  const [sel, setSel] = useState({ ini: fechaInicio, fin: fechaFin });
  // Fase de selección: true = acabamos de fijar el inicio y esperamos el fin.
  // Si el rango ya está cerrado, cualquier toque EMPIEZA un rango nuevo:
  // así siempre se puede corregir sin batallar.
  const [esperandoFin, setEsperandoFin] = useState(false);

  const toca = (k: string) => {
    let nueva: { ini: string; fin: string };
    if (!sel.ini || !esperandoFin) {
      nueva = { ini: k, fin: k }; // empieza un rango nuevo en k
      setEsperandoFin(true);
    } else if (k < sel.ini) {
      nueva = { ini: k, fin: k }; // el fin quedó antes del inicio: reinicia
      setEsperandoFin(true);
    } else {
      nueva = { ini: sel.ini, fin: k }; // cierra el rango
      setEsperandoFin(false);
    }
    setSel(nueva);
    onCambia(nueva.ini, nueva.fin);
  };

  const quitar = () => {
    setSel({ ini: "", fin: "" });
    setEsperandoFin(false);
    onCambia("", "");
  };

  /* La cuadrícula del mes en vista */
  const offset = (new Date(vista.y, vista.m, 1).getDay() + 6) % 7;
  const nDias = new Date(vista.y, vista.m + 1, 0).getDate();
  const celdas: (string | null)[] = [
    ...Array.from({ length: offset }, () => null),
    ...Array.from({ length: nDias }, (_, i) => iso(vista.y, vista.m, i + 1)),
  ];

  const enRango = (k: string) =>
    sel.ini !== "" && sel.fin !== "" && k >= sel.ini && k <= sel.fin;
  const esPunta = (k: string) => sel.ini === k || (sel.fin !== "" && sel.fin === k);

  const diasTxt =
    sel.ini && sel.fin
      ? `${rangoCorto(sel.ini, sel.fin)} · ${diasEntre(sel.ini, sel.fin)} ${
          diasEntre(sel.ini, sel.fin) === 1 ? "día" : "días"
        }`
      : "Sin fechas todavía";

  return (
    <PopElegir titulo="Elige las fechas" abierto={abierto} onCierra={onCierra} onListo={onCierra}>
      <div className="rounded-xl border border-linea-suave bg-panel p-2.5">
        <header className="flex items-center justify-between gap-2 pb-2">
          <button
            type="button"
            aria-label="Mes anterior"
            onClick={() =>
              setVista((v) =>
                v.m === 0 ? { y: v.y - 1, m: 11 } : { y: v.y, m: v.m - 1 }
              )
            }
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-acento transition-colors hover:bg-acento/10"
          >
            <ChevronLeft className="h-4 w-4" aria-hidden />
          </button>
          <p className="text-[13px] font-medium text-tinta">
            {MESES[vista.m]} {vista.y}
          </p>
          <button
            type="button"
            aria-label="Mes siguiente"
            onClick={() =>
              setVista((v) =>
                v.m === 11 ? { y: v.y + 1, m: 0 } : { y: v.y, m: v.m + 1 }
              )
            }
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-acento transition-colors hover:bg-acento/10"
          >
            <ChevronRight className="h-4 w-4" aria-hidden />
          </button>
        </header>
        <div className="grid grid-cols-7 gap-1 pb-1">
          {SEMANA.map((d, i) => (
            <span
              key={`${d}-${i}`}
              className="text-center text-[9px] font-semibold uppercase tracking-wider text-tinta-muda"
            >
              {d}
            </span>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {celdas.map((k, i) =>
            k === null ? (
              <span key={`v-${i}`} className="h-9" />
            ) : (
              <button
                key={k}
                type="button"
                onClick={() => toca(k)}
                aria-pressed={esPunta(k)}
                aria-label={`${new Date(
                  k + "T12:00:00"
                ).getDate()} de ${MESES[new Date(k + "T12:00:00").getMonth()]}`}
                className={`h-9 rounded-lg border text-xs font-medium transition-colors ${
                  esPunta(k)
                    ? "border-acento/60 bg-acento/25 text-tinta"
                    : enRango(k)
                      ? "border-acento/20 bg-acento/10 text-tinta-suave"
                      : "border-transparent text-tinta-suave hover:border-acento/25 hover:bg-acento/8"
                } ${k === hoyISO ? "ring-1 ring-acento/40" : ""}`}
              >
                {new Date(k + "T12:00:00").getDate()}
              </button>
            )
          )}
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between gap-3">
        <p className="text-[11px] text-tinta-muda">{diasTxt}</p>
        {sel.ini ? (
          <button
            type="button"
            onClick={quitar}
            className="text-[11px] font-medium text-tinta-muda underline decoration-dotted underline-offset-2 transition-colors hover:text-peligro"
          >
            Quitar fechas
          </button>
        ) : null}
      </div>
      <p className="mt-1 text-center text-[11px] text-tinta-muda">
        Primer toque: inicio · segundo: fin. El pasado también se puede elegir.
      </p>
    </PopElegir>
  );
}
