"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Calendar1,
  Clock,
  Pencil,
  Plus,
  Users,
  X,
} from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import CalendarioRango from "@/components/calendario-rango";
import Reloj24 from "@/components/reloj-24";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  calcularImpuestos,
  ESTATUS_CONFIG,
  ESTATUS_VALIDOS,
  type EventoDTO,
  type Estatus,
  formatoDinero,
  formatoTarifa,
  IDIOMAS_VALIDOS,
  IMPUESTOS_CONFIG,
  type ImpuestosTipo,
  MAX_INTERPRETES_EXTRA,
  type Modalidad,
  MODALIDAD_CONFIG,
  type LineaEquipo,
  ORIGENES_VALIDOS,
  ORIGEN_CONFIG,
  resumenEquipo,
  resumenFechas,
  type InterpreteExtra,
} from "@/lib/estatus";
import { useToast } from "@/hooks/use-toast";
import { SUPERFICIE_TARJETA } from "@/lib/temas";

interface Props {
  /** Modo crear: avisa cuando un evento nuevo queda guardado. */
  onCreado?: (evento: EventoDTO) => void;
  /** Modo editar: el evento a precargar. */
  evento?: EventoDTO;
  /** Modo editar: avisa cuando los cambios quedan guardados. */
  onEditado?: (evento: EventoDTO) => void;
}

const SECCION = "text-[10px] font-medium uppercase tracking-[0.18em] text-acento/70";
const ETIQUETA = "text-xs font-medium text-tinta-suave";

// Botones de añadido rápido (ronda 20): los cuatro conceptos oficiales del
// negocio — Cabina, Media cabina, Receptores y Transmisores. Todos viajan a
// la cotización; el dueño pone el precio a cada uno cuando lo define.
type PresetEquipo = { label: string; linea: Omit<LineaEquipo, "enCotizacion"> };
const PRESETS_EQUIPO: PresetEquipo[] = [
  { label: "Cabina", linea: { nombre: "Cabina", cantidad: 1, precio: null } },
  { label: "Media cabina", linea: { nombre: "Media cabina", cantidad: 1, precio: null } },
  { label: "Receptores", linea: { nombre: "Receptores", cantidad: 40, precio: null } },
  { label: "Transmisores", linea: { nombre: "Transmisores", cantidad: 1, precio: null } },
];

// Columnas del editor de equipo: artículo · cantidad · precio · quitar.
// La cantidad viaja como texto: vacía vale 1 al guardar (ronda 20 — el
// campo ya no se traba en 1).
const GRID_LINEA = "grid grid-cols-[minmax(0,1fr)_58px_84px_30px] items-center gap-1.5";

type LineaFormEquipo = { nombre: string; cantidad: string; precio: string };
type InterpreteForm = { nombre: string; tarifa: string; viaticos: string };

type FormState = {
  cliente: string;
  contacto: string;
  telefono: string;
  correo: string;
  idiomas: string; // "" | "EN - ES" | "PO - ES"
  nombreEvento: string;
  tema: string;
  modalidad: Modalidad;
  ciudad: string;
  origen: string; // "" | DIRECTO | AGENCIA | COLEGA
  estatus: Estatus;
  fechas: string[]; // días ISO elegidos (dispersos ok)
  horaInicio: string;
  horaFin: string;
  diaCompleto: boolean;
  tarifaPorDia: string;
  tarifa: string;
  viaticos: string; // sólo foráneo
  impuestosTipo: "" | ImpuestosTipo;
  ivaEnCotizacion: boolean;
  interpretesExtra: InterpreteForm[];
  linkGlosario: string;
  notas: string;
  equipo: LineaFormEquipo[];
};

const VACIO: FormState = {
  cliente: "",
  contacto: "",
  telefono: "",
  correo: "",
  idiomas: "",
  nombreEvento: "",
  tema: "",
  modalidad: "PRESENCIAL_CDMX",
  ciudad: "",
  origen: "",
  estatus: "PROSPECTO",
  fechas: [],
  horaInicio: "",
  horaFin: "",
  diaCompleto: false,
  tarifaPorDia: "",
  tarifa: "",
  viaticos: "",
  impuestosTipo: "",
  ivaEnCotizacion: true,
  interpretesExtra: [],
  linkGlosario: "",
  notas: "",
  equipo: [],
};

/** Pasa de un evento guardado a los valores que muestran los inputs. */
function desdeEvento(e: EventoDTO): FormState {
  // Los eventos viejos traen inicio/fin contiguos; la lista de días
  // dispersos (ronda 20) manda cuando existe.
  const fechas = e.fechas.length > 0 ? [...e.fechas] : e.fechaInicio
    ? [
        format(new Date(e.fechaInicio), "yyyy-MM-dd"),
        ...(e.fechaFin && e.fechaFin !== e.fechaInicio
          ? rangoISO(
              format(new Date(e.fechaInicio), "yyyy-MM-dd"),
              format(new Date(e.fechaFin), "yyyy-MM-dd")
            )
          : []),
      ]
    : [];
  return {
    cliente: e.cliente,
    contacto: e.contacto ?? "",
    telefono: e.telefono ?? "",
    correo: e.correo ?? "",
    idiomas: (IDIOMAS_VALIDOS as readonly string[]).includes(e.idiomas ?? "")
      ? (e.idiomas as string)
      : "",
    nombreEvento: e.nombreEvento ?? "",
    tema: e.tema ?? "",
    modalidad: e.modalidad,
    ciudad: e.ciudad ?? "",
    origen: e.origen ?? "",
    estatus: e.estatus,
    fechas,
    horaInicio: e.horaInicio ?? "",
    horaFin: e.horaFin ?? "",
    diaCompleto: e.diaCompleto,
    tarifaPorDia: e.tarifaPorDia != null ? String(e.tarifaPorDia) : "",
    tarifa: e.tarifa != null ? String(e.tarifa) : "",
    viaticos: e.viaticos != null ? String(e.viaticos) : "",
    impuestosTipo: e.impuestosTipo ?? "",
    ivaEnCotizacion: e.ivaEnCotizacion,
    interpretesExtra: (e.interpretesExtra ?? []).map((i) => ({
      nombre: i.nombre,
      tarifa: i.tarifa != null ? String(i.tarifa) : "",
      viaticos: i.viaticos != null ? String(i.viaticos) : "",
    })),
    linkGlosario: e.linkGlosario ?? "",
    notas: e.notas ?? "",
    equipo: (e.equipo ?? []).map((l) => ({
      nombre: l.nombre,
      cantidad: String(l.cantidad),
      precio: l.precio != null ? String(l.precio) : "",
    })),
  };
}

/** Todos los días ISO entre dos fechas (inclusive). */
function rangoISO(ini: string, fin: string): string[] {
  const salida: string[] = [];
  const t0 = new Date(ini + "T12:00:00").getTime();
  const t1 = new Date(fin + "T12:00:00").getTime();
  if (t1 < t0) return [];
  for (let t = t0 + 86400000; t <= t1; t += 86400000) {
    salida.push(format(new Date(t), "yyyy-MM-dd"));
  }
  return salida;
}

export default function EventoForm({ onCreado, evento, onEditado }: Props) {
  const esEdicion = Boolean(evento);
  const [abierto, setAbierto] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState<FormState>(() =>
    evento ? desdeEvento(evento) : VACIO
  );
  const { toast } = useToast();

  // Si el evento cambia por fuera (edición o toque), el formulario se sincroniza.
  useEffect(() => {
    if (evento) setForm(desdeEvento(evento));
  }, [evento]);

  const set = (k: keyof FormState) => (v: string) =>
    setForm((f) => ({ ...f, [k]: v }));

  const dias = form.fechas.length;

  // ── Fechas y horario: pop-ups estilo WQZ (calendario y reloj) ──
  const [calAbierto, setCalAbierto] = useState(false);
  const [relojAbierto, setRelojAbierto] = useState(false);

  const resumenFechasTxt = useMemo(() => {
    if (dias === 0) return "Toca el calendario";
    return `${resumenFechas(form.fechas)} · ${dias} ${dias === 1 ? "día" : "días"}`;
  }, [form.fechas, dias]);

  const resumenHorario = useMemo(() => {
    if (form.diaCompleto) return "Día completo";
    if (!form.horaInicio || !form.horaFin) return "Toca el reloj";
    const [h1, m1] = form.horaInicio.split(":").map(Number);
    const [h2, m2] = form.horaFin.split(":").map(Number);
    const mins = h2 * 60 + m2 - (h1 * 60 + m1);
    if (mins <= 0) return form.horaInicio;
    return `${form.horaInicio} – ${form.horaFin} · ${
      mins % 60 === 0 ? `${Math.round(mins / 60)} h` : `${(mins / 60).toFixed(1)} h`
    }`;
  }, [form.horaInicio, form.horaFin, form.diaCompleto]);

  // ── Tarifa por día → total autocalculado ──
  useEffect(() => {
    const porDia = parseFloat(form.tarifaPorDia);
    if (Number.isFinite(porDia) && porDia > 0 && dias >= 1) {
      const total = porDia * dias;
      setForm((f) =>
        f.tarifa === String(total) ? f : { ...f, tarifa: String(total) }
      );
    }
  }, [form.tarifaPorDia, dias]);

  // Vista previa de lo que se calculará automáticamente
  const previa = useMemo(() => {
    const partes: string[] = [];
    if (dias > 0) partes.push(`${dias} ${dias === 1 ? "día" : "días"}`);
    if (form.diaCompleto) {
      partes.push("día completo");
    } else if (/^\d{1,2}:\d{2}$/.test(form.horaInicio) && /^\d{1,2}:\d{2}$/.test(form.horaFin)) {
      const [h1, m1] = form.horaInicio.split(":").map(Number);
      const [h2, m2] = form.horaFin.split(":").map(Number);
      const mins = h2 * 60 + m2 - (h1 * 60 + m1);
      if (mins > 0) {
        partes.push(
          mins >= 360 ? "Jornada Completa" : mins >= 180 ? "Medio Día" : "Por Hora"
        );
      }
    }
    const porDia = parseFloat(form.tarifaPorDia);
    if (Number.isFinite(porDia) && porDia > 0) {
      partes.push(`$ ${formatoTarifa(porDia)} por día`);
    }
    const tarifa = parseFloat(form.tarifa);
    if (Number.isFinite(tarifa)) {
      partes.push(`total $ ${formatoTarifa(tarifa)}`);
    }
    return partes.join(" · ");
  }, [form, dias]);

  // ── Desglose de impuestos en vivo ──
  const desglose = useMemo(() => {
    const tarifa = parseFloat(form.tarifa);
    if (!form.impuestosTipo || !Number.isFinite(tarifa) || tarifa <= 0) return null;
    return {
      tipo: form.impuestosTipo,
      ...calcularImpuestos(tarifa, form.impuestosTipo),
    };
  }, [form.impuestosTipo, form.tarifa]);

  const alternarImpuestos = (t: ImpuestosTipo) =>
    setForm((f) => ({
      ...f,
      impuestosTipo: f.impuestosTipo === t ? "" : t,
    }));

  // ── Equipo: edición línea por línea ──
  const cambiarLinea = (i: number, cambios: Partial<LineaFormEquipo>) =>
    setForm((f) => ({
      ...f,
      equipo: f.equipo.map((l, j) => (i === j ? { ...l, ...cambios } : l)),
    }));

  const quitarLinea = (i: number) =>
    setForm((f) => ({ ...f, equipo: f.equipo.filter((_, j) => j !== i) }));

  const agregarPreset = (p: PresetEquipo) =>
    setForm((f) => {
      const existente = f.equipo.find(
        (l) => l.nombre.trim().toLowerCase() === p.linea.nombre.toLowerCase()
      );
      // Ya está en la lista: suma uno más en vez de duplicarla.
      if (existente) {
        return {
          ...f,
          equipo: f.equipo.map((l) =>
            l === existente
              ? {
                  ...l,
                  cantidad: String((parseInt(l.cantidad, 10) || 1) + 1),
                }
              : l
          ),
        };
      }
      if (f.equipo.length >= 12) return f;
      return {
        ...f,
        equipo: [
          ...f.equipo,
          { nombre: p.linea.nombre, cantidad: "", precio: "" },
        ],
      };
    });

  // Vista previa del equipo: todo viaja a la cotización, con costo si lo hay.
  const previaEquipo = useMemo(() => {
    const conNombre = form.equipo.filter((l) => l.nombre.trim() !== "");
    const costo = conNombre.reduce(
      (suma, l) =>
        suma + (parseFloat(l.precio) || 0) * (parseInt(l.cantidad, 10) || 1),
      0
    );
    return { alPdf: conNombre, costo };
  }, [form.equipo]);

  // ── Intérpretes extra ──
  const agregarInterprete = () =>
    setForm((f) =>
      f.interpretesExtra.length >= MAX_INTERPRETES_EXTRA
        ? f
        : {
            ...f,
            interpretesExtra: [
              ...f.interpretesExtra,
              { nombre: "", tarifa: "", viaticos: "" },
            ],
          }
    );

  const cambiarInterprete = (i: number, cambios: Partial<InterpreteForm>) =>
    setForm((f) => ({
      ...f,
      interpretesExtra: f.interpretesExtra.map((l, j) =>
        i === j ? { ...l, ...cambios } : l
      ),
    }));

  const quitarInterprete = (i: number) =>
    setForm((f) => ({
      ...f,
      interpretesExtra: f.interpretesExtra.filter((_, j) => j !== i),
    }));

  const guardar = async () => {
    setError("");
    if (!form.cliente.trim()) {
      setError("El cliente o empresa es el único campo obligatorio junto con la tarifa.");
      return;
    }
    const tarifa = form.tarifa.trim() === "" ? 0 : parseFloat(form.tarifa);
    if (!Number.isFinite(tarifa) || tarifa < 0) {
      setError("La tarifa debe ser un número (puede ser 0 si aún no la defines).");
      return;
    }

    setEnviando(true);
    try {
      const res = await fetch(
        esEdicion ? `/api/eventos/${evento!.id}` : "/api/eventos",
        {
          method: esEdicion ? "PUT" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            cliente: form.cliente,
            contacto: form.contacto || null,
            telefono: form.telefono || null,
            correo: form.correo || null,
            idiomas: form.idiomas || null,
            nombreEvento: form.nombreEvento || null,
            tema: form.tema || null,
            modalidad: form.modalidad,
            ciudad: form.modalidad === "FORANEO" ? form.ciudad || null : null,
            origen: form.origen || null,
            estatus: form.estatus,
            // El motivo de cancelación se captura al cancelar (en la tarjeta);
            // al editar se conserva el que ya estaba guardado.
            razonCancelacion: evento?.razonCancelacion ?? null,
            fechas: form.fechas,
            fechaInicio: form.fechas[0] ?? null,
            fechaFin: form.fechas[form.fechas.length - 1] ?? null,
            horaInicio: form.diaCompleto ? null : form.horaInicio || null,
            horaFin: form.diaCompleto ? null : form.horaFin || null,
            diaCompleto: form.diaCompleto,
            tarifa,
            tarifaPorDia:
              form.tarifaPorDia.trim() === "" ? null : parseFloat(form.tarifaPorDia) || null,
            viaticos:
              form.modalidad === "FORANEO" && form.viaticos.trim() !== ""
                ? parseFloat(form.viaticos) || null
                : null,
            impuestosTipo: form.impuestosTipo || null,
            ivaEnCotizacion: form.ivaEnCotizacion,
            interpretesExtra: form.interpretesExtra.map((i) => ({
              nombre: i.nombre,
              tarifa: i.tarifa.trim() === "" ? null : parseFloat(i.tarifa) || null,
              viaticos:
                form.modalidad === "FORANEO" && i.viaticos.trim() !== ""
                  ? parseFloat(i.viaticos) || null
                  : null,
            })),
            linkGlosario: form.linkGlosario || null,
            notas: form.notas || null,
            equipo: form.equipo.map((l) => ({
              nombre: l.nombre,
              cantidad: l.cantidad.trim() === "" ? 1 : parseInt(l.cantidad, 10) || 1,
              precio: l.precio.trim() === "" ? null : parseFloat(l.precio) || null,
            })),
          }),
        }
      );
      if (!res.ok) throw new Error("respuesta no ok");
      const dato: EventoDTO = await res.json();
      if (esEdicion) {
        onEditado?.(dato);
      } else {
        onCreado?.(dato);
        setForm(VACIO);
      }
      setAbierto(false);
      toast({
        title: esEdicion ? "Cambios guardados" : "Evento registrado",
        description: esEdicion
          ? `${dato.nombreEvento || dato.cliente} quedó actualizado.`
          : `${dato.nombreEvento || dato.cliente} quedó en tu registro.`,
      });
    } catch {
      toast({
        title: "No se pudo guardar",
        description: "Revisa tu conexión e inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setEnviando(false);
    }
  };

  const foraneo = form.modalidad === "FORANEO";

  return (
    <Dialog open={abierto} onOpenChange={setAbierto}>
      <DialogTrigger asChild>
        {esEdicion ? (
          <button
            type="button"
            aria-label={`Editar evento — ${evento!.nombreEvento || evento!.cliente}`}
            title="Editar evento"
            className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-tinta-muda transition-colors hover:bg-acento/10 hover:text-acento-claro"
          >
            <Pencil className="h-3.5 w-3.5" aria-hidden />
          </button>
        ) : (
          <Button className="h-10 rounded-lg bg-acento px-4 text-sm font-semibold text-acento-tinta transition-colors hover:bg-acento-claro">
            <Plus className="h-4 w-4" aria-hidden />
            Nuevo evento
          </Button>
        )}
      </DialogTrigger>

      <DialogContent
        style={SUPERFICIE_TARJETA}
        className="max-h-[88vh] overflow-y-auto radio-tarjeta border-linea-fuerte bg-tarjeta-baja text-tinta-suave sm:max-w-lg"
      >
        <DialogHeader>
          <DialogTitle className="font-display text-xl text-tinta">
            {esEdicion ? "Editar evento" : "Nuevo evento"}
          </DialogTitle>
          <DialogDescription className="text-xs text-tinta-muda">
            {esEdicion ? (
              <>
                Actualiza lo que necesites — tarifas, nombres, horarios… el resto
                de la tarjeta se recalcula solo.
                {evento!.idEvento ? (
                  <>
                    {" "}
                    Código:{" "}
                    <span className="font-mono text-tinta-suave">
                      {evento!.idEvento}
                    </span>
                  </>
                ) : null}
              </>
            ) : (
              <>
                Solo <span className="text-tinta-suave">cliente</span> y{" "}
                <span className="text-tinta-suave">tarifa</span> son obligatorios.
                Todo lo demás lo puedes dejar vacío y completar después.
              </>
            )}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5">
          {/* ── Cliente ── */}
          <section className="space-y-3">
            <p className={SECCION}>Cliente</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1.5 sm:col-span-2">
                <label className={ETIQUETA} htmlFor="f-cliente">
                  Cliente / Empresa <span className="text-acento">*</span>
                </label>
                <Input
                  id="f-cliente"
                  value={form.cliente}
                  onChange={(e) => set("cliente")(e.target.value)}
                  placeholder="Quien contrata y paga: AdWeek, CN, LS…"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-contacto">
                  Nombre del contacto
                </label>
                <Input
                  id="f-contacto"
                  value={form.contacto}
                  onChange={(e) => set("contacto")(e.target.value)}
                  placeholder="Ana María Tlatolli"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-tel">
                  Teléfono (WhatsApp)
                </label>
                <Input
                  id="f-tel"
                  type="tel"
                  inputMode="numeric"
                  value={form.telefono}
                  onChange={(e) => set("telefono")(e.target.value)}
                  placeholder="5636020401"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <label className={ETIQUETA} htmlFor="f-correo">
                  Correo del contacto
                </label>
                <Input
                  id="f-correo"
                  type="email"
                  value={form.correo}
                  onChange={(e) => set("correo")(e.target.value)}
                  placeholder="contacto@empresa.com"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
            </div>
          </section>

          {/* ── Evento ── */}
          <section className="space-y-3">
            <p className={SECCION}>El evento</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1.5 sm:col-span-2">
                <label className={ETIQUETA} htmlFor="f-evento">
                  Nombre del evento
                </label>
                <Input
                  id="f-evento"
                  value={form.nombreEvento}
                  onChange={(e) => set("nombreEvento")(e.target.value)}
                  placeholder="La historia: capacitación FAK, cumbre BH…"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA}>Idiomas</label>
                <Select
                  value={form.idiomas || "SIN-DEFINIR"}
                  onValueChange={(v) => set("idiomas")(v === "SIN-DEFINIR" ? "" : v)}
                >
                  <SelectTrigger className="h-10 border-linea-fuerte bg-panel">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-linea-fuerte bg-tarjeta text-tinta-suave">
                    <SelectItem value="SIN-DEFINIR" className="focus:bg-panel">
                      Sin definir
                    </SelectItem>
                    {IDIOMAS_VALIDOS.map((i) => (
                      <SelectItem key={i} value={i} className="focus:bg-panel">
                        {i}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-tema">
                  Tema / Industria
                </label>
                <Input
                  id="f-tema"
                  value={form.tema}
                  onChange={(e) => set("tema")(e.target.value)}
                  placeholder="Marketing, legal, médico…"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA}>Modalidad</label>
                <Select
                  value={form.modalidad}
                  onValueChange={(v) => setForm((f) => ({ ...f, modalidad: v as Modalidad }))}
                >
                  <SelectTrigger className="h-10 border-linea-fuerte bg-panel">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-linea-fuerte bg-tarjeta text-tinta-suave">
                    {(Object.keys(MODALIDAD_CONFIG) as Modalidad[]).map((m) => (
                      <SelectItem key={m} value={m} className="focus:bg-panel">
                        {MODALIDAD_CONFIG[m].label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA}>Estatus</label>
                <Select value={form.estatus} onValueChange={(v) => set("estatus")(v as Estatus)}>
                  <SelectTrigger className="h-10 border-linea-fuerte bg-panel">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-linea-fuerte bg-tarjeta text-tinta-suave">
                    {ESTATUS_VALIDOS.map((e) => (
                      <SelectItem key={e} value={e} className="focus:bg-panel">
                        {ESTATUS_CONFIG[e].label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {foraneo ? (
                <div className="space-y-1.5 sm:col-span-2">
                  <label className={ETIQUETA} htmlFor="f-ciudad">
                    Ciudad
                  </label>
                  <Input
                    id="f-ciudad"
                    value={form.ciudad}
                    onChange={(e) => set("ciudad")(e.target.value)}
                    placeholder="Monterrey, León, Tijuana…"
                    className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                  />
                </div>
              ) : null}
              <div className="space-y-1.5 sm:col-span-2">
                <label className={ETIQUETA}>Origen (para el análisis)</label>
                <div className="flex flex-wrap gap-1.5">
                  {ORIGENES_VALIDOS.map((o) => {
                    const activo = form.origen === o;
                    return (
                      <button
                        key={o}
                        type="button"
                        aria-pressed={activo}
                        onClick={() =>
                          setForm((f) => ({
                            ...f,
                            origen: f.origen === o ? "" : o,
                          }))
                        }
                        title={
                          o === "DIRECTO"
                            ? "El cliente llegó a ti directamente"
                            : o === "AGENCIA"
                              ? "Una agencia trajo el evento"
                              : "Un colega te lo cedió o lo refirió"
                        }
                        className={`inline-flex h-8 items-center rounded-full border px-3 text-[11px] font-medium transition-colors ${
                          activo
                            ? "border-acento/40 bg-acento/10 text-acento-claro"
                            : "border-linea-fuerte text-tinta-suave hover:border-acento/30 hover:text-tinta"
                        }`}
                      >
                        {ORIGEN_CONFIG[o].label}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </section>

          {/* ── Fechas y horario (calendario + reloj estilo WQZ) ── */}
          <section className="space-y-3">
            <p className={SECCION}>Fechas y horario</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-fechas">
                  Fechas
                </label>
                <button
                  id="f-fechas"
                  type="button"
                  aria-haspopup="dialog"
                  onClick={() => setCalAbierto(true)}
                  className="flex h-10 items-center gap-2 rounded-lg border border-linea-fuerte bg-panel px-3 text-left text-xs font-medium text-tinta-suave transition-colors hover:border-acento/30"
                >
                  <Calendar1 className="h-4 w-4 shrink-0 text-acento/70" aria-hidden />
                  <span className="min-w-0 flex-1 truncate text-tinta">
                    {resumenFechasTxt}
                  </span>
                  <span aria-hidden className="text-acento">›</span>
                </button>
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-horario">
                  Horario
                </label>
                <button
                  id="f-horario"
                  type="button"
                  aria-haspopup="dialog"
                  onClick={() => setRelojAbierto(true)}
                  className="flex h-10 items-center gap-2 rounded-lg border border-linea-fuerte bg-panel px-3 text-left text-xs font-medium text-tinta-suave transition-colors hover:border-acento/30"
                >
                  <Clock className="h-4 w-4 shrink-0 text-acento/70" aria-hidden />
                  <span className="min-w-0 flex-1 truncate text-tinta">
                    {resumenHorario}
                  </span>
                  <span aria-hidden className="text-acento">›</span>
                </button>
              </div>
            </div>
            {calAbierto ? (
              <CalendarioRango
                abierto
                onCierra={() => setCalAbierto(false)}
                fechas={form.fechas}
                onCambia={(fechas) =>
                  setForm((f) =>
                    f.fechas.join() === fechas.join() ? f : { ...f, fechas }
                  )
                }
              />
            ) : null}
            {relojAbierto ? (
              <Reloj24
                abierto
                onCierra={() => setRelojAbierto(false)}
                horaInicio={form.horaInicio}
                horaFin={form.horaFin}
                diaCompleto={form.diaCompleto}
                onCambia={(hi, hf, completo) =>
                  setForm((f) =>
                    f.horaInicio === hi && f.horaFin === hf && f.diaCompleto === completo
                      ? f
                      : { ...f, horaInicio: hi, horaFin: hf, diaCompleto: completo }
                  )
                }
              />
            ) : null}
          </section>

          {/* ── Equipo para el servicio ── */}
          <section className="space-y-3">
            <p className={SECCION}>Equipo para el servicio</p>
            <div className="flex flex-wrap gap-1.5">
              {PRESETS_EQUIPO.map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => agregarPreset(p)}
                  className="inline-flex h-8 items-center gap-1 rounded-full border border-linea-fuerte px-3 text-[11px] font-medium text-tinta-suave transition-colors hover:border-acento/40 hover:text-acento-claro"
                >
                  <Plus className="h-3 w-3" aria-hidden />
                  {p.label}
                </button>
              ))}
            </div>

            {form.equipo.length === 0 ? (
              <p className="text-[11px] leading-relaxed text-tinta-muda">
                Lo que el evento necesita: cabina, receptores, transmisores…
                Cada línea viaja a la cotización; con precio se cobra, sin
                precio queda como «incluido en el servicio».
              </p>
            ) : (
              <div className="space-y-2">
                <div className={`${GRID_LINEA} px-0.5 text-[10px] font-medium uppercase tracking-wide text-tinta-muda`}>
                  <span>Artículo</span>
                  <span className="text-center">Cant.</span>
                  <span className="text-right">Precio/u</span>
                  <span aria-hidden />
                </div>
                {form.equipo.map((l, i) => (
                  <div key={i} className={GRID_LINEA}>
                    <Input
                      value={l.nombre}
                      onChange={(e) => cambiarLinea(i, { nombre: e.target.value })}
                      placeholder="Receptores, cabina, transmisor…"
                      className="h-9 border-linea-fuerte bg-panel text-xs placeholder:text-tinta-muda"
                      aria-label={`Artículo de equipo ${i + 1}`}
                    />
                    <Input
                      type="number"
                      min={1}
                      inputMode="numeric"
                      value={l.cantidad}
                      onChange={(e) =>
                        cambiarLinea(i, { cantidad: e.target.value })
                      }
                      placeholder="1"
                      className="h-9 border-linea-fuerte bg-panel px-1.5 text-center text-xs placeholder:text-tinta-muda"
                      aria-label={`Cantidad de ${l.nombre || "equipo"}`}
                    />
                    <Input
                      type="number"
                      min={0}
                      inputMode="numeric"
                      value={l.precio}
                      onChange={(e) =>
                        cambiarLinea(i, { precio: e.target.value })
                      }
                      placeholder="incluido"
                      className="h-9 border-linea-fuerte bg-panel px-1.5 text-right text-xs placeholder:text-tinta-muda"
                      aria-label={`Precio unitario de ${l.nombre || "equipo"}`}
                    />
                    <button
                      type="button"
                      onClick={() => quitarLinea(i)}
                      aria-label={`Quitar ${l.nombre || "línea"} del equipo`}
                      title="Quitar del equipo"
                      className="inline-flex h-9 w-[30px] items-center justify-center rounded-lg text-tinta-muda transition-colors hover:bg-peligro/10 hover:text-peligro"
                    >
                      <X className="h-3.5 w-3.5" aria-hidden />
                    </button>
                  </div>
                ))}

                <p className="rounded-lg border border-linea-fuerte bg-panel px-3 py-2 text-[11px] leading-relaxed text-tinta-muda">
                  {previaEquipo.alPdf.length > 0 ? (
                    <>
                      Va a la cotización:{" "}
                      <span className="text-acento-claro">
                        {resumenEquipo(
                          previaEquipo.alPdf.map((l) => ({
                            ...l,
                            cantidad: parseInt(l.cantidad, 10) || 1,
                            precio: l.precio.trim() === "" ? null : parseFloat(l.precio) || null,
                            enCotizacion: true,
                          })) as LineaEquipo[],
                          4
                        )}
                      </span>
                    </>
                  ) : (
                    <>Sin equipo todavía.</>
                  )}
                  {previaEquipo.costo > 0 ? (
                    <>
                      {" "}· costo del equipo{" "}
                      <span className="text-acento-claro">
                        $ {formatoTarifa(previaEquipo.costo)}
                      </span>{" "}
                      (se suma a la tarifa en el PDF)
                    </>
                  ) : null}
                </p>
              </div>
            )}
          </section>

          {/* ── Intérpretes extra ── */}
          <section className="space-y-3">
            <p className={SECCION}>Intérpretes extra</p>
            {form.interpretesExtra.length === 0 ? (
              <p className="text-[11px] leading-relaxed text-tinta-muda">
                Cuando el evento necesita más intérpretes en cabina, agrégalos
                aquí: su tarifa y viáticos van a la cotización — y a la
                tarjeta de «Por pagar» cuando les toques liquidarlos.
              </p>
            ) : null}
            <button
              type="button"
              onClick={agregarInterprete}
              className="inline-flex h-8 items-center gap-1 rounded-full border border-linea-fuerte px-3 text-[11px] font-medium text-tinta-suave transition-colors hover:border-acento/40 hover:text-acento-claro"
            >
              <Users className="h-3 w-3" aria-hidden />
              Agregar intérprete
            </button>
            {form.interpretesExtra.length > 0 ? (
              <div className="space-y-2">
                <div className="grid grid-cols-[minmax(0,1fr)_74px_74px_30px] gap-1.5 px-0.5 text-[10px] font-medium uppercase tracking-wide text-tinta-muda">
                  <span>Nombre</span>
                  <span className="text-right">Tarifa</span>
                  {foraneo ? (
                    <span className="text-right">Viáticos</span>
                  ) : (
                    <span aria-hidden />
                  )}
                  <span aria-hidden />
                </div>
                {form.interpretesExtra.map((itp, i) => (
                  <div
                    key={i}
                    className="grid grid-cols-[minmax(0,1fr)_74px_74px_30px] items-center gap-1.5"
                  >
                    <Input
                      value={itp.nombre}
                      onChange={(e) => cambiarInterprete(i, { nombre: e.target.value })}
                      placeholder="Nombre del intérprete"
                      className="h-9 border-linea-fuerte bg-panel text-xs placeholder:text-tinta-muda"
                      aria-label={`Nombre del intérprete extra ${i + 1}`}
                    />
                    <Input
                      type="number"
                      min={0}
                      inputMode="numeric"
                      value={itp.tarifa}
                      onChange={(e) => cambiarInterprete(i, { tarifa: e.target.value })}
                      placeholder="igual"
                      title="Su tarifa (casi siempre la misma que la tuya)"
                      className="h-9 border-linea-fuerte bg-panel px-1.5 text-right text-xs placeholder:text-tinta-muda"
                      aria-label={`Tarifa del intérprete extra ${i + 1}`}
                    />
                    {foraneo ? (
                      <Input
                        type="number"
                        min={0}
                        inputMode="numeric"
                        value={itp.viaticos}
                        onChange={(e) => cambiarInterprete(i, { viaticos: e.target.value })}
                        placeholder="—"
                        className="h-9 border-linea-fuerte bg-panel px-1.5 text-right text-xs placeholder:text-tinta-muda"
                        aria-label={`Viáticos del intérprete extra ${i + 1}`}
                      />
                    ) : (
                      <span aria-hidden />
                    )}
                    <button
                      type="button"
                      onClick={() => quitarInterprete(i)}
                      aria-label={`Quitar intérprete ${itp.nombre || i + 1}`}
                      title="Quitar intérprete"
                      className="inline-flex h-9 w-[30px] items-center justify-center rounded-lg text-tinta-muda transition-colors hover:bg-peligro/10 hover:text-peligro"
                    >
                      <X className="h-3.5 w-3.5" aria-hidden />
                    </button>
                  </div>
                ))}
              </div>
            ) : null}
          </section>

          {/* ── Dinero ── */}
          <section className="space-y-3">
            <p className={SECCION}>Dinero (MXN)</p>
            <div className={foraneo ? "grid grid-cols-2 gap-3" : "grid grid-cols-2 gap-3"}>
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-pordia">
                  Tarifa por día (opcional)
                </label>
                <Input
                  id="f-pordia"
                  type="number"
                  inputMode="numeric"
                  min="0"
                  value={form.tarifaPorDia}
                  onChange={(e) => set("tarifaPorDia")(e.target.value)}
                  placeholder="3500"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              <div className="space-y-1.5">
                <label className={ETIQUETA} htmlFor="f-tarifa">
                  Tarifa total <span className="text-acento">*</span>
                </label>
                <Input
                  id="f-tarifa"
                  type="number"
                  inputMode="numeric"
                  min="0"
                  value={form.tarifa}
                  onChange={(e) => set("tarifa")(e.target.value)}
                  placeholder="4500"
                  className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                />
              </div>
              {foraneo ? (
                <div className="space-y-1.5 sm:col-span-2">
                  <label className={ETIQUETA} htmlFor="f-viaticos">
                    Viáticos (foráneo, opcional)
                  </label>
                  <Input
                    id="f-viaticos"
                    type="number"
                    inputMode="numeric"
                    min="0"
                    value={form.viaticos}
                    onChange={(e) => set("viaticos")(e.target.value)}
                    placeholder="800"
                    className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
                  />
                  <p className="text-[10px] leading-relaxed text-tinta-muda">
                    Viajan a la cotización como una línea aparte — nunca
                    cuentan como ingreso ni como deuda.
                  </p>
                </div>
              ) : null}
            </div>

            {/* Impuestos opcionales */}
            <div className="space-y-1.5">
              <p className={ETIQUETA}>Impuestos (opcional)</p>
              <div className="grid grid-cols-2 gap-2">
                {(Object.keys(IMPUESTOS_CONFIG) as ImpuestosTipo[]).map((t) => {
                  const activo = form.impuestosTipo === t;
                  return (
                    <button
                      key={t}
                      type="button"
                      aria-pressed={activo}
                      onClick={() => alternarImpuestos(t)}
                      title={IMPUESTOS_CONFIG[t].detalle}
                      className={`inline-flex h-10 items-center justify-center gap-1.5 rounded-full border px-3 text-[11px] font-medium transition-colors ${
                        activo
                          ? "border-acento/40 bg-acento/10 text-acento-claro"
                          : "border-linea-fuerte text-tinta-suave hover:border-linea-hover hover:text-tinta"
                      }`}
                    >
                      {IMPUESTOS_CONFIG[t].corto}
                    </button>
                  );
                })}
              </div>
              {/* IVA en la cotización */}
              <button
                type="button"
                role="switch"
                aria-checked={form.ivaEnCotizacion}
                onClick={() =>
                  setForm((f) => ({ ...f, ivaEnCotizacion: !f.ivaEnCotizacion }))
                }
                className="flex w-full items-center justify-between rounded-lg border border-linea-fuerte bg-panel px-3 py-2 text-left text-[11px] font-medium text-tinta-suave transition-colors hover:border-acento/30"
              >
                <span>Incluir IVA en la cotización</span>
                <span
                  className={`relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors ${
                    form.ivaEnCotizacion ? "bg-acento/70" : "bg-linea-fuerte"
                  }`}
                >
                  <span
                    className={`absolute h-4 w-4 rounded-full bg-fondo shadow transition-all ${
                      form.ivaEnCotizacion ? "left-[18px]" : "left-[2px]"
                    }`}
                  />
                </span>
              </button>
              <p className="text-[10px] leading-relaxed text-tinta-muda">
                {form.impuestosTipo
                  ? IMPUESTOS_CONFIG[form.impuestosTipo].detalle
                  : "Tócalos para calcular el desglose. Persona moral: retiene IVA e ISR · FAE: solo IVA."}
              </p>
            </div>

            {desglose ? (
              <div className="rounded-lg border border-linea-fuerte bg-panel px-3 py-2.5 text-[11px] leading-relaxed text-tinta-muda">
                <p>
                  <span className="text-acento-claro">Factura:</span>{" "}
                  $ {formatoDinero(desglose.factura)}{" "}
                  <span className="text-tinta-muda">
                    (tarifa + IVA 16% de $ {formatoDinero(desglose.iva)})
                  </span>
                </p>
                {desglose.tipo === "MORAL" ? (
                  <>
                    <p>
                      Retenciones: IVA −$ {formatoDinero(desglose.retIva)} · ISR −${" "}
                      {formatoDinero(desglose.retIsr)}
                    </p>
                    <p>
                      <span className="text-acento-claro">Neto a recibir:</span>{" "}
                      $ {formatoDinero(desglose.neto)}
                    </p>
                  </>
                ) : (
                  <p>
                    <span className="text-acento-claro">Neto a recibir:</span>{" "}
                    $ {formatoDinero(desglose.neto)} — sin retenciones
                  </p>
                )}
              </div>
            ) : null}
          </section>

          {/* ── Notas y glosario ── */}
          <section className="space-y-3">
            <p className={SECCION}>Notas y glosario</p>
            <div className="space-y-1.5">
              <label className={ETIQUETA} htmlFor="f-glos">
                Link a glosario (opcional)
              </label>
              <Input
                id="f-glos"
                value={form.linkGlosario}
                onChange={(e) => set("linkGlosario")(e.target.value)}
                placeholder="https://docs.google.com/…"
                className="h-10 border-linea-fuerte bg-panel placeholder:text-tinta-muda"
              />
            </div>
            <Textarea
              value={form.notas}
              onChange={(e) => set("notas")(e.target.value)}
              placeholder="Dress code, equipo de cabina, contactos alternos…"
              rows={2}
              className="border-linea-fuerte bg-panel placeholder:text-tinta-muda"
            />
          </section>

          {previa ? (
            <p className="rounded-lg border border-linea-fuerte bg-panel px-3 py-2 text-[11px] text-tinta-muda">
              Se calculará automáticamente:{" "}
              <span className="text-acento-claro">{previa}</span>
            </p>
          ) : null}

          {error ? <p className="text-xs text-peligro">{error}</p> : null}

          <div className="flex gap-2 pt-1">
            <Button
              onClick={guardar}
              disabled={enviando}
              className="h-11 flex-1 rounded-lg bg-acento text-sm font-semibold text-acento-tinta hover:bg-acento-claro"
            >
              {enviando ? "Guardando…" : esEdicion ? "Guardar cambios" : "Guardar evento"}
            </Button>
            <Button
              variant="outline"
              onClick={() => setAbierto(false)}
              className="h-11 rounded-lg border-linea-fuerte bg-tarjeta text-tinta-suave hover:text-tinta"
            >
              Cancelar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
