"use client";

import { useMemo } from "react";
import { differenceInCalendarDays, format } from "date-fns";
import { es } from "date-fns/locale";
import { CalendarCheck, Download, Headphones, MessageCircle, TrendingUp } from "lucide-react";
import {
  ESTATUS_CONFIG,
  ESTATUS_VALIDOS,
  formatoTarifa,
  MODALIDAD_CONFIG,
  normalizarWhatsApp,
  type EventoDTO,
} from "@/lib/estatus";
import { SUPERFICIE_TARJETA } from "@/lib/temas";
import { fechaDisplay } from "@/lib/fechas";
import { useHoy } from "@/hooks/use-hoy";

interface Props {
  eventos: EventoDTO[];
}

// Sin anticipos: lo por cobrar de un trabajado es su tarifa completa.
const saldoDe = (e: EventoDTO) => e.tarifa;

function rangoCorto(ini: Date, fin: Date | null): string {
  if (!fin || ini.toDateString() === fin.toDateString()) {
    return format(ini, "d MMM", { locale: es });
  }
  if (ini.getMonth() === fin.getMonth() && ini.getFullYear() === fin.getFullYear()) {
    return `${ini.getDate()}–${fin.getDate()} ${format(ini, "MMM", { locale: es })}`;
  }
  return `${format(ini, "d MMM", { locale: es })} – ${format(fin, "d MMM", { locale: es })}`;
}

function Seccion({
  titulo,
  conteo,
  children,
}: {
  titulo: string;
  conteo?: number;
  children: React.ReactNode;
}) {
  return (
    <section
      style={SUPERFICIE_TARJETA}
      className="radio-tarjeta border border-linea-suave bg-tarjeta-baja p-4 sm:p-5"
    >
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-[10px] font-medium uppercase tracking-[0.18em] text-acento/80">
          {titulo}
        </h2>
        {conteo !== undefined ? (
          <span className="rounded-full border border-linea-fuerte bg-panel px-2 py-0.5 text-[10px] font-medium text-tinta-muda">
            {conteo}
          </span>
        ) : null}
      </div>
      <div className="mt-3">{children}</div>
    </section>
  );
}

export default function Analisis({ eventos }: Props) {
  // Reloj del cliente: al montar. Mientras no exista, los conteos relativos
  // se muestran neutros — la hidratación nunca ve dos calendarios distintos.
  const hoy = useHoy();
  // ── Distribución del dinero por estatus ────────────────────────────────────
  const dist = useMemo(() => {
    const montos = {
      PROSPECTO: 0,
      CONFIRMADO: 0,
      REALIZADO: 0,
      PAGADO: 0,
      CANCELADO: 0,
    } as Record<string, number>;
    const conteo = { ...montos };
    for (const e of eventos) {
      montos[e.estatus] += e.tarifa;
      conteo[e.estatus] += 1;
    }
    const total = Object.values(montos).reduce((a, b) => a + b, 0);
    const filas = ESTATUS_VALIDOS.map((s) => ({
      estatus: s,
      monto: montos[s],
      n: conteo[s],
      pct: total > 0 ? Math.round((montos[s] / total) * 100) : 0,
    }));
    return { filas, total };
  }, [eventos]);

  // ── Por cobrar: sólo trabajados (REALIZADO) ───────────────────────────────
  // El número exacto que el dueño puede reclamar hoy: trabajo ya entregado
  // y aún no liquidado. Sin lo ya cobrado (PAGADO no entra) y sin contar
  // lo que apenas se cotiza o agenda (prospectos y confirmados tampoco).
  const cobranza = useMemo(() => {
    return eventos
      .filter((e) => e.estatus === "REALIZADO" && saldoDe(e) > 0)
      .sort((a, b) =>
        (a.fechaInicio ?? "").localeCompare(b.fechaInicio ?? "")
      );
  }, [eventos]);

  const porCobrarTotal = useMemo(
    () => cobranza.reduce((suma, e) => suma + saldoDe(e), 0),
    [cobranza]
  );

  // ── Lo que viene: valor agendado y en juego ────
  const caja = useMemo(() => {
    let confirmado = 0;
    let nConfirmado = 0;
    let negociacion = 0;
    let nNegociacion = 0;
    for (const e of eventos) {
      if (e.estatus === "CANCELADO" || e.estatus === "PAGADO") continue;
      if (e.estatus === "CONFIRMADO") {
        confirmado += e.tarifa;
        nConfirmado++;
      } else if (e.estatus === "PROSPECTO") {
        negociacion += e.tarifa;
        nNegociacion++;
      }
    }
    return { confirmado, nConfirmado, negociacion, nNegociacion };
  }, [eventos]);

  // ── Equipo próximo: lo que hay que rentar/preparar para lo que viene ────
  // Agrega las líneas de equipo de prospectos y confirmados con fecha por
  // delante, agrupadas por palabras clave (receptores, bodies, cabinas).
  const equipoProximo = useMemo(() => {
    if (!hoy) return null;
    let receptores = 0;
    let bodies = 0;
    let cabinas = 0;
    const otros = new Map<string, number>();
    let nEventos = 0;
    for (const e of eventos) {
      if (e.estatus !== "PROSPECTO" && e.estatus !== "CONFIRMADO") continue;
      if (!e.fechaInicio) continue;
      const ini = fechaDisplay(e.fechaInicio);
      if (ini === null || differenceInCalendarDays(ini, hoy) < 0) continue;
      if (e.equipo.length === 0) continue;
      nEventos++;
      for (const l of e.equipo) {
        const n = l.nombre.toLowerCase();
        // El orden importa: «Media cabina CON RECEPTORES» es una cabina,
        // no cuatro+ uno de receptores — la palabra más específica gana.
        if (/cabina/.test(n)) cabinas += l.cantidad;
        else if (/body|transmisor/.test(n)) bodies += l.cantidad;
        else if (/receptor|aud\u00edfono|audifono/.test(n)) receptores += l.cantidad;
        else otros.set(l.nombre, (otros.get(l.nombre) ?? 0) + l.cantidad);
      }
    }
    return { receptores, bodies, cabinas, otros: [...otros.entries()], nEventos };
  }, [eventos, hoy]);

  // ── Próximos servicios ─────────────────────────────────────────────────────
  // Lo ya realizado salió del radar de “lo que viene”.
  const proximos = useMemo(() => {
    if (!hoy) return [];
    return eventos
      .filter((e) => {
        if (
          e.estatus === "CANCELADO" ||
          e.estatus === "REALIZADO" ||
          !e.fechaInicio
        )
          return false;
        const ini = fechaDisplay(e.fechaInicio);
        return ini !== null && differenceInCalendarDays(ini, hoy) >= 0;
      })
      .sort((a, b) => (a.fechaInicio ?? "").localeCompare(b.fechaInicio ?? ""))
      .slice(0, 6);
  }, [eventos, hoy]);

  // ── Cancelaciones (con su motivo) ──────────────────────────────────────────
  const cancelados = useMemo(
    () => eventos.filter((e) => e.estatus === "CANCELADO"),
    [eventos]
  );

  // ── Top clientes: de dónde viene el dinero (y cuánto depende de uno solo) ──
  const topClientes = useMemo(() => {
    const mapa = new Map<string, { total: number; n: number }>();
    for (const e of eventos) {
      if (e.estatus === "CANCELADO") continue;
      const clave = e.cliente.trim();
      const dato = mapa.get(clave) ?? { total: 0, n: 0 };
      dato.total += e.tarifa;
      dato.n += 1;
      mapa.set(clave, dato);
    }
    const totalGeneral = [...mapa.values()].reduce((s, v) => s + v.total, 0);
    const filas = [...mapa.entries()]
      .map(([cliente, d]) => ({
        cliente,
        total: d.total,
        n: d.n,
        pct: totalGeneral > 0 ? Math.round((d.total / totalGeneral) * 100) : 0,
      }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);
    return { filas, totalGeneral };
  }, [eventos]);

  if (eventos.length === 0) {
    return (
      <div className="mt-4 grid place-items-center rounded-2xl border border-dashed border-linea-fuerte px-6 py-20 text-center">
        <p className="font-display text-xl text-tinta">
          El análisis empieza con el primer evento
        </p>
        <p className="mt-3 max-w-xs text-sm leading-relaxed text-tinta-muda">
          Cuando registres eventos, aquí verás tu cartera, tus cobros pendientes y
          lo que viene — todo en un solo vistazo.
        </p>
      </div>
    );
  }

  return (
    <div className="mt-4 space-y-4 pb-6">
      {/* Mini encabezado + exportación */}
      <div className="flex items-center justify-between gap-3 pt-1">
        <div>
          <h2 className="font-display text-xl text-tinta">Análisis</h2>
          <p className="text-[11px] text-tinta-muda">
            Lo que tu registro dice de tu negocio.
          </p>
        </div>
        <a
          href="/api/exportar"
          download
          className="inline-flex h-10 shrink-0 items-center gap-1.5 rounded-full border border-linea-fuerte px-4 text-xs font-medium text-tinta-suave transition-colors hover:border-acento/40 hover:text-acento-claro"
        >
          <Download className="h-3.5 w-3.5" aria-hidden />
          Exportar CSV
        </a>
      </div>

      {/* ── Distribución por estatus ── */}
      <Seccion titulo="Distribución por estatus" conteo={eventos.length}>
        <div className="flex h-2.5 gap-[3px] overflow-hidden rounded-full bg-linea-suave">
          {dist.filas.map((f) =>
            f.monto > 0 ? (
              <div
                key={f.estatus}
                style={{ flexGrow: f.monto }}
                className={`h-full rounded-full ${ESTATUS_CONFIG[f.estatus].punto}`}
              />
            ) : null
          )}
        </div>
        <div className="mt-3">
          {dist.filas.map((f, i) => (
            <div
              key={f.estatus}
              className={`flex flex-col gap-1 py-2 sm:flex-row sm:items-center sm:justify-between sm:gap-3 ${
                i > 0 ? "border-t border-linea-suave" : ""
              } ${f.estatus === "CANCELADO" ? "opacity-60" : ""}`}
            >
              <span className="inline-flex items-center gap-2 text-sm text-tinta-suave">
                <span
                  className={`h-2 w-2 rounded-full ${ESTATUS_CONFIG[f.estatus].punto}`}
                  aria-hidden
                />
                {ESTATUS_CONFIG[f.estatus].label}
              </span>
              <span className="text-xs text-tinta-muda sm:text-right">
                {f.n} {f.n === 1 ? "evento" : "eventos"} ·{" "}
                <span className="text-tinta">$ {formatoTarifa(f.monto)}</span>{" "}
                · {f.pct}%
              </span>
            </div>
          ))}
        </div>
      </Seccion>

      {/* ── Lo que viene ── */}
      <Seccion titulo="Lo que viene">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="rounded-lg border border-linea-suave bg-panel px-3 py-2.5">
            <p className="flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wide text-tinta-muda">
              <CalendarCheck className="h-3 w-3 text-estado-confirmado" aria-hidden />
              Confirmado por venir
            </p>
            <p className="mt-1 font-display text-xl tracking-tight text-tinta">
              $ {formatoTarifa(caja.confirmado)}
            </p>
            <p className="text-[11px] text-tinta-muda">
              {caja.nConfirmado === 0
                ? "nada agendado aún"
                : `${caja.nConfirmado} ${caja.nConfirmado === 1 ? "evento" : "eventos"} asegurados`}
            </p>
          </div>
          <div className="rounded-lg border border-linea-suave bg-panel px-3 py-2.5">
            <p className="flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wide text-tinta-muda">
              <TrendingUp className="h-3 w-3 text-estado-prospecto" aria-hidden />
              En negociación
            </p>
            <p className="mt-1 font-display text-xl tracking-tight text-tinta">
              $ {formatoTarifa(caja.negociacion)}
            </p>
            <p className="text-[11px] text-tinta-muda">
              {caja.nNegociacion === 0
                ? "sin prospectos"
                : `${caja.nNegociacion} ${caja.nNegociacion === 1 ? "prospecto" : "prospectos"} por cerrar`}
            </p>
          </div>
        </div>
      </Seccion>

      {/* ── Por cobrar (trabajados) ── */}
      <Seccion titulo="Por cobrar — trabajados" conteo={cobranza.length}>
        <p className="mb-1 font-display text-2xl tracking-tight text-acento-claro">
          $ {formatoTarifa(porCobrarTotal)}
          <span className="ml-2 text-[11px] font-medium tracking-normal text-tinta-muda">
            trabajo entregado, pendiente de cobro — sin lo ya cobrado
          </span>
        </p>
        {cobranza.length === 0 ? (
          <p className="py-6 text-center text-sm text-tinta-muda">
            Nada pendiente de cobro — todo liquidado.
          </p>
        ) : (
          <div className="divide-y divide-linea-suave">
            {cobranza.map((e) => {
              const saldo = saldoDe(e);
              const waTel = normalizarWhatsApp(e.telefono);
              const nombre = e.contacto ? e.contacto.split(" ")[0] : "";
              const msg = `Hola${nombre ? ` ${nombre}` : ""}, le escribo respecto al servicio de interpretación para ${e.cliente}. Le comparto el estado de la cuenta: saldo pendiente de $ ${formatoTarifa(saldo)} MXN. Quedo al pendiente por si tiene alguna duda. ¡Gracias!`;

              return (
                <div key={e.id} className="flex items-center gap-3 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-tinta">
                      {e.cliente}
                    </p>
                    <p className="mt-0.5 text-[11px]">
                      <span className="text-tinta-suave">
                        {e.fechaInicio ? rangoCorto(new Date(e.fechaInicio), e.fechaFin ? new Date(e.fechaFin) : null) : "sin fecha"}
                      </span>
                      {e.idEvento ? (
                        <span className="text-tinta-muda"> · {e.idEvento}</span>
                      ) : null}
                    </p>
                  </div>
                  <p className="shrink-0 font-display text-lg tracking-tight text-acento-claro">
                    $ {formatoTarifa(saldo)}
                  </p>
                  {waTel ? (
                    <a
                      href={`https://wa.me/${waTel}?text=${encodeURIComponent(msg)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`Enviar recordatorio de saldo — ${e.cliente}`}
                      title="Enviar recordatorio de saldo por WhatsApp"
                      className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-tinta-muda transition-colors hover:bg-exito/10 hover:text-exito"
                    >
                      <MessageCircle className="h-4 w-4" aria-hidden />
                    </a>
                  ) : null}
                </div>
              );
            })}
          </div>
        )}
      </Seccion>

      {/* ── Cancelaciones ── */}
      {cancelados.length > 0 ? (
        <Seccion titulo="Cancelaciones" conteo={cancelados.length}>
          <div className="divide-y divide-linea-suave">
            {cancelados.map((e) => {
              const ini = fechaDisplay(e.fechaInicio);
              const fin = fechaDisplay(e.fechaFin);
              return (
                <div key={e.id} className="flex items-center gap-3 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-tinta line-through decoration-tinta-muda">
                      {e.cliente}
                    </p>
                    <p className="mt-0.5 truncate text-[11px] text-tinta-muda">
                      {ini ? rangoCorto(ini, fin) : "sin fecha"}
                      {e.idEvento ? ` · ${e.idEvento}` : ""}
                      {e.razonCancelacion
                        ? ` · Motivo: ${e.razonCancelacion}`
                        : " · sin motivo"}
                    </p>
                  </div>
                  <p className="shrink-0 text-xs text-tinta-muda">
                    $ {formatoTarifa(e.tarifa)}
                  </p>
                </div>
              );
            })}
          </div>
        </Seccion>
      ) : null}

      {/* ── Próximos servicios ── */}
      <Seccion titulo="Próximos servicios" conteo={proximos.length}>
        {proximos.length === 0 ? (
          <p className="py-6 text-center text-sm text-tinta-muda">
            Sin servicios próximos con fecha registrada.
          </p>
        ) : (
          <div className="divide-y divide-linea-suave">
            {proximos.map((e) => {
              const ini = fechaDisplay(e.fechaInicio) as Date;
              const fin = fechaDisplay(e.fechaFin);
              const dias = hoy ? differenceInCalendarDays(ini, hoy) : null;
              const mod = MODALIDAD_CONFIG[e.modalidad];
              const modTexto =
                e.modalidad === "PRESENCIAL_CDMX"
                  ? "Presencial · CDMX"
                  : mod.conCiudad && e.ciudad
                    ? `${mod.label} · ${e.ciudad}`
                    : mod.label;
              return (
                <div key={e.id} className="flex items-center gap-3 py-3">
                  <p className="w-20 shrink-0 text-xs font-medium text-tinta-suave">
                    {rangoCorto(ini, fin)}
                  </p>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm text-tinta">{e.cliente}</p>
                    <p className="mt-0.5 truncate text-[11px] text-tinta-muda">
                      {e.idiomas ? `${e.idiomas} · ` : ""}
                      {modTexto}
                      {e.horario ? ` · ${e.horario}` : ""}
                    </p>
                  </div>
                  {dias !== null && dias <= 7 ? (
                    <span
                      className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-medium ${
                        dias === 0
                          ? "bg-acento/15 text-acento-claro"
                          : "bg-acento/10 text-acento-claro/80"
                      }`}
                    >
                      {dias === 0 ? "hoy" : dias === 1 ? "mañana" : `en ${dias} días`}
                    </span>
                  ) : null}
                </div>
              );
            })}
          </div>
        )}
      </Seccion>

      {/* ── Equipo próximo (sugerencia ronda 17) ── */}
      {/* Lo que hay que rentar o preparar para los servicios por venir:
          suma el equipo de prospectos y confirmados con fecha por delante. */}
      {equipoProximo ? (
        <Seccion titulo="Equipo próximo" conteo={equipoProximo.nEventos}>
          {equipoProximo.nEventos === 0 ? (
            <p className="py-6 text-center text-sm text-tinta-muda">
              Sin equipo registrado en lo que viene — agrégalo en el evento y
              aquí verás lo que necesitas rentar o preparar.
            </p>
          ) : (
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2">
                {equipoProximo.receptores > 0 ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-acento/30 bg-acento/[0.07] px-3 py-1 text-xs font-medium text-acento-claro">
                    <Headphones className="h-3 w-3" aria-hidden />
                    Receptores ·{" "}
                    <span className="font-display text-[13px]">
                      {formatoTarifa(equipoProximo.receptores)}
                    </span>
                  </span>
                ) : null}
                {equipoProximo.bodies > 0 ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-acento/30 bg-acento/[0.07] px-3 py-1 text-xs font-medium text-acento-claro">
                    <Headphones className="h-3 w-3" aria-hidden />
                    Bodies ·{" "}
                    <span className="font-display text-[13px]">
                      {formatoTarifa(equipoProximo.bodies)}
                    </span>
                  </span>
                ) : null}
                {equipoProximo.cabinas > 0 ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-acento/30 bg-acento/[0.07] px-3 py-1 text-xs font-medium text-acento-claro">
                    <Headphones className="h-3 w-3" aria-hidden />
                    Cabinas ·{" "}
                    <span className="font-display text-[13px]">
                      {formatoTarifa(equipoProximo.cabinas)}
                    </span>
                  </span>
                ) : null}
              </div>
              {equipoProximo.otros.length > 0 ? (
                <p className="text-[11px] text-tinta-muda">
                  Y también:{" "}
                  {equipoProximo.otros
                    .map(([n, c]) => `${c > 1 ? `${c} × ` : ""}${n}`)
                    .join(" · ")}
                </p>
              ) : null}
              <p className="text-[11px] text-tinta-muda">
                Suma de prospectos y confirmados con fecha por delante — tu
                lista de renta antes de la semana.
              </p>
            </div>
          )}
        </Seccion>
      ) : null}

      {/* ── Top clientes (sugerencia ronda 17) ── */}
      {/* De dónde viene el dinero: quiénes repiten y cuánto pesa cada uno. */}
      <Seccion titulo="Top clientes" conteo={topClientes.filas.length}>
        <div className="divide-y divide-linea-suave">
          {topClientes.filas.map((c, i) => (
            <div key={c.cliente} className="flex items-center gap-3 py-3">
              <span
                className={`w-5 shrink-0 text-right font-display text-sm ${
                  i === 0 ? "text-acento-claro" : "text-tinta-muda"
                }`}
              >
                {i + 1}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-tinta">
                  {c.cliente}
                </p>
                <p className="mt-0.5 text-[11px] text-tinta-muda">
                  {c.n} {c.n === 1 ? "servicio" : "servicios"} · {c.pct}% del registro
                </p>
              </div>
              <p className="shrink-0 font-display text-lg tracking-tight text-acento-claro">
                $ {formatoTarifa(c.total)}
              </p>
            </div>
          ))}
        </div>
      </Seccion>
    </div>
  );
}
