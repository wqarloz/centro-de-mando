"use client";

import { useMemo } from "react";
import { differenceInCalendarDays, format } from "date-fns";
import { es } from "date-fns/locale";
import {
  CalendarCheck,
  Download,
  Headphones,
  MessageCircle,
  Pocket,
  TrendingUp,
  Users,
} from "lucide-react";
import {
  ESTATUS_CONFIG,
  formatoTarifa,
  MODALIDAD_CONFIG,
  normalizarWhatsApp,
  type EventoDTO,
} from "@/lib/estatus";
import { SUPERFICIE_TARJETA } from "@/lib/temas";
import { fechaDisplay } from "@/lib/fechas";
import { useHoy } from "@/hooks/use-hoy";

interface Props {
  eventos: EventoDTO[];
}

// Sin anticipos: lo por cobrar de un trabajado es su tarifa completa.
const saldoDe = (e: EventoDTO) => e.tarifa;

// Pagos de salida (ronda 20): lo que el dueño debe por eventos ya cobrados —
// intérpretes extra sin liquidar y equipo con costo sin pagar. Los viáticos
// jamás entran aquí: son passthrough del cliente, ni ingreso ni deuda.
const porPagarDe = (e: EventoDTO) =>
  (e.pagoInterpretes
    ? 0
    : e.interpretesExtra.reduce((s, i) => s + (i.tarifa ?? 0), 0)) +
  (e.pagoEquipo
    ? 0
    : e.equipo.reduce((s, l) => s + (l.precio ?? 0) * l.cantidad, 0));

function rangoCorto(ini: Date, fin: Date | null): string {
  if (!fin || ini.toDateString() === fin.toDateString()) {
    return format(ini, "d MMM", { locale: es });
  }
  if (ini.getMonth() === fin.getMonth() && ini.getFullYear() === fin.getFullYear()) {
    return `${ini.getDate()}–${fin.getDate()} ${format(ini, "MMM", { locale: es })}`;
  }
  return `${format(ini, "d MMM", { locale: es })} – ${format(fin, "d MMM", { locale: es })}`;
}

function Seccion({
  titulo,
  conteo,
  children,
}: {
  titulo: string;
  conteo?: number;
  children: React.ReactNode;
}) {
  return (
    <section
      style={SUPERFICIE_TARJETA}
      className="radio-tarjeta border border-linea-suave bg-tarjeta-baja p-4 sm:p-5"
    >
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-[10px] font-medium uppercase tracking-[0.18em] text-acento/80">
          {titulo}
        </h2>
        {conteo !== undefined ? (
          <span className="rounded-full border border-linea-fuerte bg-panel px-2 py-0.5 text-[10px] font-medium text-tinta-muda">
            {conteo}
          </span>
        ) : null}
      </div>
      <div className="mt-3">{children}</div>
    </section>
  );
}

export default function Analisis({ eventos }: Props) {
  // Reloj del cliente: al montar. Mientras no exista, los conteos relativos
  // se muestran neutros — la hidratación nunca ve dos calendarios distintos.
  const hoy = useHoy();

  // ── Por pagar (ronda 20): lo que sale de la caja propia en eventos ya
  // cobrados — intérpretes extra y equipo con costo, liquidados por botón.
  const porPagar = useMemo(() => {
    let interpretes = 0;
    let equipo = 0;
    let n = 0;
    for (const e of eventos) {
      if (e.estatus !== "PAGADO") continue;
      const ip = e.pagoInterpretes
        ? 0
        : e.interpretesExtra.reduce((s, i) => s + (i.tarifa ?? 0), 0);
      const eq = e.pagoEquipo
        ? 0
        : e.equipo.reduce((s, l) => s + (l.precio ?? 0) * l.cantidad, 0);
      if (ip > 0 || eq > 0) n++;
      interpretes += ip;
      equipo += eq;
    }
    return { interpretes, equipo, total: interpretes + equipo, n };
  }, [eventos]);

  // ── Directo vs Agencias: de dónde viene el dinero trabajado ─────────────
  // (pagados + realizados). AGENCIA y COLEGA pliegan en "vía terceros".
  const origenes = useMemo(() => {
    let directo = 0;
    let terceros = 0;
    let nDirecto = 0;
    let nTerceros = 0;
    for (const e of eventos) {
      if (e.estatus !== "PAGADO" && e.estatus !== "REALIZADO") continue;
      if (e.origen === "AGENCIA" || e.origen === "COLEGA") {
        terceros += e.tarifa;
        nTerceros++;
      } else {
        directo += e.tarifa;
        nDirecto++;
      }
    }
    const total = directo + terceros;
    return {
      directo,
      terceros,
      nDirecto,
      nTerceros,
      pctTerceros: total > 0 ? Math.round((terceros / total) * 100) : 0,
      hayDatos: total > 0,
    };
  }, [eventos]);

  // ── Variación vs mes anterior: ingresos (PAGADO) por mes de inicio ─────
  // Seis meses a la vista, el último par en comparación directa.
  const meses = useMemo(() => {
    const clave = (d: Date) =>
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const suma = new Map<string, number>();
    for (const e of eventos) {
      if (e.estatus !== "PAGADO" || !e.fechaInicio) continue;
      const d = new Date(e.fechaInicio);
      const k = clave(d);
      suma.set(k, (suma.get(k) ?? 0) + e.tarifa);
    }
    if (!hoy) return null;
    const lista: {
      etiqueta: string;
      total: number;
      esActual: boolean;
      esPrevio: boolean;
    }[] = [];
    const cursor = new Date(hoy.getFullYear(), hoy.getMonth() - 5, 1);
    for (let i = 0; i < 6; i++) {
      const d = new Date(cursor.getFullYear(), cursor.getMonth() + i, 1);
      const k = clave(d);
      lista.push({
        etiqueta: format(d, "MMM", { locale: es }),
        total: suma.get(k) ?? 0,
        esActual: k === clave(hoy),
        esPrevio: k === clave(new Date(hoy.getFullYear(), hoy.getMonth() - 1, 1)),
      });
    }
    const actual = lista.find((m) => m.esActual)?.total ?? 0;
    const previo = lista.find((m) => m.esPrevio)?.total ?? 0;
    const delta = previo > 0 ? Math.round(((actual - previo) / previo) * 100) : null;
    return { lista, actual, previo, delta };
  }, [eventos, hoy]);

  // ── Por cobrar: sólo trabajados (REALIZADO) ───────────────────────────────
  // El número exacto que el dueño puede reclamar hoy: trabajo ya entregado
  // y aún no liquidado. Sin lo ya cobrado (PAGADO no entra) y sin contar
  // lo que apenas se cotiza o agenda (prospectos y confirmados tampoco).
  const cobranza = useMemo(() => {
    return eventos
      .filter((e) => e.estatus === "REALIZADO" && saldoDe(e) > 0)
      .sort((a, b) =>
        (a.fechaInicio ?? "").localeCompare(b.fechaInicio ?? "")
      );
  }, [eventos]);

  const porCobrarTotal = useMemo(
    () => cobranza.reduce((suma, e) => suma + saldoDe(e), 0),
    [cobranza]
  );

  // ── Lo que viene: valor agendado y en juego ────
  const caja = useMemo(() => {
    let confirmado = 0;
    let nConfirmado = 0;
    let negociacion = 0;
    let nNegociacion = 0;
    for (const e of eventos) {
      if (e.estatus === "CANCELADO" || e.estatus === "PAGADO") continue;
      if (e.estatus === "CONFIRMADO") {
        confirmado += e.tarifa;
        nConfirmado++;
      } else if (e.estatus === "PROSPECTO") {
        negociacion += e.tarifa;
        nNegociacion++;
      }
    }
    return { confirmado, nConfirmado, negociacion, nNegociacion };
  }, [eventos]);

  // ── Equipo próximo: lo que hay que rentar/preparar para lo que viene ────
  // Agrega las líneas de equipo de prospectos y confirmados con fecha por
  // delante, agrupadas por palabras clave (receptores, bodies, cabinas).
  const equipoProximo = useMemo(() => {
    if (!hoy) return null;
    let receptores = 0;
    let bodies = 0;
    let cabinas = 0;
    const otros = new Map<string, number>();
    let nEventos = 0;
    for (const e of eventos) {
      if (e.estatus !== "PROSPECTO" && e.estatus !== "CONFIRMADO") continue;
      if (!e.fechaInicio) continue;
      const ini = fechaDisplay(e.fechaInicio);
      if (ini === null || differenceInCalendarDays(ini, hoy) < 0) continue;
      if (e.equipo.length === 0) continue;
      nEventos++;
      for (const l of e.equipo) {
        const n = l.nombre.toLowerCase();
        // El orden importa: «Media cabina CON RECEPTORES» es una cabina,
        // no cuatro+ uno de receptores — la palabra más específica gana.
        if (/cabina/.test(n)) cabinas += l.cantidad;
        else if (/body|transmisor/.test(n)) bodies += l.cantidad;
        else if (/receptor|aud\u00edfono|audifono/.test(n)) receptores += l.cantidad;
        else otros.set(l.nombre, (otros.get(l.nombre) ?? 0) + l.cantidad);
      }
    }
    return { receptores, bodies, cabinas, otros: [...otros.entries()], nEventos };
  }, [eventos, hoy]);

  // ── Próximos servicios ─────────────────────────────────────────────────────
  // Lo ya realizado salió del radar de “lo que viene”.
  const proximos = useMemo(() => {
    if (!hoy) return [];
    return eventos
      .filter((e) => {
        if (
          e.estatus === "CANCELADO" ||
          e.estatus === "REALIZADO" ||
          !e.fechaInicio
        )
          return false;
        const ini = fechaDisplay(e.fechaInicio);
        return ini !== null && differenceInCalendarDays(ini, hoy) >= 0;
      })
      .sort((a, b) => (a.fechaInicio ?? "").localeCompare(b.fechaInicio ?? ""))
      .slice(0, 6);
  }, [eventos, hoy]);

  // ── Cancelaciones (con su motivo) ──────────────────────────────────────────
  const cancelados = useMemo(
    () => eventos.filter((e) => e.estatus === "CANCELADO"),
    [eventos]
  );

  // ── Top clientes: de dónde viene el dinero (y cuánto depende de uno solo) ──
  const topClientes = useMemo(() => {
    const mapa = new Map<string, { total: number; n: number }>();
    for (const e of eventos) {
      if (e.estatus === "CANCELADO") continue;
      const clave = e.cliente.trim();
      const dato = mapa.get(clave) ?? { total: 0, n: 0 };
      dato.total += e.tarifa;
      dato.n += 1;
      mapa.set(clave, dato);
    }
    const totalGeneral = [...mapa.values()].reduce((s, v) => s + v.total, 0);
    const filas = [...mapa.entries()]
      .map(([cliente, d]) => ({
        cliente,
        total: d.total,
        n: d.n,
        pct: totalGeneral > 0 ? Math.round((d.total / totalGeneral) * 100) : 0,
      }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);
    return { filas, totalGeneral };
  }, [eventos]);

  if (eventos.length === 0) {
    return (
      <div className="mt-4 grid place-items-center rounded-2xl border border-dashed border-linea-fuerte px-6 py-20 text-center">
        <p className="font-display text-xl text-tinta">
          El análisis empieza con el primer evento
        </p>
        <p className="mt-3 max-w-xs text-sm leading-relaxed text-tinta-muda">
          Cuando registres eventos, aquí verás tu cartera, tus cobros pendientes y
          lo que viene — todo en un solo vistazo.
        </p>
      </div>
    );
  }

  return (
    <div className="mt-4 space-y-4 pb-6">
      {/* Mini encabezado + exportación */}
      <div className="flex items-center justify-between gap-3 pt-1">
        <div>
          <h2 className="font-display text-xl text-tinta">Análisis</h2>
          <p className="text-[11px] text-tinta-muda">
            Lo que tu registro dice de tu negocio.
          </p>
        </div>
        <a
          href="/api/exportar"
          download
          className="inline-flex h-10 shrink-0 items-center gap-1.5 rounded-full border border-linea-fuerte px-4 text-xs font-medium text-tinta-suave transition-colors hover:border-acento/40 hover:text-acento-claro"
        >
          <Download className="h-3.5 w-3.5" aria-hidden />
          Exportar CSV
        </a>
      </div>

      {/* ── Lo que viene (con "Por pagar" — ronda 20) ── */}
      <Seccion titulo="Lo que viene">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div className="rounded-lg border border-linea-suave bg-panel px-3 py-2.5">
            <p className="flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wide text-tinta-muda">
              <CalendarCheck className="h-3 w-3 text-estado-confirmado" aria-hidden />
              Confirmado por venir
            </p>
            <p className="mt-1 font-display text-xl tracking-tight text-tinta">
              $ {formatoTarifa(caja.confirmado)}
            </p>
            <p className="text-[11px] text-tinta-muda">
              {caja.nConfirmado === 0
                ? "nada agendado aún"
                : `${caja.nConfirmado} ${caja.nConfirmado === 1 ? "evento" : "eventos"} asegurados`}
            </p>
          </div>
          <div className="rounded-lg border border-linea-suave bg-panel px-3 py-2.5">
            <p className="flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wide text-tinta-muda">
              <TrendingUp className="h-3 w-3 text-estado-prospecto" aria-hidden />
              En negociación
            </p>
            <p className="mt-1 font-display text-xl tracking-tight text-tinta">
              $ {formatoTarifa(caja.negociacion)}
            </p>
            <p className="text-[11px] text-tinta-muda">
              {caja.nNegociacion === 0
                ? "sin prospectos"
                : `${caja.nNegociacion} ${caja.nNegociacion === 1 ? "prospecto" : "prospectos"} por cerrar`}
            </p>
          </div>
          {/* Por pagar (ronda 20): lo que el dueño debe por eventos cobrados */}
          <div className="rounded-lg border border-linea-suave bg-panel px-3 py-2.5">
            <p className="flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wide text-tinta-muda">
              <Pocket className="h-3 w-3 text-estado-facturado" aria-hidden />
              Por pagar
            </p>
            <p className="mt-1 font-display text-xl tracking-tight text-tinta">
              $ {formatoTarifa(porPagar.total)}
            </p>
            <p className="text-[11px] text-tinta-muda">
              {porPagar.total === 0
                ? "nada pendiente de pagar"
                : `intérpretes $ ${formatoTarifa(porPagar.interpretes)} · equipo $ ${formatoTarifa(porPagar.equipo)}`}
            </p>
          </div>
        </div>
      </Seccion>

      {/* ── Directo vs Agencias + Variación vs mes anterior (ronda 20) ── */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Seccion titulo="Directo vs Agencias">
          {!origenes.hayDatos ? (
            <p className="py-4 text-center text-xs text-tinta-muda">
              Marca el origen en cada evento (directo, agencia o colega) y aquí
              verás de dónde viene el dinero trabajado.
            </p>
          ) : (
            <div className="space-y-3">
              <div className="flex h-2.5 gap-[3px] overflow-hidden rounded-full bg-linea-suave">
                <div
                  style={{ flexGrow: Math.max(origenes.directo, 1) }}
                  className="h-full rounded-full bg-estado-confirmado"
                />
                <div
                  style={{ flexGrow: Math.max(origenes.terceros, 1) }}
                  className="h-full rounded-full bg-estado-prospecto"
                />
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="inline-flex items-center gap-2 text-tinta-suave">
                    <span className="h-2 w-2 rounded-full bg-estado-confirmado" aria-hidden />
                    Directo
                  </span>
                  <span className="text-tinta">
                    $ {formatoTarifa(origenes.directo)} · {origenes.nDirecto}{" "}
                    {origenes.nDirecto === 1 ? "evento" : "eventos"}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="inline-flex items-center gap-2 text-tinta-suave">
                    <span className="h-2 w-2 rounded-full bg-estado-prospecto" aria-hidden />
                    Vía agencias / colegas
                  </span>
                  <span className="text-tinta">
                    $ {formatoTarifa(origenes.terceros)} · {origenes.nTerceros}{" "}
                    {origenes.nTerceros === 1 ? "evento" : "eventos"}
                  </span>
                </div>
              </div>
              <p className="text-[11px] text-tinta-muda">
                {origenes.pctTerceros}% del dinero trabajado llega vía terceros —
                así sabes cuánto pesa la cartera de agencias.
              </p>
            </div>
          )}
        </Seccion>

        <Seccion titulo="Variación vs mes anterior">
          {!meses ? (
            <p className="py-4 text-center text-xs text-tinta-muda">Cargando…</p>
          ) : (
            <div className="space-y-3">
              <div className="flex items-end justify-between gap-2">
                {meses.lista.map((m, i) => {
                  const max = Math.max(...meses.lista.map((x) => x.total), 1);
                  return (
                    <div key={i} className="flex min-w-0 flex-1 flex-col items-center gap-1">
                      <div
                        style={{ height: `${Math.max((m.total / max) * 56, 4)}px` }}
                        className={`w-full max-w-8 rounded-t-md ${
                          m.esActual
                            ? "bg-estado-facturado"
                            : m.esPrevio
                              ? "bg-acento/70"
                              : "bg-linea-fuerte"
                        }`}
                        title={`${m.etiqueta}: $ ${formatoTarifa(m.total)}`}
                      />
                      <span className="text-[9px] text-tinta-muda">{m.etiqueta}</span>
                    </div>
                  );
                })}
              </div>
              <div className="flex items-center justify-between gap-3 text-xs">
                <span className="text-tinta-muda">
                  Este mes{" "}
                  <span className="font-medium text-tinta">
                    $ {formatoTarifa(meses.actual)}
                  </span>
                </span>
                {meses.delta !== null ? (
                  <span
                    className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                      meses.delta >= 0
                        ? "bg-exito/15 text-exito"
                        : "bg-peligro/15 text-peligro"
                    }`}
                  >
                    {meses.delta >= 0 ? "↑" : "↓"} {Math.abs(meses.delta)}% vs mes anterior
                  </span>
                ) : (
                  <span className="text-[10px] text-tinta-muda">
                    sin base para comparar
                  </span>
                )}
              </div>
              <p className="text-[11px] text-tinta-muda">
                Ingresos ya cobrados por mes de servicio — el termómetro del negocio.
              </p>
            </div>
          )}
        </Seccion>
      </div>

      {/* ── Por cobrar (trabajados) ── */}
      <Seccion titulo="Por cobrar — trabajados" conteo={cobranza.length}>
        <p className="mb-1 font-display text-2xl tracking-tight text-acento-claro">
          $ {formatoTarifa(porCobrarTotal)}
          <span className="ml-2 text-[11px] font-medium tracking-normal text-tinta-muda">
            trabajo entregado, pendiente de cobro — sin lo ya cobrado
          </span>
        </p>
        {cobranza.length === 0 ? (
          <p className="py-6 text-center text-sm text-tinta-muda">
            Nada pendiente de cobro — todo liquidado.
          </p>
        ) : (
          <div className="divide-y divide-linea-suave">
            {cobranza.map((e) => {
              const saldo = saldoDe(e);
              const waTel = normalizarWhatsApp(e.telefono);
              const nombre = e.contacto ? e.contacto.split(" ")[0] : "";
              const msg = `Hola${nombre ? ` ${nombre}` : ""}, le escribo respecto al servicio de interpretación para ${e.cliente}. Le comparto el estado de la cuenta: saldo pendiente de $ ${formatoTarifa(saldo)} MXN. Quedo al pendiente por si tiene alguna duda. ¡Gracias!`;

              return (
                <div key={e.id} className="flex items-center gap-3 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-tinta">
                      {e.cliente}
                    </p>
                    <p className="mt-0.5 text-[11px]">
                      <span className="text-tinta-suave">
                        {e.fechaInicio ? rangoCorto(new Date(e.fechaInicio), e.fechaFin ? new Date(e.fechaFin) : null) : "sin fecha"}
                      </span>
                      {e.idEvento ? (
                        <span className="text-tinta-muda"> · {e.idEvento}</span>
                      ) : null}
                    </p>
                  </div>
                  <p className="shrink-0 font-display text-lg tracking-tight text-acento-claro">
                    $ {formatoTarifa(saldo)}
                  </p>
                  {waTel ? (
                    <a
                      href={`https://wa.me/${waTel}?text=${encodeURIComponent(msg)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`Enviar recordatorio de saldo — ${e.cliente}`}
                      title="Enviar recordatorio de saldo por WhatsApp"
                      className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-tinta-muda transition-colors hover:bg-exito/10 hover:text-exito"
                    >
                      <MessageCircle className="h-4 w-4" aria-hidden />
                    </a>
                  ) : null}
                </div>
              );
            })}
          </div>
        )}
      </Seccion>

      {/* ── Cancelaciones ── */}
      {cancelados.length > 0 ? (
        <Seccion titulo="Cancelaciones" conteo={cancelados.length}>
          <div className="divide-y divide-linea-suave">
            {cancelados.map((e) => {
              const ini = fechaDisplay(e.fechaInicio);
              const fin = fechaDisplay(e.fechaFin);
              return (
                <div key={e.id} className="flex items-center gap-3 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-tinta line-through decoration-tinta-muda">
                      {e.cliente}
                    </p>
                    <p className="mt-0.5 truncate text-[11px] text-tinta-muda">
                      {ini ? rangoCorto(ini, fin) : "sin fecha"}
                      {e.idEvento ? ` · ${e.idEvento}` : ""}
                      {e.razonCancelacion
                        ? ` · Motivo: ${e.razonCancelacion}`
                        : " · sin motivo"}
                    </p>
                  </div>
                  <p className="shrink-0 text-xs text-tinta-muda">
                    $ {formatoTarifa(e.tarifa)}
                  </p>
                </div>
              );
            })}
          </div>
        </Seccion>
      ) : null}

      {/* ── Próximos servicios ── */}
      <Seccion titulo="Próximos servicios" conteo={proximos.length}>
        {proximos.length === 0 ? (
          <p className="py-6 text-center text-sm text-tinta-muda">
            Sin servicios próximos con fecha registrada.
          </p>
        ) : (
          <div className="divide-y divide-linea-suave">
            {proximos.map((e) => {
              const ini = fechaDisplay(e.fechaInicio) as Date;
              const fin = fechaDisplay(e.fechaFin);
              const dias = hoy ? differenceInCalendarDays(ini, hoy) : null;
              const mod = MODALIDAD_CONFIG[e.modalidad];
              const modTexto =
                e.modalidad === "PRESENCIAL_CDMX"
                  ? "Presencial · CDMX"
                  : mod.conCiudad && e.ciudad
                    ? `${mod.label} · ${e.ciudad}`
                    : mod.label;
              return (
                <div key={e.id} className="flex items-center gap-3 py-3">
                  <p className="w-20 shrink-0 text-xs font-medium text-tinta-suave">
                    {rangoCorto(ini, fin)}
                  </p>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm text-tinta">{e.cliente}</p>
                    <p className="mt-0.5 truncate text-[11px] text-tinta-muda">
                      {e.idiomas ? `${e.idiomas} · ` : ""}
                      {modTexto}
                      {e.horario ? ` · ${e.horario}` : ""}
                    </p>
                  </div>
                  {dias !== null && dias <= 7 ? (
                    <span
                      className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-medium ${
                        dias === 0
                          ? "bg-acento/15 text-acento-claro"
                          : "bg-acento/10 text-acento-claro/80"
                      }`}
                    >
                      {dias === 0 ? "hoy" : dias === 1 ? "mañana" : `en ${dias} días`}
                    </span>
                  ) : null}
                </div>
              );
            })}
          </div>
        )}
      </Seccion>

      {/* ── Equipo próximo (sugerencia ronda 17) ── */}
      {/* Lo que hay que rentar o preparar para los servicios por venir:
          suma el equipo de prospectos y confirmados con fecha por delante. */}
      {equipoProximo ? (
        <Seccion titulo="Equipo próximo" conteo={equipoProximo.nEventos}>
          {equipoProximo.nEventos === 0 ? (
            <p className="py-6 text-center text-sm text-tinta-muda">
              Sin equipo registrado en lo que viene — agrégalo en el evento y
              aquí verás lo que necesitas rentar o preparar.
            </p>
          ) : (
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2">
                {equipoProximo.receptores > 0 ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-acento/30 bg-acento/[0.07] px-3 py-1 text-xs font-medium text-acento-claro">
                    <Headphones className="h-3 w-3" aria-hidden />
                    Receptores ·{" "}
                    <span className="font-display text-[13px]">
                      {formatoTarifa(equipoProximo.receptores)}
                    </span>
                  </span>
                ) : null}
                {equipoProximo.bodies > 0 ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-acento/30 bg-acento/[0.07] px-3 py-1 text-xs font-medium text-acento-claro">
                    <Headphones className="h-3 w-3" aria-hidden />
                    Bodies ·{" "}
                    <span className="font-display text-[13px]">
                      {formatoTarifa(equipoProximo.bodies)}
                    </span>
                  </span>
                ) : null}
                {equipoProximo.cabinas > 0 ? (
                  <span className="inline-flex items-center gap-1.5 rounded-full border border-acento/30 bg-acento/[0.07] px-3 py-1 text-xs font-medium text-acento-claro">
                    <Headphones className="h-3 w-3" aria-hidden />
                    Cabinas ·{" "}
                    <span className="font-display text-[13px]">
                      {formatoTarifa(equipoProximo.cabinas)}
                    </span>
                  </span>
                ) : null}
              </div>
              {equipoProximo.otros.length > 0 ? (
                <p className="text-[11px] text-tinta-muda">
                  Y también:{" "}
                  {equipoProximo.otros
                    .map(([n, c]) => `${c > 1 ? `${c} × ` : ""}${n}`)
                    .join(" · ")}
                </p>
              ) : null}
              <p className="text-[11px] text-tinta-muda">
                Suma de prospectos y confirmados con fecha por delante — tu
                lista de renta antes de la semana.
              </p>
            </div>
          )}
        </Seccion>
      ) : null}

      {/* ── Top clientes (sugerencia ronda 17) ── */}
      {/* De dónde viene el dinero: quiénes repiten y cuánto pesa cada uno. */}
      <Seccion titulo="Top clientes" conteo={topClientes.filas.length}>
        <div className="divide-y divide-linea-suave">
          {topClientes.filas.map((c, i) => (
            <div key={c.cliente} className="flex items-center gap-3 py-3">
              <span
                className={`w-5 shrink-0 text-right font-display text-sm ${
                  i === 0 ? "text-acento-claro" : "text-tinta-muda"
                }`}
              >
                {i + 1}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-tinta">
                  {c.cliente}
                </p>
                <p className="mt-0.5 text-[11px] text-tinta-muda">
                  {c.n} {c.n === 1 ? "servicio" : "servicios"} · {c.pct}% del registro
                </p>
              </div>
              <p className="shrink-0 font-display text-lg tracking-tight text-acento-claro">
                $ {formatoTarifa(c.total)}
              </p>
            </div>
          ))}
        </div>
      </Seccion>
    </div>
  );
}
