// Validación y normalización del payload de un evento.
// Compartido por POST (crear) y PUT (editar) para que ambos calculen
// igual los campos derivados: horario, días, tipo de bloque y fechas.
import {
  ESTATUS_VALIDOS,
  IDIOMAS_VALIDOS,
  IMPUESTOS_VALIDOS,
  MODALIDADES_VALIDAS,
  ORIGENES_VALIDOS,
  parsearFechas,
  parsearInterpretesExtra,
  parsearLineasEquipo,
  serializarEquipo,
  serializarFechas,
  serializarInterpretesExtra,
} from "./estatus";

const textoLimpio = (v: unknown): string | null => {
  if (typeof v !== "string") return null;
  const s = v.trim();
  return s === "" ? null : s;
};

const aFecha = (v: unknown): Date | null => {
  if (typeof v !== "string" || v.trim() === "") return null;
  // Las fechas de solo día ("2026-11-16") se anclan al mediodía UTC: el día
  // de calendario se conserva idéntico en cualquier zona horaria (UTC puro
  // las dejaría a medianoche, y en México se verían un día antes).
  const s = v.trim();
  const d = /^\d{4}-\d{2}-\d{2}$/.test(s) ? new Date(`${s}T12:00:00Z`) : new Date(s);
  return Number.isNaN(d.getTime()) ? null : d;
};

const minutos = (h: string | null): number | null => {
  if (!h || !/^\d{1,2}:\d{2}$/.test(h)) return null;
  const [H, M] = h.split(":").map(Number);
  return H * 60 + M;
};

const diasEntre = (inicio: Date, fin: Date) =>
  Math.round((fin.getTime() - inicio.getTime()) / 86400000) + 1;

const numeroPositivo = (v: unknown): number | null => {
  if (v == null || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : null;
};

export type PayloadEvento = {
  cliente: string;
  contacto: string | null;
  telefono: string | null;
  correo: string | null;
  idiomas: string | null;
  nombreEvento: string | null;
  origen: string | null;
  estatus: string;
  razonCancelacion: string | null;
  fechasTexto: string | null;
  fechas: string | null; // JSON de fechas ISO (dispersas ok)
  fechaInicio: Date | null;
  fechaFin: Date | null;
  dias: number | null;
  horaInicio: string | null;
  horaFin: string | null;
  horario: string | null;
  tipoBloque: string | null;
  diaCompleto: boolean;
  tema: string | null;
  modalidad: string;
  ciudad: string | null;
  tarifa: number;
  tarifaPorDia: number | null;
  impuestosTipo: string | null;
  ivaEnCotizacion: boolean;
  viaticos: number | null;
  interpretesExtra: string | null; // JSON de InterpreteExtra[]
  linkGlosario: string | null;
  notas: string | null;
  equipo: string | null; // JSON de LineaEquipo[] serializado para la base
};

export type ResultadoPayload =
  | { ok: true; data: PayloadEvento }
  | { ok: false; error: string };

export function parsearEventoPayload(
  body: Record<string, unknown> | null
): ResultadoPayload {
  if (!body) return { ok: false, error: "Cuerpo inválido" };

  const cliente = textoLimpio(body.cliente);
  if (!cliente) {
    return { ok: false, error: "El cliente es obligatorio" };
  }

  const tarifaNum = Number(body.tarifa);
  if (!Number.isFinite(tarifaNum) || tarifaNum < 0) {
    return { ok: false, error: "Tarifa inválida" };
  }

  const estatus = (ESTATUS_VALIDOS as string[]).includes(body.estatus as string)
    ? (body.estatus as string)
    : "PROSPECTO";
  const modalidad = (MODALIDADES_VALIDAS as string[]).includes(
    body.modalidad as string
  )
    ? (body.modalidad as string)
    : "PRESENCIAL_CDMX";
  const esForaneo = modalidad === "FORANEO";

  // Ronda 20: quién trajo el evento (para "Directo vs Agencias").
  const origen = (ORIGENES_VALIDOS as readonly string[]).includes(
    body.origen as string
  )
    ? (body.origen as string)
    : null;

  // ── Fechas dispersas ──
  // La fuente de verdad es la lista de días elegidos (calendario de ronda 20,
  // con arrastre y selección individual). Los eventos viejos sin lista caen
  // al rango clásico inicio–fin.
  const fechasLista = parsearFechas(body.fechas);
  let fechaInicio: Date | null;
  let fechaFin: Date | null;
  let dias: number | null;
  if (fechasLista.length > 0) {
    fechaInicio = aFecha(fechasLista[0]);
    fechaFin = aFecha(fechasLista[fechasLista.length - 1]);
    dias = fechasLista.length;
  } else {
    fechaInicio = aFecha(body.fechaInicio);
    fechaFin = aFecha(body.fechaFin);
    dias =
      fechaInicio && fechaFin
        ? diasEntre(fechaInicio, fechaFin)
        : fechaInicio
          ? 1
          : null;
  }

  // ── Horario ──
  // "Día completo" (ronda 20): jornada sin horas específicas — sólo el CDM
  // lo ofrece; el sitio WQZ siempre elige horas con el reloj.
  const diaCompleto = body.diaCompleto === true;
  const horaInicio = diaCompleto ? null : textoLimpio(body.horaInicio);
  const horaFin = diaCompleto ? null : textoLimpio(body.horaFin);
  const horario =
    horaInicio && horaFin ? `${horaInicio} - ${horaFin}` : horaInicio || null;

  const idiomas = textoLimpio(body.idiomas);
  const idiomasValido =
    idiomas && (IDIOMAS_VALIDOS as readonly string[]).includes(idiomas)
      ? idiomas
      : null;

  const impuestosRaw = textoLimpio(body.impuestosTipo);
  const impuestosTipo =
    impuestosRaw && (IMPUESTOS_VALIDOS as string[]).includes(impuestosRaw)
      ? impuestosRaw
      : null;

  const tarifaPorDia = numeroPositivo(body.tarifaPorDia);

  const hi = minutos(horaInicio);
  const hf = minutos(horaFin);
  const tipoBloque =
    hi !== null && hf !== null && hf > hi
      ? hf - hi >= 360
        ? "Jornada Completa"
        : hf - hi >= 180
          ? "Medio Día"
          : "Por Hora"
      : diaCompleto
        ? "Jornada Completa"
        : null;

  // ── Equipo (ronda 17): llegan como array desde el formulario; se sanean y
  // se guardan como JSON. Las líneas sin nombre se descartan aquí mismo.
  const equipo = serializarEquipo(parsearLineasEquipo(body.equipo));

  // ── Intérpretes extra y viáticos (ronda 20): los viáticos — propios y
  // ajenos — sólo existen en eventos foráneos; el resto del tiempo viajan
  // en null para no ensuciar la base.
  const interpretesExtra = serializarInterpretesExtra(
    parsearInterpretesExtra(
      Array.isArray(body.interpretesExtra)
        ? (body.interpretesExtra as unknown[]).map((i) => {
            const o = (i ?? {}) as Record<string, unknown>;
            return {
              nombre: o.nombre,
              tarifa: numeroPositivo(o.tarifa),
              viaticos: esForaneo ? numeroPositivo(o.viaticos) : null,
            };
          })
        : []
    )
  );
  const viaticos = esForaneo ? numeroPositivo(body.viaticos) : null;

  return {
    ok: true,
    data: {
      cliente,
      contacto: textoLimpio(body.contacto),
      telefono: textoLimpio(body.telefono),
      correo: textoLimpio(body.correo),
      idiomas: idiomasValido,
      nombreEvento: textoLimpio(body.nombreEvento),
      origen,
      estatus,
      razonCancelacion: textoLimpio(body.razonCancelacion),
      fechasTexto: textoLimpio(body.fechasTexto),
      fechas: serializarFechas(fechasLista),
      fechaInicio,
      fechaFin,
      dias,
      horaInicio,
      horaFin,
      horario,
      tipoBloque,
      diaCompleto,
      tema: textoLimpio(body.tema),
      modalidad,
      ciudad: esForaneo ? textoLimpio(body.ciudad) : null,
      tarifa: tarifaNum,
      tarifaPorDia,
      impuestosTipo,
      ivaEnCotizacion: body.ivaEnCotizacion !== false,
      viaticos,
      interpretesExtra,
      linkGlosario: textoLimpio(body.linkGlosario),
      notas: textoLimpio(body.notas),
      equipo,
    },
  };
}
