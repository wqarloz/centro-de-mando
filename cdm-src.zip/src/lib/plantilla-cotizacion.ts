// ─────────────────────────────────────────────────────────────────────────────
// Plantilla oficial de cotización (v0.9, la de la casa) — HTML 794×1123.
//
// Réplica exacta de Cotizacion-COT-8239-muestra-v0.9.html: mismo lienzo,
// mismas ondas de voz, mismos paneles de vidrio. El CDM llena los huecos con
// los datos del evento — equipo incluido, conceptos con costo y toda la
// matemática de la ronda 17 — y Chromium la imprime a PDF.
//
// Reglas de datos:
//   · Folio: el de la web (COT-XXXX) si existe; si no, COT- + código interno.
//   · Nombre del evento: se rescata de las notas («Evento: …», llegada del
//     sitio) o del tema/industria.
//   · Intérpretes: 1 + las líneas de equipo que mencionen intérpretes
//     (p. ej. «Body — segundo intérprete»); sólo se enseña cuando son 2+.
//   · Lo interno del equipo (enCotizacion = false) nunca aparece.
// ─────────────────────────────────────────────────────────────────────────────
import { FUENTES_CASA_CSS } from "./fuentes-casa";
import {
  parseEquipo,
  parseFechas,
  parseInterpretesExtra,
  resumenFechas,
  type EventoFila,
  type InterpreteExtra,
  type LineaEquipo,
} from "./estatus";

const esc = (s: string) =>
  s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

/** Dinero determinista: 9280 → "9,280.00" (sin depender del locale). */
export function dinero(n: number): string {
  const v = Math.round(n * 100) / 100;
  const [ent, dec] = v.toFixed(2).split(".");
  const conComas = ent.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${conComas}.${dec}`;
}

const MESES = [
  "enero", "febrero", "marzo", "abril", "mayo", "junio",
  "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
];

function fechaLarga(iso: string): string {
  const d = new Date(iso);
  return `${d.getUTCDate()} de ${MESES[d.getUTCMonth()]} de ${d.getUTCFullYear()}`;
}

/** Hoy en horario de México (UTC−6 fijo): la fecha que ve el cliente. */
export function hoyMexicoIso(): string {
  return new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString();
}

function rangoFechas(iniIso: string, finIso: string | null): string {
  const ini = new Date(iniIso);
  if (!finIso) return fechaLarga(iniIso);
  const fin = new Date(finIso);
  const mismoDia =
    ini.getUTCFullYear() === fin.getUTCFullYear() &&
    ini.getUTCMonth() === fin.getUTCMonth() &&
    ini.getUTCDate() === fin.getUTCDate();
  if (mismoDia) return fechaLarga(iniIso);
  const anio = ini.getUTCFullYear();
  if (ini.getUTCFullYear() === fin.getUTCFullYear()) {
    if (ini.getUTCMonth() === fin.getUTCMonth()) {
      return `${ini.getUTCDate()} – ${fin.getUTCDate()} de ${MESES[fin.getUTCMonth()]} de ${anio}`;
    }
    return (
      `${ini.getUTCDate()} de ${MESES[ini.getUTCMonth()]} – ` +
      `${fin.getUTCDate()} de ${MESES[fin.getUTCMonth()]} de ${anio}`
    );
  }
  return `${fechaLarga(iniIso)} – ${fechaLarga(finIso)}`;
}

/** "EN - ES" → "Inglés → Español" (la flecha de la plantilla). */
function idiomasTexto(idiomas: string | null): string {
  if (idiomas === "EN - ES") return "Inglés → Español";
  if (idiomas === "PO - ES") return "Portugués → Español";
  return "Idiomas por definir";
}

function modalidadTexto(mod: string, ciudad: string | null): string {
  if (mod === "PRESENCIAL_CDMX") return "Presencial · Ciudad de México";
  if (mod === "REMOTO") return "Remoto · en línea";
  return ciudad ? `Presencial · ${ciudad}` : "Presencial · ciudad por confirmar";
}

/** El nombre del evento (ronda 20): campo propio; sin rescates. Sin
 *  nombre, el subtítulo simplemente no aparece. */
function nombreEvento(fila: EventoFila): string | null {
  return fila.nombreEvento?.trim() || null;
}

/** Fecha larga de una lista de días dispersos: contiguas se pliegan.
 *  [18,19,20,24 nov] → "18 – 20 y 24 de noviembre de 2026". */
function fechasLargaDeLista(lista: string[]): string {
  const grupos: [string, string][] = [];
  for (const k of lista) {
    const ultimo = grupos[grupos.length - 1];
    if (ultimo) {
      const unDia =
        new Date(ultimo[1] + "T12:00:00Z").getTime() + 86400000;
      if (new Date(k + "T12:00:00Z").getTime() === unDia) {
        ultimo[1] = k;
        continue;
      }
    }
    grupos.push([k, k]);
  }
  const primerAnio = lista[0].slice(0, 4);
  const partes = grupos.map(([ini, fin]) => {
    const a = new Date(ini + "T12:00:00Z");
    const b = new Date(fin + "T12:00:00Z");
    const mes = MESES[a.getUTCMonth()];
    const anio = ini.slice(0, 4) !== primerAnio ? ` de ${ini.slice(0, 4)}` : "";
    if (ini === fin) return `${a.getUTCDate()} de ${mes}${anio}`;
    if (a.getUTCMonth() === b.getUTCMonth())
      return `${a.getUTCDate()} – ${b.getUTCDate()} de ${mes}${anio}`;
    return `${a.getUTCDate()} de ${mes} – ${b.getUTCDate()} de ${MESES[b.getUTCMonth()]}${anio}`;
  });
  return `${partes.join(" y ")} de ${primerAnio}`;
}

/** Jornada legible con horas: "Jornada completa · 8 h". */
function jornadaTexto(tipoBloque: string | null, hi: string | null, hf: string | null): string | null {
  if (!tipoBloque) return null;
  const bonito = tipoBloque === "Jornada Completa" ? "Jornada completa" : tipoBloque;
  const minutos = (h: string) => {
    const m = /^(\d{1,2}):(\d{2})$/.exec(h ?? "");
    return m ? Number(m[1]) * 60 + Number(m[2]) : null;
  };
  const a = minutos(hi ?? "");
  const b = minutos(hf ?? "");
  if (a !== null && b !== null && b > a) {
    const h = (b - a) / 60;
    return `${bonito} · ${Number.isInteger(h) ? h : h.toFixed(1)} h`;
  }
  return bonito;
}

// ── Bloques HTML ─────────────────────────────────────────────────────────────

function concepto(titulo: string, subtitulo: string | null, importe: string, unitario: string | null): string {
  return `      <div class="concepto">
        <div class="cuerpo">
          <b>${esc(titulo)}</b>
          ${subtitulo ? `<span>${esc(subtitulo)}</span>` : ""}
        </div>
        <div class="importe">
          <b>${esc(importe)}</b>
          ${unitario ? `<small>${esc(unitario)}</small>` : ""}
        </div>
      </div>`;
}

function campo(label: string, valor: string, destacado = false): string {
  return `        <div class="campo">
          <label>${esc(label)}</label>
          <div class="valor">${destacado ? `<span class="destacado">${esc(valor)}</span>` : esc(valor)}</div>
        </div>`;
}

// ── El lienzo completo ───────────────────────────────────────────────────────

export function htmlCotizacion(fila: EventoFila): string {
  // Ronda 20: todo el equipo viaja a la cotización (el interruptor por
  // línea se retiró). Con precio se cobra; sin precio, "incluido".
  const equipo = parseEquipo(fila.equipo);
  const conCosto = equipo.filter((l) => l.precio);
  const incluidos = equipo.filter((l) => !l.precio);
  const extras = parseInterpretesExtra(fila.interpretesExtra);
  const extrasConTarifa = extras.filter((i) => (i.tarifa ?? 0) > 0);

  const tarifa = fila.tarifa ?? 0;
  const totalEquipo = conCosto.reduce((s, l) => s + (l.precio ?? 0) * l.cantidad, 0);
  // Viáticos (sólo foráneos): los del dueño + los de los intérpretes extra
  // en una sola línea. Passthrough del cliente — nunca ingreso propio.
  const totalViaticos =
    (fila.viaticos ?? 0) +
    extras.reduce((s, i) => s + (i.viaticos ?? 0), 0);
  const conIva = fila.ivaEnCotizacion !== false;

  // Interpretación completa al cliente: el servicio propio + los extra
  // (los de tarifa igual se pliegan; los demás, línea propia).
  const nMismaTarifa = extrasConTarifa.filter((i) => (i.tarifa ?? 0) === tarifa).length;
  const extrasOtraTarifa = extrasConTarifa.filter((i) => (i.tarifa ?? 0) !== tarifa);
  const totalInterpretacion =
    tarifa * (1 + nMismaTarifa) +
    extrasOtraTarifa.reduce((s, i) => s + (i.tarifa ?? 0), 0);

  const subtotal = totalInterpretacion + totalEquipo + totalViaticos;
  const iva = conIva ? subtotal * 0.16 : 0;

  const folio =
    fila.folio ??
    "COT-" + (fila.idEvento ? fila.idEvento.replace(/^EV-/, "") : fila.id.slice(-4).toUpperCase());

  const evento = nombreEvento(fila);
  const idiomas = idiomasTexto(fila.idiomas);
  const horario = fila.horario ? fila.horario.replace(" - ", " – ") : null;
  const jornada = fila.diaCompleto
    ? "Día completo"
    : jornadaTexto(fila.tipoBloque, fila.horaInicio, fila.horaFin);
  const listaFechas = parseFechas(fila.fechas);
  const fechas =
    listaFechas.length > 0
      ? fechasLargaDeLista(listaFechas)
      : fila.fechaInicio
        ? rangoFechas(fila.fechaInicio.toISOString(), fila.fechaFin?.toISOString() ?? null)
        : fila.fechasTexto || "Por definir";
  const dias = listaFechas.length > 0 ? listaFechas.length : fila.dias;
  const duracion = dias
    ? `${dias} ${dias === 1 ? "día de servicio" : "días de servicio"}`
    : "Por definir";

  // Intérpretes: 1 (el dueño) + los extra registrados.
  const nInterpretes = 1 + extras.length;
  const interpretesTxt = nInterpretes >= 2 ? `${nInterpretes} intérpretes en cabina` : null;

  // ── Preparado para ──
  const contacto: string[] = [];
  if (fila.correo) contacto.push(esc(fila.correo));
  if (fila.telefono) contacto.push(esc(fila.telefono));

  // ── Detalle del servicio ──
  const campos: string[] = [];
  campos.push(campo("Fechas", fechas));
  campos.push(campo("Duración", duracion));
  if (horario) campos.push(campo("Horario", horario));
  if (jornada) campos.push(campo("Jornada", jornada, true));
  campos.push(campo("Idiomas", idiomas, true));
  campos.push(campo("Modalidad", modalidadTexto(fila.modalidad, fila.ciudad)));
  if (fila.tema) campos.push(campo("Tema / industria", fila.tema));
  if (interpretesTxt) campos.push(campo("Intérpretes", interpretesTxt));

  // ── Inversión ──
  let inversion: string;
  if (tarifa > 0) {
    const subtituloInterpretacion =
      [interpretesTxt, jornada ? jornada.split(" · ")[0].toLowerCase() : null]
        .filter(Boolean)
        .join(" · ") || null;

    // El A4 es fijo: más de 8 conceptos de equipo y el panel no cabe. Los
    // extras se pliegan en una sola línea con su total (la escala de la
    // impresión acomoda lo demás).
    const MAX_EQUIPO_PDF = 8;
    const equipoPdf = [...conCosto, ...incluidos].slice(0, MAX_EQUIPO_PDF);
    const extra = [...conCosto, ...incluidos].slice(MAX_EQUIPO_PDF);
    const extraConCosto = extra.reduce((s, l) => s + (l.precio ?? 0) * l.cantidad, 0);

    // ── Interpretación: los extra con la MISMA tarifa se pliegan en un
    // solo concepto multiplicado ("2 servicios de interpretación simultánea");
    // con tarifas distintas, cada uno lleva su propia línea con su nombre.
    const conceptos: string[] = [];
    const extrasMismaTarifa = extrasConTarifa.filter(
      (i) => (i.tarifa ?? 0) === tarifa
    );
    const nServicios = 1 + nMismaTarifa;
    conceptos.push(
      concepto(
        nServicios > 1
          ? `${nServicios} servicios de interpretación simultánea · ${idiomas}`
          : `Interpretación simultánea · ${idiomas}`,
        subtituloInterpretacion,
        `$ ${dinero(tarifa * nServicios)}`,
        nServicios > 1
          ? `$ ${dinero(tarifa)} c/u × ${nServicios} servicios`
          : fila.tarifaPorDia && dias && dias > 1
            ? `$ ${dinero(fila.tarifaPorDia)} × ${dias} días`
            : null
      )
    );
    for (const i of extrasOtraTarifa) {
      conceptos.push(
        concepto(
          `Interpretación simultánea · ${i.nombre}`,
          null,
          `$ ${dinero(i.tarifa ?? 0)}`,
          null
        )
      );
    }
    // ── Viáticos (foráneo): una sola línea, los de todos los intérpretes.
    if (totalViaticos > 0) {
      conceptos.push(
        concepto(
          "Viáticos",
          extras.length > 0 ? `incluye los de ${nInterpretes} intérpretes` : null,
          `$ ${dinero(totalViaticos)}`,
          null
        )
      );
    }
    conceptos.push(
      ...equipoPdf.map((l) =>
        l.precio
          ? concepto(
              l.nombre,
              `$ ${dinero(l.precio)} c/u${l.cantidad > 1 ? ` × ${l.cantidad}` : ""}`,
              `$ ${dinero(l.precio * l.cantidad)}`,
              null
            )
          : concepto(l.nombre, null, "Incluido", null)
      )
    );
    if (extra.length > 0) {
      conceptos.push(
        concepto(
          `Equipo adicional (${extra.length} ${extra.length === 1 ? "concepto" : "conceptos"} más)`,
          null,
          extraConCosto > 0 ? `$ ${dinero(extraConCosto)}` : "Incluido",
          null
        )
      );
    }
    inversion = `    <section class="panel inversion">
${conceptos.join("\n")}

      <div class="fila-suma">
        <span>Subtotal</span>
        <b>$ ${dinero(subtotal)}</b>
      </div>
      ${conIva
        ? `<div class="fila-suma">
        <span>IVA (16 %)</span>
        <b>$ ${dinero(iva)}</b>
      </div>`
        : ""}
      <div class="total">
        <span>Total</span>
        <b>$ ${dinero(subtotal + iva)}<small>MXN</small></b>
      </div>
      <div class="condiciones">
        <span class="vigencia">Vigencia: 15 días naturales</span>
        <p class="nota">Importes en pesos mexicanos (MXN).${
          conIva ? "" : " IVA no incluido."
        } La disponibilidad de las fechas queda sujeta a confirmación.</p>
      </div>
    </section>`;
  } else {
    inversion = `    <section class="panel inversion">
      <p class="nota" style="margin: 6px 2px;">Inversión por definir — la cotización se completa al definir la tarifa del servicio.</p>
    </section>`;
  }

  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cotización ${esc(folio)} — ${esc(fila.cliente)}</title>
<style>
${FUENTES_CASA_CSS}

  /* ── Lienzo fijo A4 (794 × 1123 px CSS) · plantilla oficial de la casa ── */
  @page { size: 794px 1123px; margin: 0; }

  * { margin: 0; padding: 0; box-sizing: border-box; }
  html, body { margin: 0; padding: 0; width: 794px; background: #EFF5F1; }
  body { font-family: "Manrope", system-ui, sans-serif; color: #212226; }

  :root {
    --tinta: #212226; --gris: #6B716D; --acento: #137547; --titular: #054A29;
    --esmeralda: #5BBA6F; --oro: #B08D57;
    --vidrio: rgba(255,255,255,.38); --chip: rgba(255,255,255,.30);
    --borde: rgba(255,255,255,.60); --borde-verde: rgba(19,117,71,.28);
    --filete-verde: rgba(19,117,71,.14); --filete-oro: rgba(176,141,87,.45);
  }

  .page {
    width: 794px; height: 1123px; position: relative;
    background:
      radial-gradient(560px 420px at 6% 2%,  rgba(91,186,111,.26), transparent 70%),
      radial-gradient(520px 420px at 97% 34%, rgba(176,141,87,.20), transparent 70%),
      radial-gradient(1100px 760px at 50% 20%, #F2F8F4 0%, #EFF5F1 58%, #E5EDE7 100%);
  }

  /* ── Ondas de voz (estáticas, vectoriales, dentro del lienzo) ─────────── */
  .tira { position: absolute; top: 0; bottom: 0; width: 118px; }
  .tira.izq { left: 0; }
  .tira.der { right: 0; }
  .tira svg { display: block; width: 118px; height: 1123px; }

  /* ── Columna de contenido (margen ≥ 92 px: jamás toca las tiras) ──────── */
  .contenido { position: relative; width: 596px; height: 1123px; margin: 0 auto;
    padding: 40px 0 28px; display: flex; flex-direction: column; }

  /* ── Cabecera ──────────────────────────────────────────────────────────── */
  .cabecera { display: flex; align-items: center; gap: 16px; }
  .tile {
    width: 56px; height: 56px; flex: none; border-radius: 16px;
    display: grid; place-items: center;
    background: var(--chip); border: 1px solid rgba(176,141,87,.55);
    box-shadow: 0 12px 30px rgba(5,74,41,.13), inset 0 1px 0 rgba(255,255,255,.75);
  }
  .rombo-grande { width: 27px; height: 27px; border: 1.5px solid var(--oro);
    transform: rotate(45deg); display: grid; place-items: center; border-radius: 4px;
    outline: 1px solid var(--oro); outline-offset: 3.5px; }
  .rombo-grande span { transform: rotate(-45deg); font-weight: 800; font-size: 9px;
    color: var(--titular); letter-spacing: .4px; }
  .quien { line-height: 1.25; }
  .quien b { font-size: 16px; letter-spacing: .2px; color: var(--titular); }
  .quien small { display: block; font-size: 9.5px; letter-spacing: 2.4px;
    color: var(--acento); font-weight: 700; margin-top: 3px; }
  .folio { margin-left: auto; text-align: right; line-height: 1.3; }
  .folio b { font-size: 19px; font-weight: 800; color: var(--titular); letter-spacing: .3px; }
  .folio small { display: block; font-size: 10.5px; color: var(--gris); margin-top: 3px; }

  .filete-oro { height: 1px; background: var(--filete-oro); margin: 16px 0 0; }

  /* ── Título + nombre del evento ────────────────────────────────────────── */
  h1 { margin-top: 18px; font-size: 27px; font-weight: 800; color: var(--titular);
    letter-spacing: -.3px; line-height: 1.15; }
  h1 em { font-family: "Playfair It", Georgia, serif; font-style: italic;
    color: var(--acento); font-weight: 400; }
  .evento { margin-top: 6px; font-family: "Playfair It", Georgia, serif;
    font-style: italic; font-size: 15px; color: var(--acento); }

  /* ── Secciones ─────────────────────────────────────────────────────────── */
  .etiqueta { display: flex; align-items: center; gap: 12px; margin: 18px 0 9px;
    font-size: 10px; letter-spacing: 2.6px; color: var(--acento);
    font-weight: 700; text-transform: uppercase; }
  .etiqueta::after { content: ""; height: 1px; flex: 1;
    background: var(--acento); opacity: .35; }

  .panel {
    border-radius: 18px; padding: 14px 16px;
    background: var(--vidrio); border: 1px solid var(--borde);
    box-shadow: 0 14px 36px rgba(5,74,41,.16), inset 0 1px 0 rgba(255,255,255,.9);
  }

  /* ── Preparado para ────────────────────────────────────────────────────── */
  .cliente { display: flex; gap: 18px; }
  .cliente .bloque { flex: 1; }
  .cliente .bloque.principal { flex: 1.15; }
  .cliente .rotulo { font-size: 9.5px; letter-spacing: 1.8px; text-transform: uppercase;
    color: var(--gris); font-weight: 700; margin-bottom: 5px; }
  .cliente .empresa { font-size: 15.5px; font-weight: 800; color: var(--titular); }
  .cliente .persona { font-size: 13px; color: var(--tinta); margin-top: 3px; }
  .cliente .dato { font-size: 12.5px; color: var(--tinta); margin-top: 3px; }
  .cliente .separador { width: 1px; background: var(--filete-verde); }

  /* ── Detalle del servicio ──────────────────────────────────────────────── */
  .campos { display: grid; grid-template-columns: 1fr 1fr; gap: 8px 12px; }
  .campo label { display: block; font-size: 9.5px; letter-spacing: 1.6px;
    text-transform: uppercase; color: var(--gris); font-weight: 700; margin-bottom: 4px; }
  .campo .valor {
    font-size: 13.5px; font-weight: 700; color: var(--tinta);
    padding: 7px 12px; border-radius: 11px;
    background: var(--chip); border: 1px solid var(--borde-verde);
    box-shadow: inset 0 1px 0 rgba(255,255,255,.75);
  }
  .campo .valor .destacado { color: var(--acento); }

  /* ── Inversión (por conceptos) ─────────────────────────────────────────── */
  .concepto { display: flex; justify-content: space-between; align-items: center;
    gap: 16px; padding: 11px 2px; border-bottom: 1px solid var(--filete-verde); }
  .concepto + .concepto { margin-top: 2px; }
  .concepto .cuerpo b { display: block; font-size: 14px; font-weight: 800;
    color: var(--tinta); letter-spacing: .1px; line-height: 1.3; }
  .concepto .cuerpo span { display: block; font-size: 11.5px; color: var(--gris);
    margin-top: 3px; }
  .concepto .importe { text-align: right; flex: none; }
  .concepto .importe b { display: block; font-size: 15.5px; color: var(--tinta); }
  .concepto .importe small { display: block; font-size: 11px; color: var(--gris);
    margin-top: 3px; }
  .fila-suma { display: flex; justify-content: space-between; padding: 7px 2px;
    font-size: 13.5px; }
  .fila-suma span { color: var(--gris); }
  .fila-suma b { font-weight: 700; color: var(--tinta); }
  .total { display: flex; justify-content: space-between; align-items: baseline;
    margin-top: 6px; padding-top: 10px; border-top: 1px solid var(--filete-verde); }
  .total span { font-size: 13px; color: var(--gris); font-weight: 700; letter-spacing: .3px; }
  .total b { font-size: 26px; font-weight: 800; color: var(--titular); letter-spacing: .2px; }
  .total b small { font-size: 13px; font-weight: 700; color: var(--acento);
    letter-spacing: .5px; margin-left: 6px; }
  .condiciones { display: flex; align-items: center; gap: 12px; margin-top: 10px;
    flex-wrap: wrap; }
  .vigencia { display: inline-block; font-size: 11.5px; font-weight: 700; color: var(--titular);
    padding: 6px 14px; border-radius: 999px;
    background: rgba(91,186,111,.20); border: 1px solid var(--borde-verde); }
  .condiciones .nota { font-size: 11px; color: var(--gris); line-height: 1.5; flex: 1; min-width: 200px; }

  /* ── Pie (anclado al borde inferior del A4) ────────────────────────────── */
  .pie { margin-top: auto; padding-top: 16px; border-top: 1px solid var(--filete-oro);
    text-align: center; }
  .pie b { font-size: 10px; letter-spacing: 2.4px; color: var(--gris);
    text-transform: uppercase; }
  .pie p { margin-top: 6px; font-size: 12px; color: var(--tinta); }
  .pie .idiomas { margin-top: 4px; font-size: 10px; color: var(--acento);
    font-weight: 700; letter-spacing: 1.6px; text-transform: uppercase; }

  /* ── Vista previa en navegador (auto-escala; no afecta al PDF) ────────── */
  @media screen {
    html { height: auto; display: flex; justify-content: center; background: #EFF5F1; }
    body { transform-origin: top center;
      scale: min(1, calc(100vw / 794), calc(100vh / 1123));
      margin: 0 auto; box-shadow: 0 0 60px rgba(5,74,41,.25); }
  }
</style>
</head>
<body>
<div class="page">

  <!-- ondas de voz · izquierda (la voz entra) -->
  <div class="tira izq" aria-hidden="true">
    <svg viewBox="0 0 118 1123" preserveAspectRatio="none">
      <defs>
        <linearGradient id="ondaG-i" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#2A9134" stop-opacity="0"/>
          <stop offset=".5" stop-color="#5BBA6F" stop-opacity=".8"/>
          <stop offset="1" stop-color="#2A9134" stop-opacity="0"/>
        </linearGradient>
        <linearGradient id="ondaOro-i" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#B08D57" stop-opacity="0"/>
          <stop offset=".5" stop-color="#B08D57" stop-opacity=".85"/>
          <stop offset="1" stop-color="#B08D57" stop-opacity="0"/>
        </linearGradient>
      </defs>
      <rect x="16" y="404" width="17" height="315" rx="8.5" fill="url(#ondaG-i)" opacity=".16"/>
      <rect x="19" y="416" width="11" height="291" rx="5.5" fill="url(#ondaG-i)" opacity=".62"/>
      <rect x="52" y="284" width="17" height="555" rx="8.5" fill="url(#ondaOro-i)" opacity=".16"/>
      <rect x="55" y="296" width="11" height="531" rx="5.5" fill="url(#ondaOro-i)" opacity=".6"/>
      <rect x="88" y="452" width="17" height="219" rx="8.5" fill="url(#ondaG-i)" opacity=".16"/>
      <rect x="91" y="464" width="11" height="195" rx="5.5" fill="url(#ondaG-i)" opacity=".55"/>
      <circle cx="30" cy="330" r="3.2" fill="#5BBA6F" opacity=".5"/>
      <circle cx="66" cy="700" r="2.6" fill="#B08D57" opacity=".45"/>
      <circle cx="99" cy="520" r="2.4" fill="#5BBA6F" opacity=".4"/>
    </svg>
  </div>

  <!-- ondas de voz · derecha (la voz sale) -->
  <div class="tira der" aria-hidden="true">
    <svg viewBox="0 0 118 1123" preserveAspectRatio="none">
      <defs>
        <linearGradient id="ondaG-d" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#2A9134" stop-opacity="0"/>
          <stop offset=".5" stop-color="#5BBA6F" stop-opacity=".8"/>
          <stop offset="1" stop-color="#2A9134" stop-opacity="0"/>
        </linearGradient>
        <linearGradient id="ondaOro-d" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#B08D57" stop-opacity="0"/>
          <stop offset=".5" stop-color="#B08D57" stop-opacity=".85"/>
          <stop offset="1" stop-color="#B08D57" stop-opacity="0"/>
        </linearGradient>
      </defs>
      <rect x="85" y="404" width="17" height="315" rx="8.5" fill="url(#ondaG-d)" opacity=".16"/>
      <rect x="88" y="416" width="11" height="291" rx="5.5" fill="url(#ondaG-d)" opacity=".62"/>
      <rect x="49" y="284" width="17" height="555" rx="8.5" fill="url(#ondaOro-d)" opacity=".16"/>
      <rect x="52" y="296" width="11" height="531" rx="5.5" fill="url(#ondaOro-d)" opacity=".6"/>
      <rect x="13" y="452" width="17" height="219" rx="8.5" fill="url(#ondaG-d)" opacity=".16"/>
      <rect x="16" y="464" width="11" height="195" rx="5.5" fill="url(#ondaG-d)" opacity=".55"/>
      <circle cx="87" cy="360" r="3" fill="#5BBA6F" opacity=".5"/>
      <circle cx="51" cy="660" r="2.6" fill="#B08D57" opacity=".45"/>
      <circle cx="18" cy="500" r="2.4" fill="#5BBA6F" opacity=".4"/>
    </svg>
  </div>

  <div class="contenido">

    <header class="cabecera">
      <div class="tile"><div class="rombo-grande"><span>WQZ</span></div></div>
      <div class="quien">
        <b>Carlos Serrano</b>
        <small>INTÉRPRETE · INGLÉS · ESPAÑOL</small>
      </div>
      <div class="folio">
        <b>${esc(folio)}</b>
        <small>Emitida: ${esc(fechaLarga(hoyMexicoIso()))}</small>
      </div>
    </header>
    <div class="filete-oro"></div>

    <h1>Cotización <em>de servicios</em></h1>
    ${evento ? `<p class="evento">${esc(evento)}</p>` : ""}

    <div class="etiqueta">Preparado para</div>
    <section class="panel cliente">
      <div class="bloque principal">
        <div class="empresa">${esc(fila.cliente)}</div>
        ${fila.contacto ? `<div class="persona">${esc(fila.contacto)}</div>` : ""}
      </div>
      ${contacto.length ? `<div class="separador"></div>
      <div class="bloque">
        <div class="rotulo">Contacto</div>
        ${contacto.map((c) => `<div class="dato">${c}</div>`).join("\n        ")}
      </div>` : ""}
    </section>

    <div class="etiqueta">Detalle del servicio</div>
    <section class="panel">
      <div class="campos">
${campos.join("\n")}
      </div>
    </section>

    <div class="etiqueta">Inversión</div>
${inversion}

    <footer class="pie">
      <b>Carlos Serrano · Intérprete · Traductor</b>
      <p>+52 55 4652 9029 · lcsb.tra.int@gmail.com</p>
      <p class="idiomas">Inglés · Español</p>
    </footer>

  </div>
</div>
</body>
</html>`;
}
