// Tipos, configuración de estatus y utilidades del Centro de Mando.
// Seguro para cliente (sin imports de servidor).

// El ciclo de vida de un evento:
//   PROSPECTO  → cotización enviada, fecha "con lápiz"
//   CONFIRMADO → fecha asegurada, esperando el día de trabajo
//   REALIZADO  → ya trabajado, esperando cerrar el pago
//   PAGADO     → liquidado por completo
//   CANCELADO  → no procedió (con motivo opcional)
export type Estatus =
  | "PROSPECTO"
  | "CONFIRMADO"
  | "REALIZADO"
  | "PAGADO"
  | "CANCELADO";

export const ESTATUS_VALIDOS: Estatus[] = [
  "PROSPECTO",
  "CONFIRMADO",
  "REALIZADO",
  "PAGADO",
  "CANCELADO",
];

/**
 * Estatus legado: los eventos guardados como "FACTURADO" antes de v0.5
 * se exhiben (y viajan al comedor) como REALIZADO, que es su nuevo
 * equivalente: ya trabajado, en espera de cerrar el pago.
 */
export function normalizarEstatus(s: string): Estatus {
  if (s === "FACTURADO") return "REALIZADO";
  return (ESTATUS_VALIDOS as string[]).includes(s) ? (s as Estatus) : "PROSPECTO";
}

export type Modalidad = "PRESENCIAL_CDMX" | "REMOTO" | "FORANEO";

export const MODALIDADES_VALIDAS: Modalidad[] = [
  "PRESENCIAL_CDMX",
  "REMOTO",
  "FORANEO",
];

// ── Idiomas del par ──────────────────────────────────────────────────────────
// Los pares con los que se trabaja; PO - ES está listo para cuando el
// portugués se sume al menú de servicios.
export const IDIOMAS_VALIDOS = ["EN - ES", "PO - ES"] as const;
export type IdiomaPar = (typeof IDIOMAS_VALIDOS)[number];

// ── Impuestos opcionales ─────────────────────────────────────────────────────
// Cálculo informativo: la tarifa es la base (sin IVA) y el IVA se traslada.
// MORAL: además, el cliente retiene 2/3 del IVA (10.6667% de la base)
// y 10% de ISR. FAE: solo el traslado del IVA, sin retenciones.
export type ImpuestosTipo = "MORAL" | "FAE";

export const IMPUESTOS_VALIDOS: ImpuestosTipo[] = ["MORAL", "FAE"];

export const IMPUESTOS_CONFIG: Record<
  ImpuestosTipo,
  { label: string; corto: string; detalle: string }
> = {
  MORAL: {
    label: "Persona moral",
    corto: "Moral",
    detalle: "IVA 16% + ret. IVA 10.6667% + ret. ISR 10%",
  },
  FAE: {
    label: "Física c/ act. empresarial",
    corto: "FAE",
    detalle: "IVA 16%, sin retenciones",
  },
};

export type DesgloseImpuestos = {
  iva: number;
  retIva: number;
  retIsr: number;
  factura: number;
  neto: number;
};

/** Calcula el desglose fiscal a partir de la tarifa (base, sin IVA). */
export function calcularImpuestos(
  tarifa: number,
  tipo: ImpuestosTipo
): DesgloseImpuestos {
  const iva = tarifa * 0.16;
  const factura = tarifa + iva;
  if (tipo === "FAE") {
    return { iva, retIva: 0, retIsr: 0, factura, neto: factura };
  }
  const retIva = tarifa * (10.6667 / 100);
  const retIsr = tarifa * 0.1;
  return { iva, retIva, retIsr, factura, neto: factura - retIva - retIsr };
}

/** Título explicativo del desglose, para tooltips. */
export function tituloImpuestos(tipo: ImpuestosTipo): string {
  return tipo === "MORAL"
    ? "Tarifa + IVA 16% trasladado, menos retenciones (IVA 10.6667% e ISR 10%)"
    : "Tarifa + IVA 16% trasladado, sin retenciones";
}

export type EventoDTO = {
  id: string;
  idEvento: string | null;
  folio: string | null;
  cliente: string;
  contacto: string | null;
  telefono: string | null;
  correo: string | null;
  idiomas: string | null;
  nombreEvento: string | null;
  origen: Origen | null;
  estatus: Estatus;
  razonCancelacion: string | null;
  fechasTexto: string | null;
  fechas: string[]; // fechas ISO elegidas (dispersas ok)
  fechaInicio: string | null; // ISO
  fechaFin: string | null;
  dias: number | null;
  horaInicio: string | null;
  horaFin: string | null;
  horario: string | null;
  tipoBloque: string | null;
  diaCompleto: boolean;
  tema: string | null;
  modalidad: Modalidad;
  ciudad: string | null;
  tarifa: number;
  tarifaPorDia: number | null;
  impuestosTipo: ImpuestosTipo | null;
  ivaEnCotizacion: boolean;
  viaticos: number | null;
  interpretesExtra: InterpreteExtra[];
  pagoInterpretes: boolean;
  pagoEquipo: boolean;
  linkGlosario: string | null;
  notas: string | null;
  equipo: LineaEquipo[];
  updatedAt: string; // marca de la última edición (cache-bust del PDF)
};

// ── Origen del evento (ronda 20): directo / agencia / colega ─────────────
export const ORIGENES_VALIDOS = ["DIRECTO", "AGENCIA", "COLEGA"] as const;
export type Origen = (typeof ORIGENES_VALIDOS)[number];

export const ORIGEN_CONFIG: Record<Origen, { label: string; corto: string }> = {
  DIRECTO: { label: "Directo", corto: "Directo" },
  AGENCIA: { label: "Agencia", corto: "Agencia" },
  COLEGA: { label: "Colega", corto: "Colega" },
};

// ── Intérpretes extra (ronda 20) ─────────────────────────────────────────────
// El evento de a veces necesita más intérpretes en cabina: cada uno cobra su
// propia tarifa (casi siempre la misma que el dueño) y, si el evento es
// foráneo, sus viáticos. Ni los viáticos propios ni los ajenos cuentan como
// ingreso: son passthrough que el cliente cubre en la cotización.
export type InterpreteExtra = {
  nombre: string;
  tarifa: number | null; // MXN · null = aún por definir
  viaticos: number | null; // MXN · sólo foráneo
};

export const MAX_INTERPRETES_EXTRA = 5;

export function parsearInterpretesExtra(crudo: unknown): InterpreteExtra[] {
  if (!Array.isArray(crudo)) return [];
  const out: InterpreteExtra[] = [];
  for (const l of crudo) {
    if (!l || typeof l !== "object") continue;
    const o = l as Record<string, unknown>;
    const nombre = typeof o.nombre === "string" ? o.nombre.trim() : "";
    if (!nombre) continue;
    const num = (v: unknown) =>
      v !== null && v !== "" && Number.isFinite(Number(v)) && Number(v) > 0
        ? Number(v)
        : null;
    out.push({
      nombre: nombre.slice(0, 60),
      tarifa: num(o.tarifa),
      viaticos: num(o.viaticos),
    });
    if (out.length >= MAX_INTERPRETES_EXTRA) break;
  }
  return out;
}

export function parseInterpretesExtra(
  json: string | null | undefined
): InterpreteExtra[] {
  if (!json) return [];
  try {
    return parsearInterpretesExtra(JSON.parse(json));
  } catch {
    return [];
  }
}

export function serializarInterpretesExtra(
  lineas: InterpreteExtra[]
): string | null {
  const utiles = lineas.filter((l) => l.nombre.trim() !== "");
  return utiles.length > 0 ? JSON.stringify(utiles) : null;
}

/** Dinero que se debe a los intérpretes extra ("Por pagar" de intérpretes). */
export function porPagarInterpretes(e: {
  interpretesExtra: InterpreteExtra[];
  pagoInterpretes: boolean;
}): number {
  if (e.pagoInterpretes) return 0;
  return e.interpretesExtra.reduce((s, i) => s + (i.tarifa ?? 0), 0);
}

// ── Fechas dispersas (ronda 20) ─────────────────────────────────────────────
// El calendario del CDM ahora elige días uno por uno (o por arrastre): la
// columna fechas guarda la lista real. Estas utilidades la leen, la sanean y
// la resumen en texto corto para tarjetas, CSV y cotización.

const RE_ISO = /^\d{4}-\d{2}-\d{2}$/;

export function parsearFechas(crudo: unknown): string[] {
  if (!Array.isArray(crudo)) return [];
  const validas = crudo.filter(
    (s) => typeof s === "string" && RE_ISO.test(s)
  ) as string[];
  return [...new Set(validas)].sort().slice(0, 400);
}

export function parseFechas(json: string | null | undefined): string[] {
  if (!json) return [];
  try {
    return parsearFechas(JSON.parse(json));
  } catch {
    return [];
  }
}

export function serializarFechas(fechas: string[]): string | null {
  return fechas.length > 0 ? JSON.stringify(fechas) : null;
}

const MES_CORTO = [
  "ene", "feb", "mar", "abr", "may", "jun",
  "jul", "ago", "sep", "oct", "nov", "dic",
];

/** Resumen corto de una lista de fechas ISO: contiguas se pliegan en rangos.
 *  ["2026-11-18", "2026-11-19", "2026-11-21"] → "18–19 y 21 nov". */
export function resumenFechas(fechas: string[]): string {
  if (fechas.length === 0) return "";
  const grupos: [string, string][] = []; // [inicio, fin] contiguos
  for (const k of fechas) {
    const ultimo = grupos[grupos.length - 1];
    if (ultimo) {
      const unDia =
        new Date(ultimo[1] + "T12:00:00Z").getTime() + 86400000;
      if (new Date(k + "T12:00:00Z").getTime() === unDia) {
        ultimo[1] = k;
        continue;
      }
    }
    grupos.push([k, k]);
  }
  const texto = ([ini, fin]: [string, string]) => {
    const a = new Date(ini + "T12:00:00Z");
    const b = new Date(fin + "T12:00:00Z");
    const m = MES_CORTO[a.getUTCMonth()];
    if (ini === fin) return `${a.getUTCDate()} ${m}`;
    return `${a.getUTCDate()}–${b.getUTCDate()} ${m}`;
  };
  return grupos.map(texto).join(" · ");
}
// ── Equipo de interpretación (ronda 17, recalibrado en la 20) ─────────────
// Cada línea es algo que el servicio necesita: una cabina, 100 receptores,
// transmisores… El nombre es texto libre (lo escribe el intérprete); el
// precio es OPCIONAL por línea (null = ya va incluido en la tarifa). Desde
// la ronda 20 todas las líneas viajan a la cotización del cliente — el
// interruptor PDF por línea se retiró (la idea queda documentada por si
// algún día regresa).
export type LineaEquipo = {
  nombre: string;
  cantidad: number; // ≥ 1
  precio: number | null; // unitario MXN · null = incluido en la tarifa
  enCotizacion: boolean;
};

export const MAX_LINEAS_EQUIPO = 12;

/** Lee cualquier fuente (array del formulario, JSON de la base) y devuelve
 *  sólo líneas válidas: sin nombre no hay línea; cantidad y precio se
 *  sanean solos para que la base nunca guarde basura. */
export function parsearLineasEquipo(crudo: unknown): LineaEquipo[] {
  if (!Array.isArray(crudo)) return [];
  const lineas: LineaEquipo[] = [];
  for (const l of crudo) {
    if (!l || typeof l !== "object") continue;
    const o = l as Record<string, unknown>;
    const nombre = typeof o.nombre === "string" ? o.nombre.trim() : "";
    if (!nombre) continue;
    const cant = Number(o.cantidad);
    const precioNum = Number(o.precio);
    const precio =
      o.precio !== null && o.precio !== "" && Number.isFinite(precioNum) && precioNum > 0
        ? precioNum
        : null;
    lineas.push({
      nombre: nombre.slice(0, 80),
      cantidad:
        Number.isFinite(cant) && cant >= 1 ? Math.min(Math.floor(cant), 99999) : 1,
      precio,
      enCotizacion: o.enCotizacion !== false,
    });
    if (lineas.length >= MAX_LINEAS_EQUIPO) break;
  }
  return lineas;
}

/** Columna equipo de la base → líneas listas para pintar. */
export function parseEquipo(json: string | null | undefined): LineaEquipo[] {
  if (!json) return [];
  try {
    return parsearLineasEquipo(JSON.parse(json));
  } catch {
    return []; // JSON viejo o roto: el evento se muestra sin equipo
  }
}

/** Líneas → columna de la base (null cuando no hay nada que guardar). */
export function serializarEquipo(lineas: LineaEquipo[]): string | null {
  const utiles = lineas.filter((l) => l.nombre.trim() !== "");
  return utiles.length > 0 ? JSON.stringify(utiles) : null;
}

/** Texto corto para tarjetas y CSV: "Media cabina · Receptores ×100". */
export function resumenEquipo(
  lineas: LineaEquipo[],
  max = 3
): string {
  const visibles = lineas.slice(0, max);
  const partes = visibles.map(
    (l) => `${l.cantidad > 1 ? `${l.cantidad} × ` : ""}${l.nombre}`
  );
  if (lineas.length > max) partes.push(`+${lineas.length - max} más`);
  return partes.join(" · ");
}

// Los colores de estatus siguen al tema activo (variables CSS).
// REALIZADO usa su propia pintura (azul); PAGADO viste el oro de la casa.
export const ESTATUS_CONFIG: Record<
  Estatus,
  {
    label: string;
    chip: string; // clases del badge
    punto: string; // color del dot
    texto: string;
  }
> = {
  PROSPECTO: {
    label: "Prospecto",
    chip: "border-estado-prospecto/25 bg-estado-prospecto/10 text-estado-prospecto",
    punto: "bg-estado-prospecto",
    texto: "text-estado-prospecto",
  },
  CONFIRMADO: {
    label: "Confirmado",
    chip: "border-estado-confirmado/25 bg-estado-confirmado/10 text-estado-confirmado",
    punto: "bg-estado-confirmado",
    texto: "text-estado-confirmado",
  },
  REALIZADO: {
    label: "Realizado",
    chip: "border-estado-realizado/30 bg-estado-realizado/10 text-estado-realizado",
    punto: "bg-estado-realizado",
    texto: "text-estado-realizado",
  },
  PAGADO: {
    label: "Pagado",
    chip: "border-estado-facturado/30 bg-estado-facturado/10 text-estado-facturado",
    punto: "bg-estado-facturado",
    texto: "text-estado-facturado",
  },
  CANCELADO: {
    label: "Cancelado",
    chip: "border-estado-cancelado/25 bg-estado-cancelado/10 text-estado-cancelado",
    punto: "bg-estado-cancelado",
    texto: "text-estado-cancelado",
  },
};

export const MODALIDAD_CONFIG: Record<
  Modalidad,
  { label: string; conCiudad?: boolean }
> = {
  PRESENCIAL_CDMX: { label: "Presencial" },
  REMOTO: { label: "Remoto" },
  FORANEO: { label: "Foráneo", conCiudad: true },
};

export const formatoTarifa = (n: number) =>
  new Intl.NumberFormat("es-MX", { maximumFractionDigits: 0 }).format(n);

/** Dinero con hasta dos decimales (para impuestos y netos). */
export const formatoDinero = (n: number) =>
  new Intl.NumberFormat("es-MX", { maximumFractionDigits: 2 }).format(n);

export const capitalizar = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

/**
 * Convierte el número tal cual del Sheet en un teléfono válido para wa.me.
 * "5636020401" (10 dígitos, México) → "525636020401".
 * Devuelve null si no hay número utilizable.
 */
export const normalizarWhatsApp = (tel?: string | null): string | null => {
  if (!tel) return null;
  const digitos = tel.replace(/\D/g, "");
  if (digitos.length === 10) return `52${digitos}`; // celular mexicano sin clave lada internacional
  if (digitos.length === 12 && digitos.startsWith("52")) return digitos;
  if (digitos.length === 11 && digitos.startsWith("52")) return digitos;
  if (digitos.length >= 12) return digitos; // ya viene con clave de otro país
  return null;
};

/** Forma de una fila tal como sale de la base de datos (Prisma). */
export type EventoFila = {
  id: string;
  idEvento: string | null;
  folio: string | null;
  cliente: string;
  contacto: string | null;
  telefono: string | null;
  correo: string | null;
  idiomas: string | null;
  estatus: string;
  razonCancelacion: string | null;
  fechasTexto: string | null;
  fechaInicio: Date | null;
  fechaFin: Date | null;
  dias: number | null;
  horaInicio: string | null;
  horaFin: string | null;
  horario: string | null;
  tipoBloque: string | null;
  tema: string | null;
  modalidad: string;
  ciudad: string | null;
  tarifa: number;
  tarifaPorDia: number | null;
  impuestosTipo: string | null;
  linkGlosario: string | null;
  notas: string | null;
  equipo: string | null;
  nombreEvento: string | null;
  origen: string | null;
  diaCompleto: boolean | null;
  fechas: string | null;
  ivaEnCotizacion: boolean | null;
  viaticos: number | null;
  interpretesExtra: string | null;
  pagoInterpretes: boolean | null;
  pagoEquipo: boolean | null;
  updatedAt: Date;
};

/** Traduce una fila de la base al formato que viaja al comedor (DTO). */
export function aEventoDTO(e: EventoFila): EventoDTO {
  const impuestosTipo =
    e.impuestosTipo && (IMPUESTOS_VALIDOS as string[]).includes(e.impuestosTipo)
      ? (e.impuestosTipo as ImpuestosTipo)
      : null;
  const origen =
    e.origen && (ORIGENES_VALIDOS as readonly string[]).includes(e.origen)
      ? (e.origen as Origen)
      : null;
  return {
    id: e.id,
    idEvento: e.idEvento,
    folio: e.folio,
    cliente: e.cliente,
    contacto: e.contacto,
    telefono: e.telefono,
    correo: e.correo,
    idiomas: e.idiomas,
    nombreEvento: e.nombreEvento,
    origen,
    estatus: normalizarEstatus(e.estatus),
    razonCancelacion: e.razonCancelacion,
    fechasTexto: e.fechasTexto,
    fechas: parseFechas(e.fechas),
    fechaInicio: e.fechaInicio ? new Date(e.fechaInicio).toISOString() : null,
    fechaFin: e.fechaFin ? new Date(e.fechaFin).toISOString() : null,
    dias: e.dias,
    horaInicio: e.horaInicio,
    horaFin: e.horaFin,
    horario: e.horario,
    tipoBloque: e.tipoBloque,
    diaCompleto: e.diaCompleto === true,
    tema: e.tema,
    modalidad: e.modalidad as Modalidad,
    ciudad: e.ciudad,
    tarifa: e.tarifa,
    tarifaPorDia: e.tarifaPorDia,
    impuestosTipo,
    ivaEnCotizacion: e.ivaEnCotizacion !== false,
    viaticos: e.viaticos ?? null,
    interpretesExtra: parseInterpretesExtra(e.interpretesExtra),
    pagoInterpretes: e.pagoInterpretes === true,
    pagoEquipo: e.pagoEquipo === true,
    linkGlosario: e.linkGlosario,
    notas: e.notas,
    equipo: parseEquipo(e.equipo),
    updatedAt: new Date(e.updatedAt).toISOString(),
  };
}
