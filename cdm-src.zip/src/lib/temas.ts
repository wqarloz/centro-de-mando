// Sistema de temas del Centro de Mando.
// Cada tema es un "atuendo": dos paletas (oscura y clara) que se convierten
// en variables CSS. La app entera lee esas variables, así que cambiar de tema
// es solo cambiar la pintura — nada de cómo funciona se toca.
// Seguro para cliente (sin imports de servidor).

import type { CSSProperties } from "react";

export type Modo = "oscuro" | "claro";

export type FuenteDisplay = "serif" | "sans" | "redonda";

export type Paleta = {
  fondo: string;
  tarjeta: string;
  tarjetaBaja: string;
  panel: string;
  linea: string;
  lineaSuave: string;
  lineaFuerte: string;
  lineaHover: string;
  tinta: string;
  tintaSuave: string;
  tintaMuda: string;
  acento: string;
  acentoClaro: string;
  acentoTinta: string;
  exito: string;
  exitoTinta: string;
  peligro: string;
  peligroTinta: string;
  estadoProspecto: string;
  estadoConfirmado: string;
  estadoFacturado: string;
  estadoCancelado: string;
  brillo: string; // resplandor decorativo (rgba)
  radio: string; // radios de controles (botones, inputs)
  radioTarjeta: string; // radio de tarjetas y paneles
  grosor: string; // grosor del borde de tarjetas
  sombra: string; // sombra de tarjetas
  fuente: FuenteDisplay;
  esquema: "dark" | "light";
};

export type Tema = {
  id: string;
  nombre: string;
  inspiracion: string;
  descripcion: string;
  nota?: string;
  oscuro: Paleta;
  claro: Paleta;
};

export const TEMA_DEFECTO = "obsidiana";

const FUENTES_DISPLAY: Record<FuenteDisplay, string> = {
  serif:
    "var(--font-playfair), Georgia, 'Times New Roman', serif",
  sans: "var(--font-archivo), 'Segoe UI', system-ui, sans-serif",
  redonda: "var(--font-nunito), 'Segoe UI', system-ui, sans-serif",
};

export const ETIQUETA_FUENTE: Record<FuenteDisplay, string> = {
  serif: "serif elegante",
  sans: "sans contundente",
  redonda: "redondeada amable",
};

/** Claves de localStorage para recordar el atuendo elegido. */
export const CLAVES_TEMA = {
  tema: "cm-tema",
  modo: "cm-modo",
  vars: "cm-vars",
} as const;

/** Convierte una paleta en el mapa de variables CSS que la app lee. */
export function aCSSVars(p: Paleta): Record<string, string> {
  const vars: Record<string, string> = {
    "--fondo": p.fondo,
    "--tarjeta": p.tarjeta,
    "--tarjeta-baja": p.tarjetaBaja,
    "--panel": p.panel,
    "--linea": p.linea,
    "--linea-suave": p.lineaSuave,
    "--linea-fuerte": p.lineaFuerte,
    "--linea-hover": p.lineaHover,
    "--tinta": p.tinta,
    "--tinta-suave": p.tintaSuave,
    "--tinta-muda": p.tintaMuda,
    "--acento": p.acento,
    "--acento-claro": p.acentoClaro,
    "--acento-tinta": p.acentoTinta,
    "--exito": p.exito,
    "--exito-tinta": p.exitoTinta,
    "--peligro": p.peligro,
    "--peligro-tinta": p.peligroTinta,
    "--estado-prospecto": p.estadoProspecto,
    "--estado-confirmado": p.estadoConfirmado,
    "--estado-facturado": p.estadoFacturado,
    "--estado-cancelado": p.estadoCancelado,
    "--brillo": p.brillo,
    "--radius": p.radio,
    "--radio-tarjeta": p.radioTarjeta,
    "--grosor-linea": p.grosor,
    "--sombra-tarjeta": p.sombra,
    "--fuente-display": FUENTES_DISPLAY[p.fuente],
    "--esquema-color": p.esquema,
    // Aliases para los componentes de diálogo/select/toast (shadcn),
    // que hablan el idioma de --background, --card, etc.
    "--background": p.fondo,
    "--foreground": p.tintaSuave,
    "--card": p.tarjeta,
    "--card-foreground": p.tinta,
    "--popover": p.tarjeta,
    "--popover-foreground": p.tinta,
    "--primary": p.acento,
    "--primary-foreground": p.acentoTinta,
    "--secondary": p.panel,
    "--secondary-foreground": p.tinta,
    "--muted": p.panel,
    "--muted-foreground": p.tintaMuda,
    "--accent": p.panel,
    "--accent-foreground": p.tinta,
    "--destructive": p.peligro,
    "--border": p.lineaFuerte,
    "--input": p.lineaFuerte,
    "--ring": p.acento,
  };
  return vars;
}

/** Estilo en línea para superficies de tarjeta: borde y sombra del tema. */
export const SUPERFICIE_TARJETA: CSSProperties = {
  borderWidth: "var(--grosor-linea)",
  boxShadow: "var(--sombra-tarjeta)",
};

export const TEMAS: Tema[] = [
  {
    id: "obsidiana",
    nombre: "Obsidiana y Oro",
    inspiracion: "El actual",
    descripcion:
      "La elegancia que ya conoces: negro profundo, oro viejo y serif de galería.",
    oscuro: {
      fondo: "#0A0A0C",
      tarjeta: "#16161A",
      tarjetaBaja: "#121215",
      panel: "#0E0E11",
      linea: "#232329",
      lineaSuave: "#1E1E23",
      lineaFuerte: "#26262B",
      lineaHover: "#3A3A41",
      tinta: "#F5F5F4",
      tintaSuave: "#D2D2D9",
      tintaMuda: "#6B6B73",
      acento: "#C9A96A",
      acentoClaro: "#E3C892",
      acentoTinta: "#191307",
      exito: "#34D399",
      exitoTinta: "#022C22",
      peligro: "#F87171",
      peligroTinta: "#450A0A",
      estadoProspecto: "#FBBF24",
      estadoConfirmado: "#34D399",
      estadoFacturado: "#D4B47E",
      estadoCancelado: "#71717A",
      brillo: "rgba(201, 169, 106, 0.08)",
      radio: "0.875rem",
      radioTarjeta: "1rem",
      grosor: "1px",
      sombra: "none",
      fuente: "serif",
      esquema: "dark",
    },
    claro: {
      fondo: "#F4F1EA",
      tarjeta: "#FFFFFF",
      tarjetaBaja: "#FAF8F2",
      panel: "#EEEAE0",
      linea: "#E2DAC8",
      lineaSuave: "#E9E3D4",
      lineaFuerte: "#D6CDB8",
      lineaHover: "#BCB093",
      tinta: "#26211A",
      tintaSuave: "#5F5847",
      tintaMuda: "#948C77",
      acento: "#9A7B35",
      acentoClaro: "#7C6120",
      acentoTinta: "#FFFDF5",
      exito: "#0E9F6E",
      exitoTinta: "#ECFDF5",
      peligro: "#DC2626",
      peligroTinta: "#FEF2F2",
      estadoProspecto: "#B45309",
      estadoConfirmado: "#047857",
      estadoFacturado: "#9A7B35",
      estadoCancelado: "#8A8578",
      brillo: "rgba(154, 123, 53, 0.10)",
      radio: "0.875rem",
      radioTarjeta: "1rem",
      grosor: "1px",
      sombra: "0 1px 2px rgba(38, 33, 26, 0.06)",
      fuente: "serif",
      esquema: "light",
    },
  },
  {
    id: "runner",
    nombre: "Runner",
    inspiracion: "Mirror's Edge · Xbox 360",
    descripcion:
      "La ciudad en blanco: aire, silencio, tipografía limpia y un rojo que corta la vista.",
    nota: "Su cara natural es el modo claro — pruébalo arriba.",
    oscuro: {
      fondo: "#0B0B0C",
      tarjeta: "#151517",
      tarjetaBaja: "#111113",
      panel: "#0E0E10",
      linea: "#26262A",
      lineaSuave: "#1E1E21",
      lineaFuerte: "#33333A",
      lineaHover: "#4A4A52",
      tinta: "#FAFAFA",
      tintaSuave: "#C9C9CE",
      tintaMuda: "#6E6E76",
      acento: "#FF3C00",
      acentoClaro: "#FF6A3D",
      acentoTinta: "#FFFFFF",
      exito: "#21C589",
      exitoTinta: "#00251A",
      peligro: "#FF6B6B",
      peligroTinta: "#2A0A05",
      estadoProspecto: "#FFB020",
      estadoConfirmado: "#2BD98A",
      estadoFacturado: "#D9A53A",
      estadoCancelado: "#73737A",
      brillo: "rgba(255, 60, 0, 0.07)",
      radio: "0.375rem",
      radioTarjeta: "0.5rem",
      grosor: "1px",
      sombra: "none",
      fuente: "sans",
      esquema: "dark",
    },
    claro: {
      fondo: "#FFFFFF",
      tarjeta: "#FFFFFF",
      tarjetaBaja: "#FAFAFA",
      panel: "#F4F4F5",
      linea: "#E4E4E7",
      lineaSuave: "#EFEFF1",
      lineaFuerte: "#D6D6DB",
      lineaHover: "#B9B9C1",
      tinta: "#0D0D0F",
      tintaSuave: "#44444C",
      tintaMuda: "#8E8E96",
      acento: "#FF3C00",
      acentoClaro: "#C92A00",
      acentoTinta: "#FFFFFF",
      exito: "#00A86B",
      exitoTinta: "#FFFFFF",
      peligro: "#C62828",
      peligroTinta: "#FFECEC",
      estadoProspecto: "#C77400",
      estadoConfirmado: "#0B7A4B",
      estadoFacturado: "#B07818",
      estadoCancelado: "#8E8E96",
      brillo: "rgba(255, 60, 0, 0.06)",
      radio: "0.375rem",
      radioTarjeta: "0.5rem",
      grosor: "1px",
      sombra: "0 1px 3px rgba(13, 13, 15, 0.06)",
      fuente: "sans",
      esquema: "light",
    },
  },{
    id: "zia",
    nombre: "Sol de Zia",
    inspiracion: "La bandera de Nuevo México + tu paleta cálida",
    descripcion:
      "Campo dorado con el rojo ceremonial del sol Zia: cálido, directo, inconfundible.",
    nota: "Su cara natural es el modo claro — pruébalo arriba.",
    oscuro: {
      fondo: "#221306",
      tarjeta: "#30210E",
      tarjetaBaja: "#2A1D0C",
      panel: "#1E1408",
      linea: "#4A3618",
      lineaSuave: "#3A2A12",
      lineaFuerte: "#5A4220",
      lineaHover: "#77592B",
      tinta: "#F9EDD0",
      tintaSuave: "#D6C39A",
      tintaMuda: "#8F7D57",
      acento: "#F7B538",
      acentoClaro: "#FFD46A",
      acentoTinta: "#2A1B03",
      exito: "#57A267",
      exitoTinta: "#0E2412",
      peligro: "#E0524F",
      peligroTinta: "#2A0A08",
      estadoProspecto: "#DB7C26",
      estadoConfirmado: "#57A267",
      estadoFacturado: "#FFD97A",
      estadoCancelado: "#7A6A4A",
      brillo: "rgba(247, 181, 56, 0.09)",
      radio: "0.5rem",
      radioTarjeta: "0.75rem",
      grosor: "1px",
      sombra: "0 2px 8px rgba(0, 0, 0, 0.30)",
      fuente: "serif",
      esquema: "dark",
    },
    claro: {
      fondo: "#F4CE55",
      tarjeta: "#FCF6D8",
      tarjetaBaja: "#F9EFC2",
      panel: "#E8C244",
      linea: "#D9A82B",
      lineaSuave: "#E3B838",
      lineaFuerte: "#C99A1F",
      lineaHover: "#A87E12",
      tinta: "#33230A",
      tintaSuave: "#5E4A1E",
      tintaMuda: "#93803F",
      acento: "#C41E3A",
      acentoClaro: "#9E142C",
      acentoTinta: "#FDF3D8",
      exito: "#1E6B3C",
      exitoTinta: "#EAF6EC",
      peligro: "#A51226",
      peligroTinta: "#FDF3D8",
      estadoProspecto: "#8A5A0A",
      estadoConfirmado: "#1E6B3C",
      estadoFacturado: "#6E4E0A",
      estadoCancelado: "#93803F",
      brillo: "rgba(196, 30, 58, 0.06)",
      radio: "0.5rem",
      radioTarjeta: "0.75rem",
      grosor: "1px",
      sombra: "0 2px 6px rgba(122, 84, 18, 0.18)",
      fuente: "serif",
      esquema: "light",
    },
  },
  {
    id: "aero",
    nombre: "Aero",
    inspiracion: "Frutiger Aero",
    descripcion:
      "Cristal, cielo y optimismo tecnológico: brillo húmedo, burbujas y verde exuberante.",
    nota: "Brilla más en modo claro.",
    oscuro: {
      fondo: "#06222B",
      tarjeta: "#0C3440",
      tarjetaBaja: "#092C37",
      panel: "#072630",
      linea: "#17505E",
      lineaSuave: "#11414D",
      lineaFuerte: "#1F6272",
      lineaHover: "#2C8296",
      tinta: "#E3F4F7",
      tintaSuave: "#AFD3DC",
      tintaMuda: "#628994",
      acento: "#3ECFB2",
      acentoClaro: "#7FE8D2",
      acentoTinta: "#052A24",
      exito: "#52B788",
      exitoTinta: "#07281A",
      peligro: "#F26D6D",
      peligroTinta: "#2A0808",
      estadoProspecto: "#F5A524",
      estadoConfirmado: "#52B788",
      estadoFacturado: "#D9BC4A",
      estadoCancelado: "#5E8290",
      brillo: "rgba(62, 207, 178, 0.10)",
      radio: "1rem",
      radioTarjeta: "1.25rem",
      grosor: "1px",
      sombra: "0 6px 20px rgba(0, 0, 0, 0.35)",
      fuente: "redonda",
      esquema: "dark",
    },
    claro: {
      fondo: "#A5DCEF",
      tarjeta: "#F0FAFE",
      tarjetaBaja: "#E4F5FB",
      panel: "#C4E8F4",
      linea: "#8CCBE2",
      lineaSuave: "#A6D9EA",
      lineaFuerte: "#6FB8D6",
      lineaHover: "#4E9CC0",
      tinta: "#0A3A47",
      tintaSuave: "#2D5F6E",
      tintaMuda: "#63929F",
      acento: "#0F9B8E",
      acentoClaro: "#0B7268",
      acentoTinta: "#EAFDF9",
      exito: "#2FA36B",
      exitoTinta: "#EAF8EF",
      peligro: "#E05555",
      peligroTinta: "#FEEFEF",
      estadoProspecto: "#E8901C",
      estadoConfirmado: "#2FA36B",
      estadoFacturado: "#B08D1F",
      estadoCancelado: "#7A9AA6",
      brillo: "rgba(255, 255, 255, 0.45)",
      radio: "1rem",
      radioTarjeta: "1.25rem",
      grosor: "1px",
      sombra: "0 2px 12px rgba(10, 58, 71, 0.10)",
      fuente: "redonda",
      esquema: "light",
    },
  },
];

export function getTema(id: string): Tema {
  return TEMAS.find((t) => t.id === id) ?? TEMAS[0];
}

/** Aplica un tema + modo al documento entero y lo recuerda. */
export function aplicarTema(id: string, modo: Modo): void {
  const tema = getTema(id);
  const vars = aCSSVars(tema[modo]);
  const raiz = document.documentElement;
  for (const [k, v] of Object.entries(vars)) raiz.style.setProperty(k, v);
  raiz.classList.toggle("dark", modo === "oscuro");
  try {
    localStorage.setItem(CLAVES_TEMA.tema, tema.id);
    localStorage.setItem(CLAVES_TEMA.modo, modo);
    localStorage.setItem(CLAVES_TEMA.vars, JSON.stringify(vars));
  } catch {
    // Sin almacenamiento disponible: el tema se aplica igual, solo no se recuerda.
  }
}
