import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { parseEquipo } from "@/lib/estatus";

// Exporta todo el registro como CSV con las mismas columnas del
// Google Sheet original — puede volver a importarse sin fricción.
export const dynamic = "force-dynamic";

const MESES = [
  "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
  "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre",
];

const ESTATUS_ETIQUETA: Record<string, string> = {
  PROSPECTO: "Prospecto",
  CONFIRMADO: "Confirmado",
  REALIZADO: "Realizado",
  PAGADO: "Pagado",
  CANCELADO: "Cancelado",
  // Legado anterior a v0.5: ya trabajado, en espera de cerrar el pago.
  FACTURADO: "Realizado",
};

const escapar = (v: string | number | null | undefined) => {
  const s = v == null ? "" : String(v);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

/** Reconstruye "15 - 19 Noviembre" a partir de las fechas ordenables. */
function fechasComoSheet(
  inicio: Date | null,
  fin: Date | null,
  texto: string | null
): string {
  if (texto) return texto;
  if (!inicio) return "";
  const f = fin && fin.toDateString() !== inicio.toDateString() ? fin : null;
  const anio =
    inicio.getFullYear() !== new Date().getFullYear()
      ? ` ${inicio.getFullYear()}`
      : "";
  if (!f) return `${inicio.getDate()} ${MESES[inicio.getMonth()]}${anio}`;
  if (f.getMonth() === inicio.getMonth()) {
    return `${inicio.getDate()} - ${f.getDate()} ${MESES[f.getMonth()]}${anio}`;
  }
  return `${inicio.getDate()} ${MESES[inicio.getMonth()]} - ${f.getDate()} ${MESES[f.getMonth()]}${anio}`;
}

/** Texto plano de las líneas de equipo: "Receptores x100 (25 c/u) · Media cabina x1". */
function equipoComoTexto(json: string | null): string {
  const lineas = parseEquipo(json);
  if (lineas.length === 0) return "";
  return lineas
    .map((l) =>
      `${l.nombre} x${l.cantidad}${l.precio ? ` (${l.precio} c/u)` : ""}${
        l.enCotizacion ? "" : " [interno]"
      }`
    )
    .join(" · ");
}

export async function GET() {
  const filas = await db.evento.findMany({
    orderBy: { createdAt: "desc" },
  });

  const ENCABEZADOS = [
    "ID Evento",
    "Estatus",
    "Cliente / Empresa",
    "Nombre del Contacto",
    "Número del Cliente",
    "Correo del Contacto",
    "Fechas Seleccionadas",
    "Total de Días",
    "Hora de Inicio",
    "Hora de Fin",
    "Tipo de Bloque",
    "Tema / Industria",
    "Modalidad",
    "Tarifa Total",
    "Fecha Límite de Pago",
    "Link a Glosario",
    "Idiomas",
    "Tarifa por Día",
    "Impuestos",
    "Motivo de Cancelación",
    "Equipo",
  ];

  const lineas = [ENCABEZADOS.join(",")];
  for (const e of filas) {
    const modalidad =
      e.modalidad === "REMOTO"
        ? "Remoto"
        : e.modalidad === "FORANEO"
          ? e.ciudad
            ? `Foráneo, ${e.ciudad}`
            : "Foráneo"
          : "Presencial CDMX";
    lineas.push(
      [
        e.idEvento,
        ESTATUS_ETIQUETA[e.estatus] ?? e.estatus,
        e.cliente,
        e.contacto,
        e.telefono,
        e.correo,
        fechasComoSheet(e.fechaInicio, e.fechaFin, e.fechasTexto),
        e.dias,
        e.horaInicio,
        e.horaFin,
        e.tipoBloque,
        e.tema,
        modalidad,
        e.tarifa,
        e.linkGlosario,
        e.idiomas,
        e.tarifaPorDia ?? "",
        e.impuestosTipo === "MORAL"
          ? "Persona moral"
          : e.impuestosTipo === "FAE"
            ? "FAE"
            : "",
        e.razonCancelacion,
        equipoComoTexto(e.equipo),
      ]
        .map(escapar)
        .join(",")
    );
  }

  // BOM para que Excel respete los acentos y la ñ.
  const csv = "\uFEFF" + lineas.join("\r\n");
  const hoy = new Date();
  const fecha = `${hoy.getFullYear()}-${String(hoy.getMonth() + 1).padStart(2, "0")}-${String(hoy.getDate()).padStart(2, "0")}`;

  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="eventos-interpretacion-${fecha}.csv"`,
    },
  });
}
