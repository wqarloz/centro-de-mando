import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  aEventoDTO,
  parsearFechas,
  serializarFechas,
  type LineaEquipo,
} from "@/lib/estatus";

/**
 * La puerta del sitio WQZ al panel interno.
 *
 * POST /api/solicitud — el formulario "Armemos tu cotización" del sitio
 * entrega aquí su carga. El evento nace como PROSPECTO con tarifa 0
 * (a cotizar) y un folio SECUENCIAL de cotización (COT-8241, COT-8242…):
 * nunca aleatorio, para que no haya huecos ni colisiones y el PDF,
 * el WhatsApp del cliente y la tarjeta hablen del mismo número.
 *
 * Ronda 20 — dos caminos según lo que traiga la carga:
 *   · SIN folio: solicitud nueva (como siempre).
 *   · CON folio: el cliente editó una solicitud ya enviada.
 *       - El evento sigue PROSPECTO → se sobrescribe y en las notas queda
 *         un log sintetizado de los cambios ("Cliente actualizó: …").
 *       - Ya avanzó (confirmado/pagado/…) → el evento NO se toca; las notas
 *         reciben el resumen de lo que el cliente pide cambiar y el sitio
 *         muestra "Solicitud de cambios enviada".
 *
 * CORS abierto: en producción el sitio puede vivir en otro dominio.
 */

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS });
}

const RE_CORREO = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const BASE_FOLIO = 8240; // continúa la historia de los folios de muestra

const texto = (v: unknown): string => (typeof v === "string" ? v.trim() : "");

/** "2026-11-20" → Date (mediodía UTC: el día de calendario no se corre). */
const aFecha = (s: string): Date | null => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const d = new Date(`${s}T12:00:00Z`);
  return Number.isNaN(d.getTime()) ? null : d;
};

/** El siguiente folio secuencial: el mayor que exista + 1 (con piso). */
async function siguienteFolio(): Promise<string> {
  const existentes = await db.evento.findMany({
    where: { folio: { startsWith: "COT-" } },
    select: { folio: true },
  });
  let max = BASE_FOLIO;
  for (const e of existentes) {
    const n = Number.parseInt((e.folio ?? "").slice(4), 10);
    if (Number.isFinite(n) && n > max) max = n;
  }
  return `COT-${max + 1}`;
}

const MESES_CORTOS = [
  "ene", "feb", "mar", "abr", "may", "jun",
  "jul", "ago", "sep", "oct", "nov", "dic",
];

/** Fecha y hora de México, compactas para el log: "13 nov, 18:05". */
function selloMexico(): string {
  const d = new Date(Date.now() - 6 * 60 * 60 * 1000);
  const hh = String(d.getUTCHours()).padStart(2, "0");
  const mm = String(d.getUTCMinutes()).padStart(2, "0");
  return `${d.getUTCDate()} ${MESES_CORTOS[d.getUTCMonth()]}, ${hh}:${mm}`;
}

/** El equipo elegido en el sitio, convertido a líneas del panel.
 *  Cabina/media cabina viajan cantidad 1 y SIN precio (el dueño lo define);
 *  los receptores viajan con la cantidad que pidió el cliente. */
function equipoDelSitio(
  equipoTxt: string,
  receptores: number
): LineaEquipo[] {
  const lineas: LineaEquipo[] = [];
  const n = Number.isFinite(receptores) && receptores >= 1
    ? Math.min(Math.floor(receptores), 99999)
    : null;
  if (/media/i.test(equipoTxt)) {
    lineas.push({ nombre: "Media cabina", cantidad: 1, precio: null, enCotizacion: true });
    if (n) lineas.push({ nombre: "Receptores", cantidad: n, precio: null, enCotizacion: true });
  } else if (/cabina/i.test(equipoTxt)) {
    lineas.push({ nombre: "Cabina", cantidad: 1, precio: null, enCotizacion: true });
    if (n) lineas.push({ nombre: "Receptores", cantidad: n, precio: null, enCotizacion: true });
  } else if (/receptor/i.test(equipoTxt)) {
    if (n) lineas.push({ nombre: "Receptores", cantidad: n, precio: null, enCotizacion: true });
  }
  return lineas;
}

/** Resumen compacto del equipo del sitio para el log: "media cabina + 40 receptores". */
function equipoTexto(equipoTxt: string, receptores: number): string {
  const lineas = equipoDelSitio(equipoTxt, receptores);
  if (lineas.length === 0) return "sin equipo";
  return lineas
    .map((l) => `${l.nombre.toLowerCase()}${l.cantidad > 1 ? ` ×${l.cantidad}` : ""}`)
    .join(" + ");
}

export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => null)) as Record<
    string,
    unknown
  > | null;
  if (!body) {
    return NextResponse.json(
      { error: "Cuerpo inválido" },
      { status: 400, headers: CORS }
    );
  }

  const cliente = texto(body.cliente);
  const eventoNombre = texto(body.evento);
  const correo = texto(body.correo);
  const celular = texto(body.celular);
  const sede = texto(body.sede);
  const tema = texto(body.tema);
  const equipoTxt = texto(body.equipo);
  const notasCliente = texto(body.notas);
  const horaInicio = texto(body.horaInicio);
  const horaFin = texto(body.horaFin);
  const modalidadRaw = texto(body.modalidad);
  const folioEdit = texto(body.folio);

  if (!cliente) {
    return NextResponse.json(
      { error: "Falta el nombre o empresa" },
      { status: 400, headers: CORS }
    );
  }
  if (!correo || !RE_CORREO.test(correo)) {
    return NextResponse.json(
      { error: "Correo inválido" },
      { status: 400, headers: CORS }
    );
  }
  if (!eventoNombre) {
    return NextResponse.json(
      { error: "Falta el nombre del evento" },
      { status: 400, headers: CORS }
    );
  }

  // Días elegidos en el calendario del sitio (ISO, uno por uno).
  const dias = parsearFechas(body.dias);
  if (dias.length === 0) {
    return NextResponse.json(
      { error: "Falta elegir los días" },
      { status: 400, headers: CORS }
    );
  }

  // Receptores pedidos (ronda 20): cualquier opción que los incluya pregunta
  // cuántos; sin número y con equipo que los menciona, se piden explícitos.
  const receptoresNum = Number(body.receptores);
  if (dias.length > 0 && /receptor/i.test(equipoTxt) && !Number.isFinite(receptoresNum)) {
    return NextResponse.json(
      { error: "Falta decir cuántos receptores" },
      { status: 400, headers: CORS }
    );
  }

  // Horario del reloj (opcional pero, si viene, viene completo).
  const horarioOk = (h: string) => /^\d{1,2}:\d{2}$/.test(h);
  const hi = horarioOk(horaInicio) ? horaInicio : null;
  const hf = horarioOk(horaFin) ? horaFin : null;

  // Modalidad del sitio → modalidad del panel.
  const virtual = /virt/i.test(modalidadRaw);
  const modalidad = virtual ? "REMOTO" : sede ? "FORANEO" : "PRESENCIAL_CDMX";

  // Fechas: inicio/fin para ordenar, lista real para la agenda dispersa.
  const fechaInicio = aFecha(dias[0]);
  const fechaFin = aFecha(dias[dias.length - 1]);
  const fechasTexto = dias
    .map((k) => {
      const [y, m, d] = k.split("-").map(Number);
      return `${d} ${MESES_CORTOS[m - 1]} ${y}`;
    })
    .join(" · ");

  const notasPartes = [
    "Llegó del sitio web",
    notasCliente ? `Notas del cliente: ${notasCliente}` : null,
  ].filter(Boolean);

  const lineasEquipo = equipoDelSitio(
    equipoTxt,
    Number.isFinite(receptoresNum) ? receptoresNum : 0
  );

  const data = {
    cliente,
    contacto: null,
    telefono: celular || null,
    correo,
    idiomas: "EN - ES",
    nombreEvento: eventoNombre,
    origen: null,
    estatus: "PROSPECTO",
    razonCancelacion: null,
    fechasTexto,
    fechas: serializarFechas(dias),
    fechaInicio,
    fechaFin,
    dias: dias.length,
    horaInicio: hi,
    horaFin: hf,
    horario: hi && hf ? `${hi} - ${hf}` : hi,
    tipoBloque: null,
    diaCompleto: false,
    tema: tema || null,
    modalidad,
    ciudad: sede || null,
    tarifa: 0,
    tarifaPorDia: null,
    impuestosTipo: null,
    ivaEnCotizacion: true,
    viaticos: null,
    interpretesExtra: null,
    pagoInterpretes: false,
    pagoEquipo: false,
    linkGlosario: null,
    equipo: lineasEquipo.length > 0 ? JSON.stringify(lineasEquipo) : null,
  };

  // ── Ronda 20: edición de una solicitud ya enviada ────────────────────────
  if (folioEdit && /^COT-\d+$/.test(folioEdit)) {
    const previo = await db.evento
      .findUnique({ where: { folio: folioEdit } })
      .catch(() => null);
    if (previo) {
      // Log sintetizado de lo que cambió — corto y legible, nunca un muro.
      const cambios: string[] = [];
      if (previo.cliente !== cliente) cambios.push(`cliente: ${previo.cliente} → ${cliente}`);
      if ((previo.nombreEvento ?? "") !== eventoNombre)
        cambios.push(`evento: ${previo.nombreEvento || "—"} → ${eventoNombre}`);
      if ((previo.correo ?? "") !== correo) cambios.push(`correo: ${previo.correo || "—"} → ${correo}`);
      if ((previo.telefono ?? "") !== (celular || ""))
        cambios.push(`teléfono: ${previo.telefono || "—"} → ${celular || "—"}`);
      const diasPrevios = previo.fechas
        ? parsearFechas(JSON.parse(previo.fechas)).map((k) => k.slice(8) + " " + MESES_CORTOS[Number(k.slice(5, 7)) - 1]).join(", ")
        : previo.fechasTexto || "—";
      const diasNuevos = dias.map((k) => k.slice(8) + " " + MESES_CORTOS[Number(k.slice(5, 7)) - 1]).join(", ");
      if (diasPrevios !== diasNuevos) cambios.push(`días: ${diasPrevios} → ${diasNuevos}`);
      const horarioPrevio = previo.horario || "—";
      const horarioNuevo = hi && hf ? `${hi} - ${hf}` : "—";
      if (horarioPrevio !== horarioNuevo) cambios.push(`horario: ${horarioPrevio} → ${horarioNuevo}`);
      const modPrevio =
        previo.modalidad === "REMOTO" ? "Virtual" : previo.modalidad === "FORANEO" ? `Presencial (${previo.ciudad || "?"})` : "Presencial";
      const modNueva = virtual ? "Virtual" : sede ? `Presencial (${sede})` : "Presencial";
      if (modPrevio !== modNueva) cambios.push(`modalidad: ${modPrevio} → ${modNueva}`);
      if ((previo.tema ?? "") !== (tema || "")) cambios.push(`tema: ${previo.tema || "—"} → ${tema || "—"}`);
      const eqPrevio = previo.equipo
        ? (JSON.parse(previo.equipo) as LineaEquipo[])
            .map((l) => `${l.nombre.toLowerCase()}${l.cantidad > 1 ? ` ×${l.cantidad}` : ""}`)
            .join(" + ") || "sin equipo"
        : "sin equipo";
      const eqNuevo = equipoTexto(equipoTxt, Number.isFinite(receptoresNum) ? receptoresNum : 0);
      if (eqPrevio !== eqNuevo) cambios.push(`equipo: ${eqPrevio} → ${eqNuevo}`);
      if ((previo.notas ?? "").includes("Notas del cliente: ") || notasCliente) {
        const notaPrevia = previo.notas?.match(/Notas del cliente: ([^·\n]*)/)?.[1] ?? "";
        if ((notaPrevia || "") !== (notasCliente || "")) cambios.push(`notas: ${notaPrevia || "—"} → ${notasCliente || "—"}`);
      }

      const resumen = cambios.length > 0 ? cambios.slice(0, 5).join(" · ") + (cambios.length > 5 ? ` · +${cambios.length - 5} más` : "") : "sin cambios de fondo";

      if (previo.estatus === "PROSPECTO") {
        // Sigue siendo prospecto: se sobrescribe y queda el log en las notas.
        const notas = [...notasPartes, `Cliente actualizó (${selloMexico()}): ${resumen}`]
          .filter(Boolean)
          .join(" · ");
        const actualizado = await db.evento.update({
          where: { id: previo.id },
          data: { ...data, notas },
        });
        return NextResponse.json(
          { folio: folioEdit, modo: "actualizada", evento: aEventoDTO(actualizado) },
          { status: 200, headers: CORS }
        );
      }

      // Ya avanzó de prospecto: el evento no se toca — el pedido queda anotado.
      const pedido = `Cliente solicitó cambios (${selloMexico()}): ${resumen}`;
      const notas = [previo.notas, pedido].filter(Boolean).join(" · ");
      const actualizado = await db.evento.update({
        where: { id: previo.id },
        data: { notas },
      });
      return NextResponse.json(
        { folio: folioEdit, modo: "cambios", evento: aEventoDTO(actualizado) },
        { status: 200, headers: CORS }
      );
    }
    // Folio que no existe: cae abajo y nace como solicitud nueva.
  }

  // Folio secuencial con reintento si dos solicitudes llegan a la vez.
  for (let intento = 0; intento < 3; intento++) {
    const folio = await siguienteFolio();
    try {
      const creado = await db.evento.create({
        data: { ...data, notas: notasPartes.join(" · "), folio },
      });
      return NextResponse.json(
        { folio: creado.folio, modo: "nueva", evento: aEventoDTO(creado) },
        { status: 201, headers: CORS }
      );
    } catch (e) {
      const codigo = (e as { code?: string }).code;
      if (codigo === "P2002" && intento < 2) continue; // folio tomado: siguiente
      return NextResponse.json(
        { error: "No se pudo registrar la solicitud" },
        { status: 500, headers: CORS }
      );
    }
  }
  return NextResponse.json(
    { error: "No se pudo asignar un folio" },
    { status: 500, headers: CORS }
  );
}
