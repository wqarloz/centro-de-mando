import { NextResponse } from "next/server";
import { db } from "@/lib/db";

/**
 * GET /api/disponibilidad — el calendario del sitio WQZ pregunta aquí
 * qué días ya están comprometidos antes de dejar elegirlos.
 *
 * Cuentan como ocupados los eventos CONFIRMADOS, REALIZADOS y PAGADOS
 * (compromiso real: la agenda ya tiene ese día). Los PROSPECTOS siguen
 * siendo "lápiz": no bloquean la vista del cliente ni se doble-bloquean
 * entre solicitudes. Los CANCELADOS, obviamente, liberan el día.
 *
 * CORS abierto: en producción el sitio puede vivir en otro dominio.
 */

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS });
}

/** Expande un rango de fechas a sus días ISO (tope de sanidad: 400 días). */
const diasDelRango = (ini: Date, fin: Date): string[] => {
  const salida: string[] = [];
  const cursor = new Date(ini);
  cursor.setUTCHours(12, 0, 0, 0);
  const tope = new Date(fin);
  tope.setUTCHours(12, 0, 0, 0);
  let vueltas = 0;
  while (cursor.getTime() <= tope.getTime() && vueltas < 400) {
    salida.push(cursor.toISOString().slice(0, 10));
    cursor.setUTCDate(cursor.getUTCDate() + 1);
    vueltas++;
  }
  return salida;
};

export async function GET() {
  const comprometidos = await db.evento.findMany({
    where: {
      estatus: { in: ["CONFIRMADO", "REALIZADO", "PAGADO"] },
      fechaInicio: { not: null },
    },
    select: { fechaInicio: true, fechaFin: true },
  });

  const ocupados = new Set<string>();
  for (const e of comprometidos) {
    if (!e.fechaInicio) continue;
    const fin = e.fechaFin ?? e.fechaInicio;
    for (const k of diasDelRango(new Date(e.fechaInicio), new Date(fin))) {
      ocupados.add(k);
    }
  }

  return NextResponse.json(
    { ocupados: [...ocupados].sort() },
    { headers: CORS }
  );
}
