import { NextRequest, NextResponse } from "next/server";
import { readdirSync, existsSync } from "fs";
import { homedir } from "os";
import { join } from "path";
import { PDFDocument } from "pdf-lib";
import { db } from "@/lib/db";
import { htmlCotizacion } from "@/lib/plantilla-cotizacion";

// ─────────────────────────────────────────────────────────────────────────────
// Cotización en PDF — Fase 2 del ecosistema.
//
// Ronda 18: el documento YA usa la plantilla oficial de la casa (v0.9, la
// esmeralda con ondas de voz). Se llena el HTML con los datos del evento —
// equipo incluido, conceptos con costo y la matemática de la ronda 17 — y
// Chromium lo imprime tal cual, sin redibujo a mano.
//
//   · En Vercel: el Chromium de @sparticuz/chromium (serverless estándar).
//   · En el taller: el Chromium de Playwright o del sistema; se puede fijar
//     con la variable CHROME_RUTA.
//   · Las fuentes de la casa viajan incrustadas (fuentes-casa.ts), así el
//     PDF nunca depende de internet.
// ─────────────────────────────────────────────────────────────────────────────

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const maxDuration = 60;

/** Encuentra un Chromium ejecutable: CHROME_RUTA → Playwright del taller → sistema. */
function chromiumDelTaller(): string | null {
  const cache = join(homedir(), ".cache", "ms-playwright");
  if (!existsSync(cache)) return null;
  const carpetas = readdirSync(cache)
    .filter((c) => c.startsWith("chromium-"))
    .sort()
    .reverse();
  for (const c of carpetas) {
    for (const sub of ["chrome-linux64/chrome", "chrome-linux/chrome", "headless_shell-linux64/headless_shell"]) {
      const ruta = join(cache, c, sub);
      if (existsSync(ruta)) return ruta;
    }
  }
  return null;
}

async function imprimirPdf(html: string): Promise<Uint8Array> {
  const puppeteer = (await import("puppeteer-core")).default;
  let navegador;
  if (process.env.VERCEL) {
    const chromium = (await import("@sparticuz/chromium")).default;
    navegador = await puppeteer.launch({
      executablePath: await chromium.executablePath(),
      args: chromium.args,
      headless: "shell",
    });
  } else {
    const ruta =
      process.env.CHROME_RUTA ??
      chromiumDelTaller() ??
      ["/usr/bin/chromium", "/usr/bin/chromium-browser", "/usr/bin/google-chrome"].find(existsSync) ??
      null;
    if (!ruta) {
      throw new Error(
        "No hay Chromium disponible: instala Playwright/Chromium o define CHROME_RUTA."
      );
    }
    navegador = await puppeteer.launch({
      executablePath: ruta,
      args: ["--no-sandbox", "--disable-dev-shm-usage"],
      headless: true,
    });
  }
  try {
    const pagina = await navegador.newPage();
    await pagina.setContent(html, { waitUntil: "load" });
    // Las fuentes van en base64: se pide que terminen de cargar antes de imprimir.
    await pagina.evaluateHandle("document.fonts.ready");
    // El A4 es fijo: si el contenido crece más que la página (evento muy
    // cargado), se reduce TODO en la misma proporción — como se encuadra una
    // hoja larga en una hoja carta. El pie sigue pegado al borde.
    const alto = await pagina.evaluate(() => {
      const c = document.querySelector(".contenido");
      return c ? Math.ceil(c.scrollHeight) : 0;
    });
    if (alto > 1123) {
      const z = Math.max(0.72, 1123 / alto);
      await pagina.addStyleTag({
        content: `.contenido { zoom: ${z}; height: ${Math.round(1123 / z)}px; }`,
      });
    }
    return await pagina.pdf({
      width: "794px",
      height: "1123px",
      printBackground: true,
      preferCSSPageSize: true,
      pageRanges: "1",
    });
  } finally {
    await navegador.close();
  }
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  const fila = await db.evento.findUnique({ where: { id } }).catch(() => null);
  if (!fila) {
    return NextResponse.json({ error: "Evento no encontrado" }, { status: 404 });
  }

  const folio =
    fila.folio ??
    "COT-" + (fila.idEvento ? fila.idEvento.replace(/^EV-/, "") : fila.id.slice(-4).toUpperCase());

  try {
    const crudo = await imprimirPdf(htmlCotizacion(fila));

    // Metadatos del documento (título, autor) sobre el PDF que imprimió Chromium.
    const pdf = await PDFDocument.load(crudo);
    pdf.setTitle(`Cotización ${folio} — ${fila.cliente}`);
    pdf.setAuthor("Carlos Serrano");
    const eventoNombre = fila.notas?.match(/Evento:\s*([^·\n]+)/)?.[1]?.trim() ?? fila.tema ?? "";
    pdf.setSubject(`Cotización de servicios de interpretación${eventoNombre ? ` · ${eventoNombre}` : ""}`);
    pdf.setCreator("Centro de Mando");
    const bytes = await pdf.save();

    return new NextResponse(bytes as unknown as BodyInit, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `inline; filename="Cotizacion-${folio}.pdf"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (e) {
    console.error("cotización:", e);
    return NextResponse.json(
      { error: "No se pudo imprimir la cotización" },
      { status: 500 }
    );
  }
}
