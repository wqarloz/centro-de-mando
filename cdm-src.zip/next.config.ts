import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // En el taller (sandbox) se empaqueta standalone para servir rápido;
  // en Vercel la plataforma usa su propio emplatado, así que ahí NO se
  // genera el paquete standalone.
  output: process.env.VERCEL ? undefined : "standalone",
  // Chromium para imprimir cotizaciones en Vercel: hay que meterlo a la
  // función serverless a mano, Next no lo rastrea solo (se descomprime en
  // tiempo de ejecución desde .br).
  serverExternalPackages: ["puppeteer-core", "@sparticuz/chromium"],
  outputFileTracingIncludes: {
    "/api/cotizacion/**": [
      "./node_modules/@sparticuz/chromium/bin/**",
      "./node_modules/@sparticuz/chromium/dist/**",
    ],
  },
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  allowedDevOrigins: ["*.space-z.ai"],
  devIndicators: false,
};

export default nextConfig;
