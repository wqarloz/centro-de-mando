/* Service worker del Centro de Mando y del sitio WQZ (misma casa).
   Califica de PWA instalable y deja pasar TODAS las peticiones a la
   red tal cual (la app vive con datos frescos; no queremos que una
   copia vieja se quede pegada en el teléfono).
   Dos cortesías propias de cada app:
   · /wqz.html se guarda en la alacena al vuelo: la app instalada del
     sitio abre incluso sin señal (el sobre es un solo archivo).
   · toda navegación sin red cae a su página de cortesía: oscura para
     el Centro de Mando, clara para el sitio del intérprete. */
const CASCARON = { name: "cm-shell-v1" };
const WQZ = "/wqz.html";

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CASCARON.name).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches
      .keys()
      .then((claves) =>
        Promise.all(claves.filter((c) => c !== CASCARON.name).map((c) => caches.delete(c)))
      )
      .then(() => self.clients.claim())
  );
});

/* La página de cortesía cuando no hay red, con el vestido de cada app. */
function cortesia(esWQZ) {
  const cuerpo = esWQZ
    ? {
        fondo: "#EFF5F1",
        tinta: "#212226",
        muda: "#6B716D",
        acento: "#137547",
        titulo: "Carlos Serrano · Intérprete",
        texto: "No pude conectar. Revisa tu señal y vuelve a abrir la app.",
      }
    : {
        fondo: "#0a0a0c",
        tinta: "#f5f5f4",
        muda: "#9b9b9b",
        acento: "#e3c892",
        titulo: "Centro de Mando",
        texto: "No pude conectar. Revisa tu señal y vuelve a abrir la app.",
      };
  return new Response(
    "<!doctype html><html lang=es><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>Sin conexión</title><style>body{background:" +
      cuerpo.fondo + ";color:" + cuerpo.tinta + ";font-family:system-ui,sans-serif;display:grid;place-items:center;height:100vh;margin:0}p{max-width:20ch;text-align:center;line-height:1.6;color:" +
      cuerpo.muda + "}b{color:" + cuerpo.acento + ";display:block;margin-bottom:.5ch;font-size:1.15rem}</style><body><p><b>" +
      cuerpo.titulo + "</b>" + cuerpo.texto + "</p>",
    { headers: { "Content-Type": "text/html; charset=utf-8" } }
  );
}

self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET") return;
  /* navegaciones: red primero, alacena de respaldo */
  if (e.request.mode === "navigate") {
    const esWQZ = new URL(e.request.url).pathname === WQZ;
    e.respondWith(
      fetch(e.request)
        .then((r) => {
          if (esWQZ && r.ok) {
            const copia = r.clone();
            caches
              .open(CASCARON.name)
              .then((c) => c.put(WQZ, copia))
              .catch(() => {});
          }
          return r;
        })
        .catch(() =>
          caches
            .open(CASCARON.name)
            .then((c) => (esWQZ ? c.match(WQZ) : undefined))
            .then((g) => g || cortesia(esWQZ))
        )
    );
    return;
  }
  /* todo lo demás: directo a la red, sin caché */
});
